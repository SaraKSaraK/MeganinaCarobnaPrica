(()=>{
'use strict';
const $=s=>document.querySelector(s);
const world=$('#world'),viewport=$('#sceneViewport'),megan=$('#megan'),piko=$('#piko'),held=$('#heldItem');
const soundBtn=$('#soundBtn'),coach=$('#dragCoach'),orb=$('#narratorOrb'),zoneName=$('#zoneName');
const flowers=$('#flowers'),butterfly=$('#butterfly'),puddle=$('#puddle'),nut=$('#nut'),bush=$('#bush'),squirrel=$('#squirrel'),mushroom=$('#mushroom'),log=$('#log'),gate=$('#gate'),secret=$('#secretMeadow');
const WORLD_W=5200, MIN_X=130, MAX_X=4930, FOLLOW_GAP=118;
let meganX=360,pikoX=235,cameraX=0,dragging=false,dragPointer=null,desiredX=meganX,lastFrame=performance.now(),facing=1;
let soundOn=true,audioStarted=false,audioCtx=null,music=null;
let carried=null,bushOpen=false,squirrelFed=false,gateOpen=false,puddleCount=0,butterflyCount=0;
let speakTimer=null,lastSpoken='';
const nearRange=175;
const storyState={flowers:false,puddle:false,nut:false,bush:false,squirrel:false,mushroom:false,log:false,gate:false};

function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function worldXFromClient(clientX){return clamp(clientX + cameraX, MIN_X, MAX_X)}
function setPos(){megan.style.left=meganX+'px';piko.style.left=pikoX+'px';world.style.transform=`translate3d(${-cameraX}px,0,0)`}
function targetCamera(){const vw=innerWidth;return clamp(meganX-vw*.43,0,WORLD_W-vw)}
function updateZone(){let n='Čarobna livada';if(meganX>1750)n='Vjeveričji gaj';if(meganX>2850)n='Gljivina čistina';if(meganX>3950)n='Tajni prolaz';if(gateOpen&&meganX>4520)n='Skrivena livada';if(zoneName.textContent!==n)zoneName.textContent=n}

function nativeSpeak(text){
 if(!soundOn||!text)return;
 lastSpoken=text;
 orb.classList.add('speaking');
 clearTimeout(speakTimer);
 speakTimer=setTimeout(()=>orb.classList.remove('speaking'),Math.max(1200,text.length*58));
 try{if(window.AndroidNative?.speak)AndroidNative.speak(text)}catch(_){ }
}
function stopSpeak(){try{window.AndroidNative?.stopSpeaking?.()}catch(_){ } orb.classList.remove('speaking')}

function ensureAudio(){
 if(audioStarted)return;
 audioStarted=true;
 music=new Audio('audio/music_loop.mp3'); music.loop=true; music.volume=.22;
 music.play().catch(()=>{});
 try{audioCtx=new (window.AudioContext||window.webkitAudioContext)()}catch(_){ }
}
function setSound(on){soundOn=on;soundBtn.classList.toggle('soundOn',on);soundBtn.querySelector('.note').textContent=on?'♪':'×';if(music)music.volume=on?.22:0;if(!on)stopSpeak();else if(audioStarted)music?.play().catch(()=>{})}
function tone(freq=500,d=.09,type='sine',vol=.035,delay=0){if(!soundOn||!audioCtx)return;const t=audioCtx.currentTime+delay,o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.setValueAtTime(freq,t);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(vol,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g).connect(audioCtx.destination);o.start(t);o.stop(t+d+.03)}
function sfx(kind){ensureAudio(); if(!audioCtx)return; if(audioCtx.state==='suspended')audioCtx.resume();
 if(kind==='pickup'){tone(620,.11,'sine',.035);tone(850,.15,'sine',.03,.07)}
 if(kind==='sparkle'){tone(760,.08,'triangle',.026);tone(1080,.13,'triangle',.02,.07)}
 if(kind==='splash'){tone(180,.13,'sine',.05);tone(260,.09,'triangle',.03,.05)}
 if(kind==='boing'){tone(210,.18,'sine',.05);tone(410,.16,'sine',.035,.07)}
 if(kind==='pop'){tone(430,.08,'triangle',.033);tone(650,.09,'sine',.025,.04)}
 if(kind==='munch'){tone(240,.05,'square',.012);tone(190,.05,'square',.012,.09);tone(270,.05,'square',.012,.18)}
 if(kind==='door'){tone(210,.28,'sine',.035);tone(315,.28,'triangle',.025,.12);tone(480,.35,'sine',.02,.24)}
}
function sparkAt(x,y,count=10){const fx=$('#worldFx');for(let i=0;i<count;i++){const s=document.createElement('i');s.className='spark';s.style.left=x+'px';s.style.bottom=y+'px';const a=Math.random()*Math.PI*2,r=30+Math.random()*70;s.style.setProperty('--dx',Math.cos(a)*r+'px');s.style.setProperty('--dy',Math.sin(a)*r+'px');fx.appendChild(s);setTimeout(()=>s.remove(),950)}}
function reactPiko(){piko.classList.remove('react');void piko.offsetWidth;piko.classList.add('react');setTimeout(()=>piko.classList.remove('react'),800)}

function objectX(el){return Number(el.dataset.x||0)}
function near(el,range=nearRange){return Math.abs(meganX-objectX(el))<=range}
function updateNear(){
 document.querySelectorAll('.object').forEach(el=>el.classList.remove('near'));
 [flowers,butterfly,puddle,nut,bush,squirrel,mushroom,log,gate].forEach(el=>{
   if(!el||el.classList.contains('hidden')||el.classList.contains('taken'))return;
   if(near(el,el===gate?210:nearRange))el.classList.add('near');
 });
}
function softReject(el){el.animate([{transform:'scale(1)'},{transform:'scale(1.06)'},{transform:'scale(1)'}],{duration:300});sfx('pop')}
function useObject(el,fn,range=nearRange){el.addEventListener('pointerdown',e=>{e.stopPropagation();ensureAudio();if(!near(el,range)){softReject(el);return}fn(el)})}

function carryNut(){carried='nut';held.className='heldItem show nutHeld';nut.classList.add('taken');storyState.nut=true;sfx('pickup');sparkAt(meganX+60,120,7);nativeSpeak('Ooo, žir! Megan ga može ponijeti. Možda ga netko želi.');reactPiko()}
function dropCarry(){carried=null;held.className='heldItem'}

function interactFlowers(){flowers.classList.remove('bloom');void flowers.offsetWidth;flowers.classList.add('bloom');sfx('sparkle');sparkAt(770,155,12);if(!storyState.flowers){storyState.flowers=true;nativeSpeak('Pogledaj! Cvjetići se bude kad ih Megan dotakne.');reactPiko()}}
function interactButterfly(){butterflyCount++;butterfly.classList.remove('chase');void butterfly.offsetWidth;butterfly.classList.add('chase');sfx('sparkle');if(butterflyCount===1)nativeSpeak('Leptirić! Pokušaj ga pratiti.');setTimeout(()=>{const nx=clamp(objectX(butterfly)+170,950,1680);butterfly.dataset.x=nx;butterfly.style.left=nx+'px';butterfly.classList.remove('chase')},1000)}
function interactPuddle(){puddleCount++;megan.classList.remove('jump');void megan.offsetWidth;megan.classList.add('jump');puddle.classList.remove('splash');void puddle.offsetWidth;puddle.classList.add('splash');sfx('splash');reactPiko();sparkAt(1400,90,8);if(puddleCount===1)nativeSpeak('PLOP! Megan je skočila ravno u blatnu lokvu!');else if(puddleCount===3)nativeSpeak('Opet! Mislim da Piko više uopće nije suh.');setTimeout(()=>megan.classList.remove('jump'),850)}
function interactBush(){if(!bushOpen){bushOpen=true;storyState.bush=true;bush.classList.add('rustle');sfx('pop');nativeSpeak('Ššš... nešto se miče u grmu.');setTimeout(()=>{squirrel.classList.remove('hidden');squirrel.classList.add('show');sfx('sparkle');reactPiko();nativeSpeak('Aha! Mala vjeverica. Izgleda gladno.')},850)}else{bush.classList.remove('rustle');void bush.offsetWidth;bush.classList.add('rustle');sfx('pop')}}
function interactSquirrel(){if(!bushOpen)return;if(squirrelFed){squirrel.classList.remove('happy');void squirrel.offsetWidth;squirrel.classList.add('happy');sfx('sparkle');return}if(carried==='nut'){dropCarry();squirrelFed=true;storyState.squirrel=true;squirrel.classList.add('eating');sfx('munch');nativeSpeak('Njam, njam! Vjeverica je dobila svoj žir.');setTimeout(()=>{squirrel.classList.remove('eating');squirrel.classList.add('happy');sparkAt(2550,165,14);sfx('sparkle');reactPiko();nativeSpeak('Vidi! Pokazuje nam put prema sjajnim vratima.');gate.classList.add('near')},1200)}else{nativeSpeak('Vjeverica njuška po travi. Možda traži nešto za pojesti.') }}
function interactMushroom(){mushroom.classList.remove('bounce');void mushroom.offsetWidth;mushroom.classList.add('bounce');megan.classList.remove('jump');void megan.offsetWidth;megan.classList.add('jump');sfx('boing');reactPiko();if(!storyState.mushroom){storyState.mushroom=true;nativeSpeak('Boooing! Ova gljiva je mekana kao trampolin.');}setTimeout(()=>megan.classList.remove('jump'),850)}
function interactLog(){log.classList.remove('sit');void log.offsetWidth;log.classList.add('sit');megan.classList.add('sit');sfx('pop');reactPiko();if(!storyState.log){storyState.log=true;nativeSpeak('Malo odmora. Piko kaže da je ovo njegov najbolji stolac.');}setTimeout(()=>megan.classList.remove('sit'),1500)}
function interactGate(){if(gateOpen){sfx('sparkle');return}if(!squirrelFed){nativeSpeak('Hmm... ova vrata još spavaju. Možda netko u šumi zna kako ih probuditi.');softReject(gate);return}gateOpen=true;storyState.gate=true;gate.classList.add('open','done');secret.classList.add('reveal');sfx('door');sparkAt(4400,180,24);nativeSpeak('Oooo! Tajni prolaz! Što li je tamo iza?');reactPiko()}

useObject(flowers,interactFlowers);useObject(butterfly,interactButterfly,190);useObject(puddle,interactPuddle,210);useObject(nut,carryNut,180);useObject(bush,interactBush,200);useObject(squirrel,interactSquirrel,200);useObject(mushroom,interactMushroom,215);useObject(log,interactLog,210);useObject(gate,interactGate,235);
piko.addEventListener('pointerdown',e=>{e.stopPropagation();ensureAudio();reactPiko();sfx('pop');if(Math.random()<.3)nativeSpeak('Piko je spreman za pustolovinu!')});

function startDrag(e){e.preventDefault();e.stopPropagation();ensureAudio();dragging=true;dragPointer=e.pointerId;megan.setPointerCapture?.(e.pointerId);desiredX=worldXFromClient(e.clientX);megan.classList.add('dragging');coach.classList.add('hide')}
function moveDrag(e){if(!dragging||e.pointerId!==dragPointer)return;e.preventDefault();desiredX=worldXFromClient(e.clientX)}
function endDrag(e){if(!dragging||e.pointerId!==dragPointer)return;dragging=false;dragPointer=null;desiredX=meganX;megan.classList.remove('dragging')}
megan.addEventListener('pointerdown',startDrag);megan.addEventListener('pointermove',moveDrag);megan.addEventListener('pointerup',endDrag);megan.addEventListener('pointercancel',endDrag);

function frame(now){const dt=Math.min(.035,(now-lastFrame)/1000);lastFrame=now;let moving=false;
 if(dragging){const delta=desiredX-meganX;const maxStep=430*dt;if(Math.abs(delta)>2){const step=Math.sign(delta)*Math.min(Math.abs(delta),maxStep);meganX+=step;moving=true;const nf=delta<0?-1:1;if(nf!==facing){facing=nf;megan.classList.toggle('faceLeft',facing<0)}}}
 megan.classList.toggle('walking',moving);
 const targetPiko=clamp(meganX-facing*FOLLOW_GAP,MIN_X,MAX_X);const pd=targetPiko-pikoX;if(Math.abs(pd)>5){pikoX+=Math.sign(pd)*Math.min(Math.abs(pd),310*dt);piko.classList.add('walking');piko.classList.toggle('faceLeft',pd<0)}else piko.classList.remove('walking');
 const tc=targetCamera();cameraX+=(tc-cameraX)*Math.min(1,dt*5.5);
 updateZone();updateNear();setPos();requestAnimationFrame(frame)}

soundBtn.addEventListener('click',e=>{e.stopPropagation();ensureAudio();setSound(!soundOn)});
$('#backBtn').addEventListener('click',e=>{e.stopPropagation();reactPiko();nativeSpeak('Još malo istražujemo šumu.')});

addEventListener('pointerdown',()=>ensureAudio(),{once:true});
addEventListener('resize',()=>{cameraX=targetCamera();setPos()});
setPos();requestAnimationFrame(frame);
setTimeout(()=>{if(!coach.classList.contains('hide'))nativeSpeak('Drži Megan prstom i pomakni je lijevo ili desno.')},900);
window.__nativeTtsStart=()=>{try{if(music)music.volume=soundOn?.09:0}catch(_){}};
window.__nativeTtsDone=()=>{try{if(music)music.volume=soundOn?.22:0}catch(_){}};
})();
