package com.sara.meganstory;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;
import org.json.JSONArray;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int REQ_AUDIO = 1001;
    private WebView webView;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private Intent recognizerIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        tts = new TextToSpeech(this, this);
        webView.addJavascriptInterface(new NativeBridge(), "AndroidNative");
        webView.loadUrl("file:///android_asset/index.html");
        setupSpeechRecognizer();
    }

    private void setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return;
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hr-HR");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle params) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float rmsdB) {}
            public void onBufferReceived(byte[] buffer) {}
            public void onEndOfSpeech() {}
            public void onPartialResults(Bundle partialResults) {}
            public void onEvent(int eventType, Bundle params) {}
            public void onError(int error) { runJs("window.__nativeSpeechError&&window.__nativeSpeechError();"); }
            public void onResults(Bundle results) {
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (list == null || list.isEmpty()) { runJs("window.__nativeSpeechError&&window.__nativeSpeechError();"); return; }
                String best = list.get(0); JSONArray arr = new JSONArray(); for (String item : list) arr.put(item);
                runJs("window.__nativeSpeechResult&&window.__nativeSpeechResult(" + quote(best) + "," + quote(arr.toString()) + ");");
            }
        });
    }

    private static String quote(String s) {
        if (s == null) return "\"\"";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\"";
    }
    private void runJs(String js) { runOnUiThread(() -> webView.evaluateJavascript(js, null)); }

    @Override public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) return;
        Locale hr = new Locale("hr", "HR");
        tts.setLanguage(hr);
        Voice best = null;
        Set<Voice> voices = tts.getVoices();
        if (voices != null) {
            for (Voice v : voices) {
                Locale l = v.getLocale();
                if (l == null || !"hr".equalsIgnoreCase(l.getLanguage())) continue;
                if (best == null || v.getQuality() > best.getQuality()) best = v;
            }
        }
        if (best != null) tts.setVoice(best);
        tts.setSpeechRate(0.96f);
        tts.setPitch(1.02f);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) { runJs("window.__nativeTtsStart&&window.__nativeTtsStart();"); }
            @Override public void onDone(String utteranceId) { runJs("window.__nativeTtsDone&&window.__nativeTtsDone();"); }
            @Override public void onError(String utteranceId) { runJs("window.__nativeTtsDone&&window.__nativeTtsDone();"); }
        });
    }

    public class NativeBridge {
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> { if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "narrator"); });
        }
        @JavascriptInterface public void stopSpeaking() { runOnUiThread(() -> { if (tts != null) tts.stop(); }); }
        @JavascriptInterface public void startListening() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return;
                }
                if (recognizer != null) recognizer.startListening(recognizerIntent);
                else runJs("window.__nativeSpeechError&&window.__nativeSpeechError();");
            });
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (recognizer != null) recognizer.startListening(recognizerIntent);
        } else runJs("window.__nativeSpeechError&&window.__nativeSpeechError();");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
