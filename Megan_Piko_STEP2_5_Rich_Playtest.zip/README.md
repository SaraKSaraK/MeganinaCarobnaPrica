# Megan & Piko — Step 2.5 Rich Interaction Playground

A longer preschool playtest build focused on game feel before story expansion.

## Controls
- Touch and hold Megan, then drag left/right. She walks toward the finger while staying on the path.
- Release Megan to stop.
- Nearby usable objects glow gently; tap the object to interact.
- No reading is required for gameplay.

## Test route
1. Wake the flowers.
2. Chase the butterfly.
3. Jump in the muddy puddle repeatedly.
4. Find and pick up the acorn.
5. Investigate the moving bush.
6. Give the acorn to the squirrel.
7. Bounce on the giant mushroom.
8. Rest on the log.
9. Reach and open the secret gate after helping the squirrel.

## Audio
A quiet original instrumental loop starts after the first touch. Croatian Android TTS is used for short narrator lines; the app selects the highest-quality Croatian voice reported by the device and ducks music while narration is speaking.

## Prototype signing
This project contains a development-only keystore so later prototype APKs built from this project can update one another instead of receiving a different random GitHub Actions debug signature each build. It must never be reused for a Play Store / production release.
