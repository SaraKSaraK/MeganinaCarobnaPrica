extends Node2D

signal drag_started
signal drag_ended

@export var min_x := 160.0
@export var max_x := 4540.0
var target_x := 360.0
var dragging := false
var moving := false
var speed := 560.0
var facing := 1.0
var walk_time := 0.0
var jumping := false

var idle_tex = preload("res://assets/megan_idle.svg")
var walk1_tex = preload("res://assets/megan_walk1.svg")
var walk2_tex = preload("res://assets/megan_walk2.svg")
var sprite: Sprite2D

func _ready():
    sprite = Sprite2D.new()
    sprite.texture = idle_tex
    sprite.scale = Vector2(0.72,0.72)
    sprite.position = Vector2(0,-88)
    add_child(sprite)
    target_x = global_position.x

func _process(delta):
    if jumping:
        return
    var dist = target_x - global_position.x
    moving = abs(dist) > 4.0
    if moving:
        facing = sign(dist)
        global_position.x = move_toward(global_position.x, target_x, speed * delta)
        walk_time += delta
        sprite.texture = walk1_tex if int(walk_time * 7.0) % 2 == 0 else walk2_tex
        sprite.scale.x = abs(sprite.scale.x) * facing
        sprite.position.y = -88 + sin(walk_time*14.0)*2.0
    else:
        sprite.texture = idle_tex
        sprite.scale.x = abs(sprite.scale.x) * facing
        sprite.position.y = -88

func can_grab(screen_pos: Vector2, camera: Camera2D) -> bool:
    var world_pos = camera.get_screen_center_position() + screen_pos - get_viewport_rect().size/2.0
    return world_pos.distance_to(global_position + Vector2(0,-80)) < 130.0

func begin_drag():
    dragging = true
    drag_started.emit()

func update_drag(screen_pos: Vector2, camera: Camera2D):
    if not dragging or jumping:
        return
    var world_x = camera.get_screen_center_position().x + screen_pos.x - get_viewport_rect().size.x/2.0
    target_x = clamp(world_x, min_x, max_x)

func end_drag():
    dragging = false
    target_x = global_position.x
    drag_ended.emit()

func hop(height := 120.0, duration := 0.72):
    if jumping:
        return
    jumping = true
    target_x = global_position.x
    var start_y = global_position.y
    var tween = create_tween()
    tween.set_trans(Tween.TRANS_QUAD)
    tween.set_ease(Tween.EASE_OUT)
    tween.tween_property(self, "global_position:y", start_y-height, duration*0.45)
    tween.set_ease(Tween.EASE_IN)
    tween.tween_property(self, "global_position:y", start_y, duration*0.55)
    tween.finished.connect(func(): jumping = false)
