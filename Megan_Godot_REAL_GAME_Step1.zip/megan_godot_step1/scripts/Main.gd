extends Node2D

const WORLD_W := 4800.0
const GROUND_Y := 570.0

var player
var camera
var music
var sfx
var dragging := false
var acorn_taken := false
var squirrel_fed := false
var gate_open := false
var voice_enabled := true
var english_voice := ""
var interactables := []
var hint_timer := 0.0

func _ready():
    _build_world()
    _setup_tts()
    _speak("Welcome, Megan! Hold me with your finger and move me through the forest!")

func _build_world():
    var art = Node2D.new()
    art.set_script(load("res://scripts/WorldArt.gd"))
    add_child(art)

    # Decorative sparkle particles across the world
    for x in [680, 1420, 2740, 3550, 4200]:
        var p = CPUParticles2D.new()
        p.position = Vector2(x, 390)
        p.amount = 12
        p.lifetime = 2.8
        p.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
        p.emission_sphere_radius = 90.0
        p.initial_velocity_min = 8.0
        p.initial_velocity_max = 18.0
        p.gravity = Vector2(0,-4)
        p.scale_amount_min = 2.0
        p.scale_amount_max = 4.0
        p.color = Color(1.0,0.92,0.65,0.75)
        add_child(p)

    player = Node2D.new()
    player.set_script(load("res://scripts/Player.gd"))
    player.position = Vector2(360, GROUND_Y)
    add_child(player)

    camera = Camera2D.new()
    camera.position = Vector2(0,-40)
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 5.0
    camera.limit_left = 0
    camera.limit_right = int(WORLD_W)
    camera.limit_top = 0
    camera.limit_bottom = 720
    player.add_child(camera)

    # Game objects
    _add_object("puddle1", preload("res://assets/puddle.svg"), Vector2(980, 595), Vector2(0.78,0.78), "puddle")
    _add_object("flower_magic", null, Vector2(1420, 535), Vector2.ONE, "flowers")
    _add_object("acorn", preload("res://assets/acorn.svg"), Vector2(1800, 540), Vector2(0.78,0.78), "acorn")
    _add_object("squirrel", preload("res://assets/squirrel.svg"), Vector2(2260, 510), Vector2(0.86,0.86), "squirrel")
    _add_object("mushroom", preload("res://assets/mushroom.svg"), Vector2(2860, 520), Vector2(0.90,0.90), "mushroom")
    _add_object("puddle2", preload("res://assets/puddle.svg"), Vector2(3380, 595), Vector2(0.95,0.95), "puddle")
    _add_object("gate", preload("res://assets/gate.svg"), Vector2(4130, 425), Vector2(0.95,0.95), "gate")

    # Simple flower patch visual
    var flowers = Node2D.new()
    flowers.name = "FlowerPatch"
    flowers.position = Vector2(1420,535)
    add_child(flowers)
    for i in range(9):
        var poly = Polygon2D.new()
        poly.polygon = PackedVector2Array([Vector2(-8,0),Vector2(0,-28),Vector2(8,0)])
        poly.color = [Color("#f4a8d8"),Color("#d9bdff"),Color("#ffe279")][i%3]
        poly.position = Vector2((i-4)*26, sin(i)*8)
        flowers.add_child(poly)

    # Audio
    music = AudioStreamPlayer.new()
    music.stream = load("res://audio/forest_music.wav")
    music.bus = &"Music"
    music.autoplay = true
    add_child(music)
    music.play()
    music.finished.connect(func(): music.play())

    sfx = AudioStreamPlayer.new()
    sfx.bus = &"SFX"
    add_child(sfx)

    # Tiny unobtrusive audio toggle only
    var layer = CanvasLayer.new()
    add_child(layer)
    var sound_btn = Button.new()
    sound_btn.text = "♪"
    sound_btn.position = Vector2(1190,24)
    sound_btn.size = Vector2(64,64)
    sound_btn.add_theme_font_size_override("font_size",32)
    sound_btn.pressed.connect(_toggle_audio)
    layer.add_child(sound_btn)

func _add_object(n:String, tex, pos:Vector2, sc:Vector2, kind:String):
    var node = Node2D.new()
    node.name = n
    node.position = pos
    node.set_meta("kind",kind)
    if tex != null:
        var sp = Sprite2D.new()
        sp.texture = tex
        sp.scale = sc
        node.add_child(sp)
    add_child(node)
    interactables.append(node)

func _setup_tts():
    if not DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
        voice_enabled = false
        return
    var voices = DisplayServer.tts_get_voices_for_language("en")
    if voices.size() > 0:
        english_voice = voices[0]
    else:
        voice_enabled = false

func _speak(text:String):
    if not voice_enabled or english_voice == "":
        return
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Music"), -26.0)
    DisplayServer.tts_speak(text, english_voice, 72, 1.08, 1.02, 0, true)
    var timer = get_tree().create_timer(max(1.6, text.length()*0.045))
    timer.timeout.connect(func(): AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Music"), -18.0))

func _input(event):
    if event is InputEventScreenTouch:
        if event.pressed:
            if player.can_grab(event.position, camera):
                dragging = true
                player.begin_drag()
            else:
                _try_interact(event.position)
        else:
            if dragging:
                dragging = false
                player.end_drag()
    elif event is InputEventScreenDrag and dragging:
        player.update_drag(event.position, camera)
    elif event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_LEFT:
            if event.pressed:
                if player.can_grab(event.position, camera):
                    dragging = true
                    player.begin_drag()
                else:
                    _try_interact(event.position)
            else:
                if dragging:
                    dragging = false
                    player.end_drag()
    elif event is InputEventMouseMotion and dragging and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        player.update_drag(event.position, camera)

func _screen_to_world(screen_pos:Vector2) -> Vector2:
    return camera.get_screen_center_position() + screen_pos - get_viewport_rect().size/2.0

func _try_interact(screen_pos:Vector2):
    var w = _screen_to_world(screen_pos)
    var nearest = null
    var nearest_d = 9999.0
    for ob in interactables:
        if not is_instance_valid(ob) or not ob.visible:
            continue
        var d = ob.global_position.distance_to(w)
        if d < nearest_d:
            nearest = ob
            nearest_d = d
    if nearest == null or nearest_d > 170.0:
        return
    if player.global_position.distance_to(nearest.global_position) > 290.0:
        _pulse(nearest)
        return
    _activate(nearest)

func _activate(ob):
    var kind = str(ob.get_meta("kind"))
    match kind:
        "puddle":
            _speak("Yaaay! A muddy puddle! SPLASH!")
            player.hop(135,0.78)
            _play_sfx("res://audio/splash.wav")
            _splash(ob.global_position)
        "flowers":
            _speak("Ooooh! Magic flowers! Look at them sparkle!")
            _play_sfx("res://audio/sparkle.wav")
            _sparkle_burst(ob.global_position + Vector2(0,-30), Color("#f4b5ff"))
        "acorn":
            if acorn_taken:
                return
            acorn_taken = true
            ob.visible = false
            _play_sfx("res://audio/pickup.wav")
            _speak("Ooo! An acorn! I bet someone in the forest would love this!")
            var held = Sprite2D.new()
            held.name = "HeldAcorn"
            held.texture = preload("res://assets/acorn.svg")
            held.scale = Vector2(0.34,0.34)
            held.position = Vector2(42,-100)
            player.add_child(held)
        "squirrel":
            if squirrel_fed:
                _speak("Aww! She is still munching!")
                _pulse(ob)
            elif acorn_taken:
                squirrel_fed = true
                var held = player.get_node_or_null("HeldAcorn")
                if held: held.queue_free()
                _play_sfx("res://audio/sparkle.wav")
                _speak("Yay! She loves it! Look how happy she is!")
                _sparkle_burst(ob.global_position + Vector2(0,-70), Color("#ffe587"))
            else:
                _speak("A squirrel! Aww... I think she is hungry. Maybe she likes acorns!")
                _pulse(ob)
        "mushroom":
            _speak("Whoa! A giant bouncy mushroom! Here I go!")
            _play_sfx("res://audio/boing.wav")
            player.hop(190,0.88)
            _sparkle_burst(ob.global_position + Vector2(0,-100), Color("#dda0ff"))
        "gate":
            if squirrel_fed:
                if not gate_open:
                    gate_open = true
                    _speak("NO WAY! The magic door is opening!")
                    _play_sfx("res://audio/sparkle.wav")
                    var tw = create_tween().set_parallel(true)
                    tw.tween_property(ob,"modulate:a",0.12,1.4)
                    tw.tween_property(ob,"scale",Vector2(1.12,1.12),1.4)
                    _sparkle_burst(ob.global_position + Vector2(0,-120), Color("#fff1a3"))
                else:
                    _speak("A secret path! I wonder where it goes...")
            else:
                _speak("Hmm... a magic door. I think the forest wants us to help someone first!")
                _pulse(ob)

func _pulse(node):
    var tw = create_tween()
    tw.tween_property(node,"scale",Vector2(1.08,1.08),0.16)
    tw.tween_property(node,"scale",Vector2.ONE,0.22)

func _play_sfx(path:String):
    sfx.stream = load(path)
    sfx.play()

func _sparkle_burst(pos:Vector2, col:Color):
    var p = CPUParticles2D.new()
    p.position = pos
    p.one_shot = true
    p.amount = 28
    p.lifetime = 1.0
    p.explosiveness = 0.9
    p.initial_velocity_min = 70.0
    p.initial_velocity_max = 150.0
    p.direction = Vector2(0,-1)
    p.spread = 180.0
    p.gravity = Vector2(0,120)
    p.scale_amount_min = 3.0
    p.scale_amount_max = 7.0
    p.color = col
    add_child(p)
    p.emitting = true
    get_tree().create_timer(1.5).timeout.connect(p.queue_free)

func _splash(pos:Vector2):
    var p = CPUParticles2D.new()
    p.position = pos + Vector2(0,-25)
    p.one_shot = true
    p.amount = 34
    p.lifetime = 0.75
    p.explosiveness = 0.95
    p.initial_velocity_min = 90.0
    p.initial_velocity_max = 190.0
    p.direction = Vector2(0,-1)
    p.spread = 85.0
    p.gravity = Vector2(0,420)
    p.scale_amount_min = 3.0
    p.scale_amount_max = 8.0
    p.color = Color("#74c7ee")
    add_child(p)
    p.emitting = true
    get_tree().create_timer(1.2).timeout.connect(p.queue_free)

func _toggle_audio():
    var idx = AudioServer.get_bus_index("Master")
    AudioServer.set_bus_mute(idx, not AudioServer.is_bus_mute(idx))
