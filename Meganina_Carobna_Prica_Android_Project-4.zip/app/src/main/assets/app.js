
const ADVENTURES = [{"id": "forest", "title": "Tajna svjetlucave šume", "icon": "🌲", "color": "lavender", "sub": "Tragovi, zmaj i izgubljena zvijezda", "treasure": ["💎", "Šumski kristal"], "level": 1, "scenes": [{"kind": "choice", "art": "forest", "prop": "✨", "speaker": "Piko", "text": "{name}, nešto svjetluca iza velikog stabla. Kamo ćemo prvo?", "help": "Ti biraš priču. Oba puta su dobra.", "choices": [["🌳", "Iza stabla", "tree"], ["🌉", "Prema mostu", "bridge"]]}, {"kind": "voice", "art": "tracks", "prop": "🐾", "speaker": "Piko", "text": "Što smo pronašli u blatu? Reci svojim riječima.", "help": "Možeš reći tragovi, otisci ili šapice.", "concepts": ["trag", "otisk", "šap", "blat"]}, {"kind": "sequence", "art": "cards", "prop": "🧩", "speaker": "Piko", "text": "Ups! Pomiješao sam priču. Što je bilo prvo?", "help": "Sjeti se samog početka.", "choices": [["👧🏻", "Krenuli smo u pustolovinu", 1], ["🐾", "Pronašli smo tragove", 0], ["⭐", "Našli smo zvijezdu", 0]]}, {"kind": "spatial", "art": "bench", "prop": "🔑", "speaker": "Piko", "text": "Gdje se skriva ključ?", "help": "Pogledaj pažljivo gdje je ključ.", "choices": [["⬇️", "Ispod klupe", 1], ["⬆️", "Iznad klupe", 0], ["↔️", "Pored klupe", 0]]}, {"kind": "choice", "art": "dragon", "prop": "🐉", "speaker": "Mali zmaj", "text": "Ne mogu pronaći mamu. Što ćemo?", "help": "Ti vodiš priču.", "choices": [["❤️", "Pomoći zmaju", "dragon"], ["🔎", "Prvo pratiti tragove", "clues"]]}, {"kind": "sound", "art": "door", "prop": "🌙", "speaker": "Čarobna vrata", "text": "Koja riječ počinje glasom Mmmm, kao {name}?", "help": "Slušaj prvi glas.", "choices": [["🐱", "Maca", 1], ["🐶", "Pas", 0], ["☀️", "Sunce", 0]]}, {"kind": "predict", "art": "magicdoor", "prop": "🚪", "speaker": "Piko", "text": "Što TI misliš da je iza svjetlucavih vrata?", "help": "Nema krivog odgovora. Reci svoju ideju."}, {"kind": "retell", "art": "star", "prop": "⭐", "speaker": "Piko", "text": "Ispričaj mi dvije stvari koje su se dogodile u našoj priči.", "help": "Pogledaj male sličice ako trebaš pomoć."}]}, {"id": "sea", "title": "Misterij školjke", "icon": "🐚", "color": "blue", "sub": "More, redoslijed i smiješni galeb", "treasure": ["🐚", "Biserna školjka"], "level": 1, "scenes": [{"kind": "choice", "art": "beach", "prop": "🏖️", "speaker": "Piko", "text": "Stigli smo na plažu! Hoćemo prvo do mora ili do suncobrana?", "help": "Ti biraš.", "choices": [["🌊", "Do mora", "sea"], ["⛱️", "Do suncobrana", "umbrella"]]}, {"kind": "voice", "art": "shell", "prop": "🐚", "speaker": "Piko", "text": "Što si pronašla u pijesku?", "help": "Reci svojim riječima.", "concepts": ["školjk", "skoljk", "pijes", "biser"]}, {"kind": "spatial", "art": "basket", "prop": "🧺", "speaker": "Piko", "text": "Što je U košari?", "help": "Pogledaj unutra.", "choices": [["🍓", "Jagode", 1], ["🪁", "Zmaj za puštanje", 0], ["👒", "Šešir", 0]]}, {"kind": "sequence", "art": "seagull", "prop": "🐦", "speaker": "Galeb Gigi", "text": "Prvo sam vidio sendvič, onda poletio, pa ga zgrabio. Što je bilo drugo?", "help": "Što je bilo između prvog i zadnjeg?", "choices": [["👀", "Vidio sendvič", 0], ["🪽", "Poletio", 1], ["🥪", "Zgrabio sendvič", 0]]}, {"kind": "predict", "art": "wave", "prop": "🌊", "speaker": "Piko", "text": "Veliki val dolazi. Što misliš da će biti sa školjkom?", "help": "Reci što predviđaš."}, {"kind": "sound", "art": "fish", "prop": "🐟", "speaker": "Ribica", "text": "Koja riječ počinje glasom Rrrr?", "help": "Rrrr kao ribica.", "choices": [["🐟", "Riba", 1], ["🐱", "Maca", 0], ["🍌", "Banana", 0]]}, {"kind": "choice", "art": "pearl", "prop": "🌈", "speaker": "Piko", "text": "Školjka se otvorila. Što želiš da bude unutra?", "help": "Ti stvaraš dio priče.", "choices": [["💎", "Mali biser", "pearl"], ["🗺️", "Tajna karta", "map"]]}, {"kind": "retell", "art": "sunset", "prop": "🌅", "speaker": "Piko", "text": "Ispričaj mi kako je počela naša priča i što smo pronašli.", "help": "Počni od plaže."}]}, {"id": "teddy", "title": "Teddy prije spavanja", "icon": "🧸", "color": "pink", "sub": "Topla kuća, prostorni pojmovi i priča", "treasure": ["🧸", "Zvjezdani medo"], "level": 1, "scenes": [{"kind": "choice", "art": "bedroom", "prop": "🛏️", "speaker": "Piko", "text": "Vrijeme je za spavanje, ali medo je nestao! Gdje ćemo prvo tražiti?", "help": "Ti odlučuješ.", "choices": [["🛋️", "U dnevnoj sobi", "living"], ["🧺", "Kod košare", "basket"]]}, {"kind": "voice", "art": "laundry", "prop": "🧦", "speaker": "Piko", "text": "Što vidiš pored košare?", "help": "Reci samo što vidiš.", "concepts": ["čarap", "carap"]}, {"kind": "spatial", "art": "sofa", "prop": "🐱", "speaker": "Piko", "text": "Maca je iza kauča. Gdje je maca?", "help": "Iza, ispred ili na kauču?", "choices": [["↩️", "Iza kauča", 1], ["➡️", "Ispred kauča", 0], ["⬆️", "Na kauču", 0]]}, {"kind": "sequence", "art": "cards", "prop": "🧩", "speaker": "Piko", "text": "Što smo prvo napravili?", "help": "Prisjeti se početka.", "choices": [["🔎", "Krenuli tražiti medu", 1], ["🧸", "Pronašli medu", 0], ["😴", "Zaspali", 0]]}, {"kind": "predict", "art": "door", "prop": "🚪", "speaker": "Piko", "text": "Čujem zvuk iza vrata. Što misliš da je tamo?", "help": "Reci svoju ideju."}, {"kind": "sound", "art": "moon", "prop": "🌙", "speaker": "Medo", "text": "Koja riječ počinje kao Mmmm-medo?", "help": "Slušaj prvi glas.", "choices": [["🌙", "Mjesec", 1], ["🐶", "Pas", 0], ["🍓", "Jagoda", 0]]}, {"kind": "choice", "art": "bed", "prop": "🧸", "speaker": "Piko", "text": "Pronašla si medu! Gdje ćemo ga staviti?", "help": "Oba su odgovora dobra.", "choices": [["🛏️", "Pored jastuka", "beside"], ["🧺", "Ispod dekice", "under"]]}, {"kind": "retell", "art": "night", "prop": "⭐", "speaker": "Piko", "text": "Sada ti meni ispričaj kako smo pronašli medu.", "help": "Kreni od početka."}]}, {"id": "silly", "title": "Piko je sve pobrkao", "icon": "🤪", "color": "yellow", "sub": "Smiješna priča gdje TI ispravljaš Pika", "treasure": ["🎈", "Balon smijalica"], "level": 1, "scenes": [{"kind": "quiz", "art": "banana", "prop": "🍌", "speaker": "Piko", "text": "Ja znam! Banana se nosi na glavi, jel tako?", "help": "Ispravi Pika.", "choices": [["😂", "Ne, banana se jede!", 1], ["🎩", "Da, to je šešir!", 0]]}, {"kind": "predict", "art": "fishcar", "prop": "🚗", "speaker": "Piko", "text": "Riba vozi auto u moru! Što je ovdje smiješno ili čudno?", "help": "Ispričaj naglas."}, {"kind": "sequence", "art": "icecream", "prop": "🍦", "speaker": "Piko", "text": "Prvo sam pojeo sladoled, onda ga kupio. Je li to dobar redoslijed?", "help": "Što bi trebalo biti prvo?", "choices": [["🍦", "Prvo kupiš, onda jedeš", 1], ["🤷", "Prvo pojedeš, onda kupiš", 0]]}, {"kind": "spatial", "art": "shoes", "prop": "👟", "speaker": "Piko", "text": "Gdje idu cipele?", "help": "Odaberi.", "choices": [["🦶", "Na noge", 1], ["👂", "Na uši", 0], ["🍽️", "Na tanjur", 0]]}, {"kind": "sound", "art": "cat", "prop": "🐱", "speaker": "Piko", "text": "Koja riječ počinje glasom Mmmm?", "help": "Mmmm kao maca.", "choices": [["🐱", "Maca", 1], ["🐶", "Pas", 0], ["☀️", "Sunce", 0]]}, {"kind": "predict", "art": "frogcake", "prop": "🎂", "speaker": "Piko", "text": "Žaba je pronašla tortu. Što misliš da će sada napraviti?", "help": "Ti smišljaš."}, {"kind": "choice", "art": "balloons", "prop": "🎈", "speaker": "Piko", "text": "Izaberi najsmješniji završetak.", "help": "Nema krivog odgovora.", "choices": [["🎈", "Baloni polete s tortom", "balloon"], ["🐸", "Žaba zapjeva", "frog"]]}, {"kind": "retell", "art": "party", "prop": "😂", "speaker": "Piko", "text": "Ispričaj mi najsmješniji dio naše priče.", "help": "Možeš izabrati bilo koji dio."}]}, {"id": "bakery", "title": "Nestala rođendanska torta", "icon": "🎂", "color": "peach", "sub": "Tragovi, uzrok-posljedica i zabavni izbori", "treasure": ["🧁", "Zlatni cupcake"], "level": 2, "scenes": [{"kind": "choice", "art": "bakery", "prop": "🎂", "speaker": "Piko", "text": "Torta je nestala iz slastičarnice! Hoćemo pogledati mrvice ili vrata?", "help": "Ti odlučuješ.", "choices": [["🍪", "Pratimo mrvice", "crumbs"], ["🚪", "Provjerimo vrata", "door"]]}, {"kind": "voice", "art": "crumbs", "prop": "🍪", "speaker": "Piko", "text": "Što vidiš na podu?", "help": "Reci svojim riječima.", "concepts": ["mrv", "keks", "trag"]}, {"kind": "cause", "art": "window", "prop": "🌬️", "speaker": "Piko", "text": "Prozor je otvoren, a salvete su na podu. Zašto su pale?", "help": "Što ih je moglo otpuhati?", "choices": [["🌬️", "Vjetar ih je otpuhnuo", 1], ["🧁", "Cupcake ih je pozvao", 0], ["🪑", "Stolica ih je pojela", 0]]}, {"kind": "sequence", "art": "cards", "prop": "🧩", "speaker": "Piko", "text": "Što je bilo prvo?", "help": "Sjeti se početka.", "choices": [["🎂", "Primijetili smo da nema torte", 1], ["🍪", "Pronašli smo mrvice", 0], ["🎉", "Počela je zabava", 0]]}, {"kind": "predict", "art": "box", "prop": "📦", "speaker": "Piko", "text": "Čuje se šuškanje iz kutije. Što misliš da je unutra?", "help": "Reci svoju ideju."}, {"kind": "sound", "art": "cake", "prop": "🎂", "speaker": "Piko", "text": "Koja riječ počinje glasom Tttt?", "help": "Tttt kao torta.", "choices": [["🎂", "Torta", 1], ["🐱", "Maca", 0], ["🌙", "Mjesec", 0]]}, {"kind": "choice", "art": "party", "prop": "🎉", "speaker": "Piko", "text": "Našli smo tortu! Kako će završiti zabava?", "help": "Ti biraš.", "choices": [["🎈", "Ples s balonima", "dance"], ["🎵", "Rođendanska pjesma", "song"]]}, {"kind": "retell", "art": "cake", "prop": "🧁", "speaker": "Piko", "text": "Ispričaj kako smo pronašli tortu.", "help": "Pokušaj spomenuti barem dvije stvari."}]}, {"id": "rainbow", "title": "Jednorogova izgubljena duga", "icon": "🦄", "color": "rainbow", "sub": "Boje, slijed i male odluke", "treasure": ["🌈", "Dugin kamen"], "level": 2, "scenes": [{"kind": "choice", "art": "rainbow", "prop": "🦄", "speaker": "Lumi", "text": "Moja duga je nestala! Kamo ćemo prvo?", "help": "Ti vodiš potragu.", "choices": [["☁️", "Do oblaka", "cloud"], ["🌷", "Prema livadi", "meadow"]]}, {"kind": "voice", "art": "flowers", "prop": "🌷", "speaker": "Lumi", "text": "Što vidiš na livadi?", "help": "Reci jednu ili dvije stvari.", "concepts": ["cvijet", "trava", "livad", "leptir"]}, {"kind": "spatial", "art": "cloud", "prop": "☁️", "speaker": "Piko", "text": "Zvjezdica je iznad oblaka. Gdje je zvjezdica?", "help": "Pogledaj odnos zvjezdice i oblaka.", "choices": [["⬆️", "Iznad oblaka", 1], ["⬇️", "Ispod oblaka", 0], ["↔️", "Pored oblaka", 0]]}, {"kind": "sound", "art": "rose", "prop": "🌹", "speaker": "Lumi", "text": "Koja riječ počinje glasom Dddd?", "help": "Dddd kao duga.", "choices": [["🌈", "Duga", 1], ["🐱", "Maca", 0], ["🍌", "Banana", 0]]}, {"kind": "predict", "art": "rain", "prop": "🌧️", "speaker": "Piko", "text": "Sunce sja, a pada kiša. Što misliš da bi se moglo pojaviti?", "help": "Razmisli o nebu."}, {"kind": "sequence", "art": "cards", "prop": "🧩", "speaker": "Lumi", "text": "Što se dogodilo prije kiše?", "help": "Prisjeti se puta.", "choices": [["🌷", "Bili smo na livadi", 1], ["🌈", "Pronašli smo cijelu dugu", 0], ["🏠", "Otišli smo spavati", 0]]}, {"kind": "choice", "art": "rainbow", "prop": "🌈", "speaker": "Lumi", "text": "Duga se vratila! Koju boju želiš staviti na vrh?", "help": "Tvoj izbor.", "choices": [["💜", "Ljubičastu", "purple"], ["💗", "Ružičastu", "pink"]]}, {"kind": "retell", "art": "unicorn", "prop": "🦄", "speaker": "Lumi", "text": "Ispričaj mi kako smo vratili dugu.", "help": "Počni s tim gdje smo prvo tražili."}]}, {"id": "dino", "title": "Dinosaur koji se izgubio", "icon": "🦕", "color": "green", "sub": "Smjerovi, tragovi i mali dinosaur", "treasure": ["🦴", "Fosil prijateljstva"], "level": 2, "scenes": [{"kind": "choice", "art": "jungle", "prop": "🦕", "speaker": "Piko", "text": "Mali dinosaur ne zna put kući. Idemo lijevo ili desno?", "help": "Ti biraš put.", "choices": [["⬅️", "Lijevo prema rijeci", "left"], ["➡️", "Desno prema stijenama", "right"]]}, {"kind": "voice", "art": "footprints", "prop": "👣", "speaker": "Piko", "text": "Što vidimo na zemlji?", "help": "Reci svojim riječima.", "concepts": ["trag", "stop", "otis"]}, {"kind": "spatial", "art": "rock", "prop": "🪨", "speaker": "Piko", "text": "Jaje je između dvije stijene. Gdje je jaje?", "help": "Između znači u sredini.", "choices": [["↔️", "Između stijena", 1], ["⬆️", "Na stijeni", 0], ["⬇️", "Ispod obje stijene", 0]]}, {"kind": "cause", "art": "mud", "prop": "💦", "speaker": "Piko", "text": "Dinosaur je sav blatnjav. Zašto?", "help": "Pogledaj lokvu.", "choices": [["💦", "Stao je u blatnu lokvu", 1], ["☀️", "Sunce ga je obojilo", 0], ["🎈", "Balon ga je zaprljao", 0]]}, {"kind": "sound", "art": "dino", "prop": "🦕", "speaker": "Dino", "text": "Koja riječ počinje kao Dddd-dinosaur?", "help": "Slušaj prvi glas.", "choices": [["🏠", "Dom", 1], ["🐱", "Maca", 0], ["🌊", "More", 0]]}, {"kind": "predict", "art": "cave", "prop": "🕳️", "speaker": "Piko", "text": "Iz špilje čujemo tiho roaar. Tko bi mogao biti unutra?", "help": "Reci što misliš."}, {"kind": "choice", "art": "family", "prop": "🦖", "speaker": "Dino", "text": "Pronašli smo njegovu obitelj! Što ćemo sada?", "help": "Ti biraš završetak.", "choices": [["🥳", "Napravimo ples dinosaura", "dance"], ["🍃", "Pojedimo veliki list", "leaf"]]}, {"kind": "retell", "art": "sunset", "prop": "🦕", "speaker": "Piko", "text": "Ispričaj kako smo pomogli dinosauru pronaći dom.", "help": "Pokušaj se sjetiti tragova."}]}, {"id": "space", "title": "Mala raketa na Mjesecu", "icon": "🚀", "color": "navy", "sub": "Planiranje, predviđanje i svemirska priča", "treasure": ["🌙", "Mjesečev kamen"], "level": 2, "scenes": [{"kind": "choice", "art": "rocket", "prop": "🚀", "speaker": "Piko", "text": "Raketa je spremna! Hoćemo prvo provjeriti gorivo ili kacigu?", "help": "Ti vodiš pripremu.", "choices": [["⛽", "Provjeri gorivo", "fuel"], ["🪖", "Provjeri kacigu", "helmet"]]}, {"kind": "sequence", "art": "launch", "prop": "3️⃣", "speaker": "Piko", "text": "Što ide prije polijetanja?", "help": "Razmisli što trebamo prije nego raketa krene.", "choices": [["🪖", "Staviti kacigu", 1], ["🌙", "Sletjeti na Mjesec", 0], ["⭐", "Vidjeti zvijezde", 0]]}, {"kind": "voice", "art": "space", "prop": "⭐", "speaker": "Piko", "text": "Što vidiš kroz prozor rakete?", "help": "Reci jednu stvar.", "concepts": ["zvijezd", "mjesec", "planet", "svemir"]}, {"kind": "sound", "art": "rocket", "prop": "🚀", "speaker": "Piko", "text": "Koja riječ počinje glasom Rrrr?", "help": "Rrrr kao raketa.", "choices": [["🚀", "Raketa", 1], ["🐶", "Pas", 0], ["🍓", "Jagoda", 0]]}, {"kind": "predict", "art": "moon", "prop": "🌙", "speaker": "Piko", "text": "Na Mjesecu vidimo sjaj iza stijene. Što misliš da je tamo?", "help": "Reci svoju ideju."}, {"kind": "spatial", "art": "moonrock", "prop": "🪨", "speaker": "Piko", "text": "Mali kamen je pored velikog kamena. Gdje je mali kamen?", "help": "Pored znači tik uz.", "choices": [["↔️", "Pored velikog kamena", 1], ["⬆️", "Na velikom kamenu", 0], ["⬇️", "Ispod tla", 0]]}, {"kind": "choice", "art": "alien", "prop": "👽", "speaker": "Mali vanzemaljac", "text": "Bok! Želiš li plesati ili mi pokazati raketu?", "help": "Oba izbora su dobra.", "choices": [["💃", "Ples", "dance"], ["🚀", "Pokaži raketu", "show"]]}, {"kind": "retell", "art": "earth", "prop": "🌍", "speaker": "Piko", "text": "Ispričaj kako smo stigli do Mjeseca.", "help": "Počni od pripreme rakete."}]}, {"id": "farm", "title": "Tko je otvorio vrata farme?", "icon": "🐮", "color": "cream", "sub": "Životinje, uzrok-posljedica i tragovi", "treasure": ["🔔", "Zlatno zvonce"], "level": 2, "scenes": [{"kind": "choice", "art": "farm", "prop": "🚪", "speaker": "Piko", "text": "Vrata farme su otvorena. Gdje ćemo prvo pogledati?", "help": "Ti odlučuješ.", "choices": [["🐔", "Kod kokoši", "hens"], ["🐮", "Kod krave", "cow"]]}, {"kind": "voice", "art": "feather", "prop": "🪶", "speaker": "Piko", "text": "Što smo pronašli kraj vrata?", "help": "Reci što vidiš.", "concepts": ["pero", "perje"]}, {"kind": "cause", "art": "gate", "prop": "💨", "speaker": "Piko", "text": "Vrata se ljuljaju, a jako puše. Što ih možda pomiče?", "help": "Razmisli o vjetru.", "choices": [["💨", "Vjetar", 1], ["🥕", "Mrkva", 0], ["🐟", "Riba", 0]]}, {"kind": "sound", "art": "cow", "prop": "🐮", "speaker": "Krava", "text": "Koja riječ počinje glasom Kkkk?", "help": "Kkkk kao krava.", "choices": [["🐮", "Krava", 1], ["🐶", "Pas", 0], ["🌙", "Mjesec", 0]]}, {"kind": "spatial", "art": "hay", "prop": "🐥", "speaker": "Piko", "text": "Pile je na sijenu. Gdje je pile?", "help": "Pogledaj gdje stoji.", "choices": [["⬆️", "Na sijenu", 1], ["⬇️", "Ispod sijena", 0], ["↔️", "Pored štale", 0]]}, {"kind": "predict", "art": "barn", "prop": "🏚️", "speaker": "Piko", "text": "Iz štale čujemo muu i kuc-kuc. Što misliš da se događa?", "help": "Reci svoju ideju."}, {"kind": "choice", "art": "animals", "prop": "🐮", "speaker": "Piko", "text": "Sve životinje su na sigurnom. Kako završava priča?", "help": "Ti biraš.", "choices": [["🎵", "Životinje zapjevaju", "song"], ["🍎", "Dobiju jabuke", "apples"]]}, {"kind": "retell", "art": "farm", "prop": "🔔", "speaker": "Piko", "text": "Ispričaj kako smo otkrili što se dogodilo na farmi.", "help": "Prisjeti se pera i vrata."}]}, {"id": "snow", "title": "Snježna staza", "icon": "⛄", "color": "ice", "sub": "Zimska avantura i prostorni pojmovi", "treasure": ["❄️", "Snježna zvijezda"], "level": 2, "scenes": [{"kind": "choice", "art": "snow", "prop": "⛄", "speaker": "Piko", "text": "Netko je ostavio tragove u snijegu. Kamo vode?", "help": "Izaberi kamo ćemo.", "choices": [["🌲", "Prema borovima", "pines"], ["🏠", "Prema kućici", "cabin"]]}, {"kind": "voice", "art": "snowtracks", "prop": "👣", "speaker": "Piko", "text": "Što vidiš u snijegu?", "help": "Reci svojim riječima.", "concepts": ["trag", "otis", "stop"]}, {"kind": "spatial", "art": "snowman", "prop": "🧣", "speaker": "Piko", "text": "Šal je oko vrata snjegovića. Gdje je šal?", "help": "Pogledaj snjegovića.", "choices": [["🧣", "Oko vrata", 1], ["⬇️", "Ispod njega", 0], ["⬆️", "Iznad glave", 0]]}, {"kind": "sound", "art": "snow", "prop": "❄️", "speaker": "Piko", "text": "Koja riječ počinje glasom Ssss?", "help": "Ssss kao snijeg.", "choices": [["❄️", "Snijeg", 1], ["🐱", "Maca", 0], ["🍌", "Banana", 0]]}, {"kind": "predict", "art": "cabin", "prop": "🏠", "speaker": "Piko", "text": "Dim izlazi iz dimnjaka. Što misliš da se događa unutra?", "help": "Reci što misliš."}, {"kind": "sequence", "art": "cards", "prop": "🧩", "speaker": "Piko", "text": "Što smo pronašli prije kućice?", "help": "Pogledaj trag priče.", "choices": [["👣", "Tragove u snijegu", 1], ["🎂", "Tortu", 0], ["🚀", "Raketu", 0]]}, {"kind": "choice", "art": "cocoa", "prop": "☕", "speaker": "Piko", "text": "Pronašli smo toplu kućicu! Što ćemo?", "help": "Ti biraš.", "choices": [["☕", "Topli kakao", "cocoa"], ["🛷", "Još malo sanjkanja", "sled"]]}, {"kind": "retell", "art": "snow", "prop": "❄️", "speaker": "Piko", "text": "Ispričaj mi našu snježnu pustolovinu.", "help": "Počni od tragova u snijegu."}]}, {"id": "garden", "title": "Tajna malog vrta", "icon": "🐞", "color": "green", "sub": "Bubamare, skriveni predmeti i priča", "treasure": ["🐞", "Bubamarina značka"], "level": 2, "scenes": [{"kind": "choice", "art": "garden", "prop": "🐞", "speaker": "Piko", "text": "Bubamara je izgubila točkicu. Gdje ćemo je tražiti?", "help": "Ti biraš.", "choices": [["🌼", "Kod cvijeća", "flowers"], ["🪴", "Ispod teglice", "pot"]]}, {"kind": "spatial", "art": "pot", "prop": "🔴", "speaker": "Piko", "text": "Crvena točkica je ispod lista. Gdje je?", "help": "Pogledaj list.", "choices": [["⬇️", "Ispod lista", 1], ["⬆️", "Iznad lista", 0], ["↔️", "Pored ograde", 0]]}, {"kind": "voice", "art": "garden", "prop": "🌼", "speaker": "Piko", "text": "Što sve vidiš u vrtu?", "help": "Reci barem jednu stvar.", "concepts": ["cvijet", "list", "trava", "bubamar", "vrt"]}, {"kind": "sound", "art": "ladybug", "prop": "🐞", "speaker": "Bubamara", "text": "Koja riječ počinje glasom Bbbb?", "help": "Bbbb kao bubamara.", "choices": [["🐞", "Bubamara", 1], ["🐶", "Pas", 0], ["🌙", "Mjesec", 0]]}, {"kind": "cause", "art": "watering", "prop": "💧", "speaker": "Piko", "text": "Zemlja je mokra. Zašto?", "help": "Pogledaj kanticu.", "choices": [["💧", "Netko je zalijevao", 1], ["☀️", "Sunce ju je smočilo", 0], ["🎈", "Balon je pustio vodu", 0]]}, {"kind": "predict", "art": "leaf", "prop": "🍃", "speaker": "Piko", "text": "Nešto se miče ispod lista. Što misliš da je tamo?", "help": "Reci svoju ideju."}, {"kind": "choice", "art": "ladybug", "prop": "🐞", "speaker": "Bubamara", "text": "Pronašli smo točkicu! Gdje je staviti?", "help": "Ti biraš.", "choices": [["❤️", "Na bubamarina leđa", "back"], ["🎁", "U malu kutijicu", "box"]]}, {"kind": "retell", "art": "garden", "prop": "🌼", "speaker": "Piko", "text": "Ispričaj kako smo pomogli bubamari.", "help": "Prisjeti se gdje smo tražili."}]}, {"id": "castle", "title": "Vrata malog dvorca", "icon": "🏰", "color": "lavender", "sub": "Ključevi, sobe i mala misterija", "treasure": ["👑", "Zvjezdana krunica"], "level": 3, "scenes": [{"kind": "choice", "art": "castle", "prop": "🏰", "speaker": "Piko", "text": "Dvorac ima dvoja vrata. Koja ćemo otvoriti?", "help": "Ti biraš put.", "choices": [["💜", "Ljubičasta vrata", "purple"], ["💚", "Zelena vrata", "green"]]}, {"kind": "voice", "art": "hall", "prop": "🕯️", "speaker": "Piko", "text": "Što vidiš u velikom hodniku?", "help": "Reci jednu stvar.", "concepts": ["svijeć", "tepih", "slik", "vrat", "hodnik"]}, {"kind": "sequence", "art": "cards", "prop": "🧩", "speaker": "Piko", "text": "Što smo napravili prije ulaska u hodnik?", "help": "Prisjeti se vrata.", "choices": [["🚪", "Odabrali vrata", 1], ["👑", "Pronašli krunu", 0], ["😴", "Otišli spavati", 0]]}, {"kind": "spatial", "art": "tablekey", "prop": "🔑", "speaker": "Piko", "text": "Ključ je na stolu između dvije knjige. Gdje je ključ?", "help": "Između znači u sredini.", "choices": [["↔️", "Između knjiga", 1], ["⬇️", "Ispod stola", 0], ["⬆️", "Na prozoru", 0]]}, {"kind": "cause", "art": "candle", "prop": "🕯️", "speaker": "Piko", "text": "Svijeća se ugasila kad smo otvorili prozor. Zašto?", "help": "Što dolazi kroz otvoreni prozor?", "choices": [["💨", "Vjetar", 1], ["🍰", "Torta", 0], ["🐟", "Riba", 0]]}, {"kind": "predict", "art": "chest", "prop": "🧰", "speaker": "Piko", "text": "U staroj škrinji nešto zvecka. Što misliš da je unutra?", "help": "Reci svoju ideju."}, {"kind": "choice", "art": "crown", "prop": "👑", "speaker": "Piko", "text": "Pronašli smo malu krunu. Kome je dati?", "help": "Ti odlučuješ.", "choices": [["🦊", "Piku", "piko"], ["👧🏻", "Tebi", "me"]]}, {"kind": "retell", "art": "castle", "prop": "🏰", "speaker": "Piko", "text": "Ispričaj našu dvorac-priču od početka.", "help": "Pokušaj se sjetiti barem tri stvari."}]}, {"id": "picnic", "title": "Piknik koji je pobjegao", "icon": "🧺", "color": "peach", "sub": "Vjetar, predmeti i smiješan kraj", "treasure": ["🍓", "Jagodna medalja"], "level": 3, "scenes": [{"kind": "choice", "art": "picnic", "prop": "🧺", "speaker": "Piko", "text": "Vjetar je odnio salvetu! Hoćemo prvo uhvatiti salvetu ili spremiti hranu?", "help": "Ti biraš.", "choices": [["🧻", "Uhvatimo salvetu", "napkin"], ["🧺", "Spremimo hranu", "food"]]}, {"kind": "cause", "art": "wind", "prop": "💨", "speaker": "Piko", "text": "Zašto salveta leti?", "help": "Pogledaj travu i oblake.", "choices": [["💨", "Puše vjetar", 1], ["🍓", "Jagode je guraju", 0], ["🪨", "Kamen je puše", 0]]}, {"kind": "voice", "art": "picnic", "prop": "🍓", "speaker": "Piko", "text": "Što vidiš na dekici?", "help": "Reci barem jednu stvar.", "concepts": ["jagod", "sendvič", "sendvic", "sok", "voć", "voc"]}, {"kind": "spatial", "art": "basket", "prop": "🥪", "speaker": "Piko", "text": "Sendvič je pored košare. Gdje je sendvič?", "help": "Pogledaj položaj.", "choices": [["↔️", "Pored košare", 1], ["⬇️", "Ispod košare", 0], ["⬆️", "Na stablu", 0]]}, {"kind": "sound", "art": "strawberry", "prop": "🍓", "speaker": "Piko", "text": "Koja riječ počinje glasom Jjjj?", "help": "Jjjj kao jagoda.", "choices": [["🍓", "Jagoda", 1], ["🐱", "Maca", 0], ["🚗", "Auto", 0]]}, {"kind": "predict", "art": "ant", "prop": "🐜", "speaker": "Piko", "text": "Mrav ide prema mrvicama. Što misliš da će napraviti?", "help": "Reci što predviđaš."}, {"kind": "choice", "art": "kite", "prop": "🪁", "speaker": "Piko", "text": "Vjetar je jak. Hoćemo pustiti zmaja ili se vratiti na dekicu?", "help": "Ti vodiš završetak.", "choices": [["🪁", "Pustimo zmaja", "kite"], ["🧺", "Nazad na piknik", "picnic"]]}, {"kind": "retell", "art": "picnic", "prop": "🧺", "speaker": "Piko", "text": "Ispričaj što se dogodilo na pikniku.", "help": "Prisjeti se vjetra i salvete."}]}];

const App = (() => {
  const $ = s => document.querySelector(s);
  const screens = [...document.querySelectorAll('.screen')];

  const savedSkills = JSON.parse(localStorage.getItem('magic_skills') || '{}');
  const defaults = {sequence:0,spatial:0,sound:0,voice:0,predict:0,cause:0,retell:0};
  const state = {
    name: localStorage.getItem('magic_name') || 'Megan',
    stars: Number(localStorage.getItem('magic_stars') || 0),
    treasures: JSON.parse(localStorage.getItem('magic_treasures') || '[]'),
    completed: JSON.parse(localStorage.getItem('magic_completed') || '[]'),
    sound: localStorage.getItem('magic_sound') !== 'off',
    skills: Object.assign({}, defaults, savedSkills),
    adventureId: localStorage.getItem('magic_last_adventure') || 'forest',
    step: 0, help: 0, runStars: 0, trail: [], lastText: '', branch: null,
    streak: 0, attemptsThisScene: 0
  };

  const A = id => ADVENTURES.find(a=>a.id===id) || ADVENTURES[0];

  function persist(){
    localStorage.setItem('magic_name',state.name);
    localStorage.setItem('magic_stars',String(state.stars));
    localStorage.setItem('magic_treasures',JSON.stringify(state.treasures));
    localStorage.setItem('magic_completed',JSON.stringify(state.completed));
    localStorage.setItem('magic_sound',state.sound?'on':'off');
    localStorage.setItem('magic_skills',JSON.stringify(state.skills));
    localStorage.setItem('magic_last_adventure',state.adventureId);
  }

  function show(id){
    screens.forEach(s=>s.classList.toggle('active',s.id===id));
    window.scrollTo({top:0,behavior:'smooth'});
  }

  function speak(text){
    state.lastText=text;
    if(!state.sound) return;
    const cleaned=text.replace(/[✨⭐🌲🦊🐾🧩🔑🐉🌙🚪🐚🧸🤪😂🎈🎂🦄🦕🚀🐮⛄🐞🏰🧺]/g,'');
    try{
      if(window.AndroidNative && AndroidNative.speak){ AndroidNative.speak(cleaned); return; }
      if('speechSynthesis' in window){
        speechSynthesis.cancel();
        const u=new SpeechSynthesisUtterance(cleaned);
        u.lang='hr-HR';u.rate=.89;u.pitch=1.03;u.volume=1;
        speechSynthesis.speak(u);
      }
    }catch(e){}
  }

  function toast(msg){
    const t=$('#toast'); t.textContent=msg; t.classList.add('show');
    clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.classList.remove('show'),1250);
  }

  function skillKey(kind){
    if(kind==='sequence') return 'sequence';
    if(kind==='spatial') return 'spatial';
    if(kind==='sound') return 'sound';
    if(kind==='voice') return 'voice';
    if(kind==='predict') return 'predict';
    if(kind==='cause') return 'cause';
    if(kind==='retell') return 'retell';
    return null;
  }

  function bumpSkill(kind,amount){
    const k=skillKey(kind); if(!k) return;
    state.skills[k]=Math.max(0,Math.min(12,(state.skills[k]||0)+amount));
  }

  function updateHeader(){
    $('#starCount').textContent=state.stars;
    $('#welcomeTitle').textContent=`Bok, ${state.name} ✨`;
    $('#soundToggle').textContent=state.sound?'🔊':'🔇';
    $('#completedCount').textContent=new Set(state.completed).size;
    $('#treasureCount').textContent=state.treasures.length;
    const avg=Object.values(state.skills).reduce((a,b)=>a+b,0)/Object.keys(state.skills).length;
    $('#skillLevel').textContent=avg>=7?'Istraživač':avg>=3?'Pripovjedač':'Početnik';
  }

  function wash(level){
    return level===1?'#f3eefb':level===2?'#eef6f4':'#f7f0eb';
  }

  function renderHome(){
    const grid=$('#adventureGrid'); grid.innerHTML='';
    ADVENTURES.forEach(a=>{
      const b=document.createElement('button');b.className='adventure';b.type='button';b.style.setProperty('--wash',wash(a.level));
      b.innerHTML=`<span class="adv-icon">${a.icon}</span><div class="adv-level">RAZINA ${a.level}</div><div class="adv-title">${a.title}</div><div class="adv-sub">${a.sub}</div><span class="adv-arrow">→</span>`;
      b.addEventListener('click',()=>startAdventure(a.id)); grid.appendChild(b);
    });
    updateHeader();
  }

  function startAdventure(id){
    state.adventureId=id;state.step=0;state.help=0;state.runStars=0;state.trail=[];state.branch=null;state.streak=0;state.attemptsThisScene=0;
    persist();show('gameScreen');renderScene();
  }

  function current(){ return A(state.adventureId).scenes[state.step]; }

  function artEmoji(art){
    const map={
      forest:'🌲',tracks:'🐾',cards:'🧩',bench:'🪑',dragon:'🐉',door:'🚪',magicdoor:'✨',star:'⭐',
      beach:'🏖️',shell:'🐚',basket:'🧺',seagull:'🐦',wave:'🌊',fish:'🐟',pearl:'💎',sunset:'🌅',
      bedroom:'🛏️',laundry:'🧦',sofa:'🛋️',moon:'🌙',bed:'🛏️',night:'🌙',
      banana:'🍌',fishcar:'🐟',icecream:'🍦',shoes:'👟',cat:'🐱',frogcake:'🐸',balloons:'🎈',party:'🎉',
      bakery:'🏪',crumbs:'🍪',window:'🪟',box:'📦',cake:'🎂',
      rainbow:'🌈',flowers:'🌷',cloud:'☁️',rose:'🌹',rain:'🌧️',unicorn:'🦄',
      jungle:'🌿',footprints:'👣',rock:'🪨',mud:'💦',dino:'🦕',cave:'🕳️',family:'🦖',
      rocket:'🚀',launch:'🔥',space:'⭐',moonrock:'🪨',alien:'👽',earth:'🌍',
      farm:'🚜',feather:'🪶',gate:'🚪',cow:'🐮',hay:'🌾',barn:'🏚️',animals:'🐮',
      snow:'❄️',snowtracks:'👣',snowman:'⛄',cabin:'🏠',cocoa:'☕',
      garden:'🌼',pot:'🪴',ladybug:'🐞',watering:'💧',leaf:'🍃',
      castle:'🏰',hall:'🕯️',tablekey:'🔑',candle:'🕯️',chest:'🧰',crown:'👑',
      picnic:'🧺',wind:'💨',strawberry:'🍓',ant:'🐜',kite:'🪁'
    }; return map[art]||'✨';
  }

  function renderScene(){
    const a=A(state.adventureId), s=current();
    state.attemptsThisScene=0;
    $('#adventureName').textContent=a.title;
    $('#progressText').textContent=`${state.step+1} / ${a.scenes.length}`;
    $('#progressBar').style.width=`${((state.step+1)/a.scenes.length)*100}%`;
    $('#artProp').textContent=s.prop||a.icon;
    $('#sceneObject').textContent=artEmoji(s.art);
    $('#speakerName').textContent=s.speaker||'Piko';
    $('#speakerAvatar').textContent=s.speaker==='Piko'?'🦊':(s.prop||'✨');
    const text=s.text.replaceAll('{name}',state.name);
    $('#promptText').textContent=text;
    $('#helperText').textContent=s.help||'';
    $('#adaptiveHint').classList.add('hidden');
    state.trail.push(s.prop||a.icon); renderTrail();

    const choices=$('#choiceArea');choices.innerHTML='';
    const isVoice=['voice','predict','retell'].includes(s.kind);
    $('#voiceArea').classList.toggle('hidden',!isVoice);
    $('#heardBox').classList.add('hidden');
    $('#parentControls').classList.add('hidden');
    $('#heardText').textContent='';

    if(s.choices){
      let options=s.choices.slice();
      const k=skillKey(s.kind);
      if(k && state.skills[k]<2 && options.length>2 && s.kind!=='choice') options=options.slice(0,2);
      options.forEach(ch=>{
        const [ico,label,val]=ch;
        const b=document.createElement('button');b.className='choice-btn';b.type='button';
        b.innerHTML=`<span class="ico">${ico}</span><span>${label}</span>`;
        b.addEventListener('click',()=>handleChoice(val,b));
        choices.appendChild(b);
      });
    }
    speak(text);
  }

  function renderTrail(){
    const el=$('#storyTrail');el.innerHTML='';
    state.trail.forEach((x,i)=>{const d=document.createElement('div');d.className='trail-item'+(i===state.trail.length-1?' current':'');d.textContent=x;el.appendChild(d)});
    el.scrollLeft=el.scrollWidth;
  }

  function good(kind){
    state.runStars++;state.stars++;state.streak++;bumpSkill(kind,1);
    persist();updateHeader();toast(state.streak>=3?'Bravo! Tri super odgovora zaredom! 🌟':'Bravo! ⭐');
  }

  function handleChoice(val,btn){
    const s=current();
    if(val===1){
      btn.classList.add('correct-flash');good(s.kind);setTimeout(next,260);return;
    }
    if(val===0){
      state.help++;state.streak=0;state.attemptsThisScene++;bumpSkill(s.kind,-0.2);
      btn.classList.add('wrong-flash');setTimeout(()=>btn.classList.remove('wrong-flash'),320);
      if(state.attemptsThisScene===1){
        $('#helperText').textContent='Hmm… pogledaj još jednom. Nema žurbe.';
        speak('Hmm, pogledaj još jednom. Nema žurbe.');
      }else{
        $('#adaptiveHint').textContent='💡 Piko daje veći trag: probaj odgovor koji najbolje odgovara slici ili događaju.';
        $('#adaptiveHint').classList.remove('hidden');
        speak('Piko ima trag za tebe. Pogledaj sliku još jednom.');
      }
      return;
    }
    state.branch=val;good(s.kind);setTimeout(next,220);
  }

  function next(){
    const a=A(state.adventureId);state.step++;
    if(state.step>=a.scenes.length){finishAdventure();return}
    setTimeout(renderScene,140);
  }

  function finishAdventure(){
    const a=A(state.adventureId), [emoji,name]=a.treasure;
    if(!state.treasures.some(x=>x.name===name)) state.treasures.push({emoji,name,date:new Date().toISOString()});
    state.completed.push(a.id);persist();updateHeader();
    $('#rewardOrb').textContent=emoji;$('#treasureEmoji').textContent=emoji;$('#treasureName').textContent=name;
    $('#rewardTitle').textContent=`Jeeeej, ${state.name}!`;
    $('#rewardText').textContent='Dovršila si cijelu pustolovinu, pomogla likovima i osvojila novo čarobno blago.';
    $('#earnedStars').textContent=state.runStars;$('#thinkingResult').textContent=state.help<=1?'Odlično':state.help<=3?'Super':'Uporna!';
    const strip=$('#finalStoryStrip');strip.innerHTML='';state.trail.forEach(x=>{const sp=document.createElement('span');sp.textContent=x;strip.appendChild(sp)});
    makeConfetti();show('rewardScreen');speak(`Jeeeej, ${state.name}! Uspjela si!`);
  }

  function makeConfetti(){
    const c=$('#confetti');c.innerHTML='';const sy=['✨','⭐','🎈','💫','🎉'];
    for(let i=0;i<24;i++){const s=document.createElement('span');s.textContent=sy[i%sy.length];s.style.left=(2+(i*4.1)%95)+'%';s.style.animationDelay=((i%7)*.07)+'s';c.appendChild(s)}
  }

  function renderTreasures(){
    const shelf=$('#treasureShelf');shelf.innerHTML='';
    $('#emptyTreasure').classList.toggle('hidden',state.treasures.length>0);
    state.treasures.forEach(t=>{const d=document.createElement('div');d.className='treasure-item';d.innerHTML=`<div class="bigemoji">${t.emoji}</div><b>${t.name}</b><small>Osvojeno</small>`;shelf.appendChild(d)});
  }

  function renderParent(){
    const unique=new Set(state.completed).size;
    $('#parentSummary').innerHTML=`
      <div class="summary-card"><b>${unique} / ${ADVENTURES.length}</b><small>različitih priča završeno</small></div>
      <div class="summary-card"><b>${state.stars}</b><small>ukupno zvjezdica</small></div>
      <div class="summary-card"><b>${state.treasures.length}</b><small>prikupljenih blaga</small></div>
      <div class="summary-card"><b>${state.completed.length}</b><small>ukupnih odigranih priča</small></div>`;
    const labels={
      sequence:['🧩','Redoslijed','prvo, zatim, zadnje'],
      spatial:['📍','Prostorni pojmovi','ispod, iza, pored, između'],
      sound:['🎵','Fonološka svjesnost','početni glas riječi'],
      voice:['🗣️','Opisivanje','opis slike vlastitim riječima'],
      predict:['💭','Predviđanje','što bi se moglo dogoditi'],
      cause:['🔗','Uzrok i posljedica','zašto se nešto dogodilo'],
      retell:['📖','Prepričavanje','prisjećanje tijeka priče']
    };
    const grid=$('#skillGrid');grid.innerHTML='';
    Object.entries(labels).forEach(([k,[ico,title,sub]])=>{
      const score=Math.round((state.skills[k]||0)/12*100);
      const d=document.createElement('div');d.className='skill-card';
      d.innerHTML=`<div class="skill-icon">${ico}</div><div><b>${title}</b><small>${sub}</small></div><div class="skill-meter"><i style="width:${score}%"></i></div>`;
      grid.appendChild(d);
    });
  }

  window.__nativeSpeechResult = function(best, alternativesJson){
    let texts=[best||''];
    try{
      const alts=JSON.parse(alternativesJson||'[]');
      if(Array.isArray(alts)) texts=texts.concat(alts);
    }catch(e){}
    $('#heardText').textContent=best||'';
    $('#heardBox').classList.remove('hidden');
    const s=current();
    if(s.kind==='predict'||s.kind==='retell'){
      if((best||'').trim().length>0){good(s.kind);setTimeout(next,450)}
      else $('#parentControls').classList.remove('hidden');
      return;
    }
    if(s.kind==='voice'){
      if(conceptMatch(texts,s.concepts||[])){good('voice');setTimeout(next,450)}
      else{$('#parentControls').classList.remove('hidden');toast('Možda nisam dobro razumjela 🤔')}
    }
  };

  window.__nativeSpeechError = function(){
    toast('Nisam dobro čula. Probaj opet 🎤');
    $('#parentControls').classList.remove('hidden');
  };

  // Speech recognition: semantic-ish concept matching + generous fallback
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  let recognition=null,listening=false;
  function normalize(t){return (t||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zčćžšđ0-9 ]/gi,' ')}
  function conceptMatch(texts,concepts){
    const normTexts=texts.map(normalize);
    return (concepts||[]).some(raw=>{
      const c=normalize(raw);
      return normTexts.some(t=>t.includes(c) || t.split(/\s+/).some(w=>w.startsWith(c.slice(0,Math.min(4,c.length)))));
    });
  }

  if(SR){
    recognition=new SR();recognition.lang='hr-HR';recognition.interimResults=false;recognition.maxAlternatives=4;
    recognition.onstart=()=>{listening=true;$('#micBtn').classList.add('listening');$('#micLabel').textContent='Slušam…'};
    recognition.onend=()=>{listening=false;$('#micBtn').classList.remove('listening');$('#micLabel').textContent='Pritisni i reci'};
    recognition.onerror=()=>{toast('Nisam dobro čula. Probaj opet 🎤');$('#parentControls').classList.remove('hidden')};
    recognition.onresult=e=>{
      const texts=[...e.results[0]].map(x=>x.transcript);
      const best=texts[0]||'';
      $('#heardText').textContent=best;$('#heardBox').classList.remove('hidden');
      const s=current();
      if(s.kind==='predict'||s.kind==='retell'){
        if(best.trim().split(/\s+/).length>=1){good(s.kind);setTimeout(next,450)} else $('#parentControls').classList.remove('hidden');
        return;
      }
      if(s.kind==='voice'){
        if(conceptMatch(texts,s.concepts||[])){good('voice');setTimeout(next,450)}
        else{$('#parentControls').classList.remove('hidden');toast('Možda nisam dobro razumjela 🤔')}
      }
    };
  }

  $('#micBtn').addEventListener('click',()=>{
    if(window.AndroidNative && AndroidNative.startListening){
      try{ AndroidNative.startListening(); $('#micBtn').classList.add('listening'); $('#micLabel').textContent='Slušam…'; return; }catch(e){}
    }
    if(!recognition){toast('Glasovno prepoznavanje ovdje nije dostupno. Mama može potvrditi odgovor.');$('#parentControls').classList.remove('hidden');return}
    try{listening?recognition.stop():recognition.start()}catch(e){$('#parentControls').classList.remove('hidden')}
  });
  $('#parentPass').addEventListener('click',()=>{good(current().kind);next()});
  $('#parentHelp').addEventListener('click',()=>{
    state.help++;state.streak=0;bumpSkill(current().kind,-0.1);
    $('#adaptiveHint').textContent='💡 Piko pomaže: reci samo jednu važnu stvar koju vidiš ili čega se sjećaš.';
    $('#adaptiveHint').classList.remove('hidden');speak($('#adaptiveHint').textContent);
  });

  $('#continueBtn').addEventListener('click',()=>startAdventure(state.adventureId));
  $('#randomBtn').addEventListener('click',()=>startAdventure(ADVENTURES[Math.floor(Math.random()*ADVENTURES.length)].id));
  $('#backHome').addEventListener('click',()=>{if('speechSynthesis'in window)speechSynthesis.cancel();show('homeScreen')});
  $('#repeatBtn').addEventListener('click',()=>speak(state.lastText));
  $('#soundToggle').addEventListener('click',()=>{state.sound=!state.sound;if(!state.sound){try{if(window.AndroidNative&&AndroidNative.stopSpeaking)AndroidNative.stopSpeaking();else if('speechSynthesis'in window)speechSynthesis.cancel()}catch(e){}}persist();updateHeader()});
  $('#treasureBtn').addEventListener('click',()=>{renderTreasures();show('treasureScreen')});
  $('#treasureBack').addEventListener('click',()=>show('homeScreen'));
  $('#againBtn').addEventListener('click',()=>{renderHome();show('homeScreen')});
  $('#replayBtn').addEventListener('click',()=>startAdventure(state.adventureId));
  $('#profileBtn').addEventListener('click',()=>{$('#nameInput').value=state.name;$('#profileModal').classList.remove('hidden')});
  $('#closeProfile').addEventListener('click',()=>$('#profileModal').classList.add('hidden'));
  $('#profileForm').addEventListener('submit',e=>{e.preventDefault();const v=$('#nameInput').value.trim().slice(0,18);if(!v)return;state.name=v;persist();updateHeader();$('#profileModal').classList.add('hidden')});
  $('#parentBtn').addEventListener('click',()=>{renderParent();show('parentScreen')});
  $('#parentBack').addEventListener('click',()=>show('homeScreen'));
  $('#resetProgress').addEventListener('click',()=>{
    const ok=confirm('Poništiti sve zvjezdice, blago i napredak? Ime će ostati spremljeno.');
    if(!ok)return;
    state.stars=0;state.treasures=[];state.completed=[];state.skills={...defaults};persist();renderParent();updateHeader();toast('Napredak je poništen.');
  });
  $('#shareBtn').addEventListener('click',async()=>{
    const data={title:'Čarobne priče',text:`Pogledaj ${state.name}inu igru priča!`,url:location.href};
    if(navigator.share){try{await navigator.share(data)}catch(e){}}
    else{toast('Podijeli adresu ove stranice iz preglednika ↗')}
  });

  updateHeader();renderHome();show('homeScreen');
  return {};
})();

if('serviceWorker' in navigator){
  window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
}
