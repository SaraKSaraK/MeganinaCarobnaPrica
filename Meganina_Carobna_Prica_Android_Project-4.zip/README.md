# Meganina Čarobna Priča — Android

Native Android wrapper around the Deluxe game.

## What is native in this build
- Android TextToSpeech (Croatian)
- Android SpeechRecognizer (Croatian)
- RECORD_AUDIO runtime permission
- all game HTML/CSS/JS bundled in the APK assets
- no public website required to play after installation

## Build
The included GitHub Actions workflow builds a debug APK automatically.
Artifact path:
`app/build/outputs/apk/debug/app-debug.apk`

The debug APK is signed by the Android build tools and can be installed directly on Android after allowing installation from the browser/files app.

## Package
`com.sara.meganstory.debug` for the debug build.
