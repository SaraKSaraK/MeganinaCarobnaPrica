# Megan & Piko — STEP 2 Interactive Forest

Step 2 only: movement plus playful forest interactions. No story, narration or speech recognition yet.

Interactions: magic flowers, bounce mushroom + jump button, rustling bush/squirrel, muddy puddle with repeatable jump/splash and frog surprise, log rest moment, butterfly chase, Piko reactions, procedural sound effects.
