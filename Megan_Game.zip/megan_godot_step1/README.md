# Megan's Magical Adventure — Magical Forest 0.5

Premium interaction pass:
- Player-controlled mushroom jumps: one tap = one chosen jump; no automatic chain.
- Portal is a real traversal: Megan walks into the portal, shrinks/spins through it, then arrives at the magic slide.
- Slide rewards are tappable collectibles, not automatic rewards.
- Illustrated scenery contains hidden interaction hotspots (lights, waterfalls, butterflies, fireflies).
- Repeatable squirrel/acorn, flowers, pond, bushes and crystals remain active.
- Goal: earn 5 Magic Acorns and enter the rainbow portal.
