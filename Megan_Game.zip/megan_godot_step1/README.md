# Megan's Magical Adventure — v0.7 Magical Forest Preview

This build deliberately focuses on game feel and player agency rather than adding more worlds.

## Play loop
- Bounce on mushrooms: every deliberate landing pops out a physical candy reward.
- Collect 4 candies.
- Pick up the acorn and visibly carry it to the squirrel.
- Feed the squirrel.
- The portal wakes only after both goals are complete.
- Enter the portal using the action button; the glade is blocked from normal walking.
- In the Secret Glade, ring giant flowers, bounce again, open a treasure chest, collect optional stars, then use the return portal.

## Foundation improvements
- Camera section boundaries prevent the player from walking off-camera or accidentally reaching the glade.
- Hard world bounds prevent the character leaving the playable space.
- Mushroom reward/state/cooldown system.
- Physical candy arcs, bounces, idle bobbing and proximity collection.
- Optional floating star collectibles.
- Stateful flowers, treasure chest and return portal.
- Living butterflies, fireflies, grass and flower motion.
- Compact player-facing HUD instead of developer playground overlays.
