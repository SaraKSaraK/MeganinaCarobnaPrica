# Megan's Magical Adventure — Rainbow Gate
Production gameplay slice. Premise: a forest sprite stole three Rainbow Stones. Megan must use platforming, berry throwing, breakable barriers, a bridge target, mushroom bouncing, a lever/cage puzzle, and a chase encounter to recover them and open the Rainbow Gate.

Controls: left/right, jump, contextual action. No lives/death; water safely recovers the player. Mushrooms produce optional candy. Boot/loading/menu/icon retained.
