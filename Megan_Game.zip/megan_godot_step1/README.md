# Megan's Magical Adventure — Magical Forest 0.3

A landscape, touch-first Godot 4.3 preschool adventure.

Core loop: explore the forest, play with repeatable toys, earn 5 magic acorns, wake the rainbow portal, then ride the psychedelic magic slide to complete the world.

Controls: hold/drag Megan to walk; tap interesting objects to interact. Tapping an object from farther away makes Megan walk toward it first.

Magical Forest activities:
- Rainbow flower butterfly party
- Four-mushroom automatic BOING run
- Repeatable acorn collection and squirrel feeding
- Frog splash pond
- Three-crystal musical cave puzzle
- Surprise bushes
- Portal transition to a candy/star magic slide

No lives, no failure states, no precision platforming.
