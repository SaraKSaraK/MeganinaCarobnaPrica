# Megan's Magical Adventure — Godot Vertical Slice 0.1

This is the first **real Godot 4** foundation build, replacing the old HTML/WebView prototype.

## Test scope
- Landscape 1280×720.
- Hold Megan, then drag your finger left/right anywhere on screen. Megan walks toward your finger; release to stop.
- ~4,800 px wide magical forest so movement/camera can be judged over a longer route.
- Gentle looping background music and interaction SFX.
- Native Godot text-to-speech using an English system voice where the Android device supports TTS.
- Muddy puddles: tap while Megan is nearby to jump/splash.
- Magic flowers: tap nearby to trigger a sparkle reaction.
- Acorn: pick it up and visibly carry it.
- Squirrel: feed the carried acorn.
- Giant mushroom: bounce when tapped nearby.
- Magic gate: reacts differently before/after helping the squirrel.
- Ambient sparkles/forest scenery.
- Almost no UI; only a small audio toggle.

## Child UX rules implemented
- No reading required.
- No failure/lives/timers.
- Interaction requires proximity but uses forgiving radii.
- If an object is tapped from too far away it pulses instead of failing silently.
- Voice lines react to discoveries instead of narrating obvious actions.

## Architecture
- `Main.gd`: world composition, interaction/state logic, TTS/audio orchestration.
- `Player.gd`: hold-and-drag movement, walk animation, jump state.
- `WorldArt.gd`: long forest rendering.
- Separate Music and SFX buses so narration can duck music.
- Interactable state (acorn, squirrel, gate) is explicit and ready to split into dedicated components after the control/feel test passes.

## Current intentional limitations
This is a vertical slice foundation, not the final art pack. It does **not** yet include the unicorn/castle/underwater worlds, inventory UI, speech recognition, full story system, or final professional character sprite animation. Those are deliberately held until the core game feel is approved.

## Godot
Designed for Godot 4.3+ using the GL Compatibility renderer for broad Android support.
