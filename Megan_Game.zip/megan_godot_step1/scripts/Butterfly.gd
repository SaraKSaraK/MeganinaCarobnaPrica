extends Node2D

var home := Vector2.ZERO
var target := Vector2.ZERO
var velocity := Vector2.ZERO
var clock := 0.0
var choose_clock := 0.0
var wing_l: Polygon2D
var wing_r: Polygon2D
var body: Line2D
var player = null

func _ready():
    home = global_position
    target = home
    _build()

func _build():
    wing_l = Polygon2D.new()
    wing_l.polygon = PackedVector2Array([Vector2(-2,0),Vector2(-30,-20),Vector2(-39,4),Vector2(-18,20)])
    wing_l.color = Color("67e9ff")
    add_child(wing_l)
    wing_r = Polygon2D.new()
    wing_r.polygon = PackedVector2Array([Vector2(2,0),Vector2(30,-20),Vector2(39,4),Vector2(18,20)])
    wing_r.color = Color("c778ff")
    add_child(wing_r)
    body = Line2D.new(); body.points=PackedVector2Array([Vector2(0,-12),Vector2(0,17)]); body.width=5; body.default_color=Color("402552"); body.antialiased=true; add_child(body)

func _process(delta):
    clock += delta
    choose_clock -= delta
    if player and global_position.distance_to(player.global_position+Vector2(0,-110)) < 145:
        target = global_position + Vector2(150 if global_position.x>=player.global_position.x else -150,-70)
        choose_clock = 0.8
    elif choose_clock <= 0:
        choose_clock = randf_range(1.3,2.8)
        target = home + Vector2(randf_range(-150,150),randf_range(-80,85))
    var desired = (target-global_position).normalized()*105.0 if global_position.distance_to(target)>8 else Vector2.ZERO
    velocity = velocity.lerp(desired,1.0-exp(-3.4*delta))
    global_position += velocity*delta
    rotation = lerp(rotation,clamp(velocity.y/220.0,-0.18,0.18),0.08)
    if abs(velocity.x)>4: scale.x = abs(scale.x)*(1.0 if velocity.x>=0 else -1.0)
    var flap = 0.22 + abs(sin(clock*11.5))*0.82
    wing_l.scale.x = flap
    wing_r.scale.x = flap
    position.y += sin(clock*5.2)*0.025
