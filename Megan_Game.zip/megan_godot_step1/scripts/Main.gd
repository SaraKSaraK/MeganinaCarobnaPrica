extends Node2D

const VIEW_W := 1280.0
const VIEW_H := 720.0
const GROUND_Y := 610.0
const ZONE_COUNT := 6

var player
var camera
var interactables = []
var ambient = []
var pending_object = null
var dragging := false
var stars := 0
var candy := 0
var held_acorns := 0
var magic_acorns := 0
var magic_tasks = {}
var squirrel_feed_count := 0
var flower_taps := 0
var frog_splashes := 0
var crystal_lit := {}
var mushroom_runs := 0
var zone_seen := {}
var slide_active := false
var slide_time := 0.0
var slide_reward_marks := {}
var rng = RandomNumberGenerator.new()
var music: AudioStreamPlayer
var sfx: AudioStreamPlayer

var star_label: Label
var candy_label: Label
var held_label: Label
var magic_label: Label
var goal_label: Label
var task_dots = []

func _ready():
    rng.randomize()
    _build_world()
    _say("Whoa! This forest is FULL of magic. Let's wake the portal!")

func _build_world():
    _build_backgrounds()
    _build_ambient_magic()
    _build_tasks()

    player = Node2D.new()
    player.set_script(load("res://scripts/Player.gd"))
    player.position = Vector2(150, GROUND_Y)
    add_child(player)

    camera = Camera2D.new()
    camera.position = Vector2(150,-120)
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 6.0
    camera.limit_left = 0
    camera.limit_right = int(VIEW_W * ZONE_COUNT)
    camera.limit_top = 0
    camera.limit_bottom = int(VIEW_H)
    player.add_child(camera)
    camera.make_current()

    music = AudioStreamPlayer.new()
    music.stream = load("res://audio/forest_music.wav")
    music.volume_db = -19
    add_child(music)
    music.play()
    music.finished.connect(func(): music.play())

    sfx = AudioStreamPlayer.new()
    add_child(sfx)
    _build_hud()

func _build_backgrounds():
    var names = [
        "res://assets/zone0_grove.png",
        "res://assets/zone1_mushrooms.png",
        "res://assets/zone2_squirrels.png",
        "res://assets/zone3_crystals.png",
        "res://assets/zone4_portal.png",
        "res://assets/zone5_slide.png"
    ]
    for i in range(names.size()):
        var bg = Sprite2D.new()
        bg.texture = load(names[i])
        bg.position = Vector2(i * VIEW_W + VIEW_W/2.0, VIEW_H/2.0)
        add_child(bg)

        # Slight foreground depth layer so Megan sits in the scene instead of floating over wallpaper.
        var shade = Polygon2D.new()
        shade.polygon = PackedVector2Array([
            Vector2(i*VIEW_W,585),Vector2((i+1)*VIEW_W,585),
            Vector2((i+1)*VIEW_W,720),Vector2(i*VIEW_W,720)
        ])
        shade.color = Color(0.05,0.08,0.04,0.10 if i < 5 else 0.06)
        add_child(shade)

func _build_ambient_magic():
    for zone in range(5):
        for j in range(12):
            var dot = _circle(3.0 + float(j%3), Color(1.0,0.91,0.48,0.78))
            dot.position = Vector2(zone*VIEW_W + 80 + (j*103)%1120, 185 + (j*73)%350)
            dot.set_meta("home", dot.position)
            dot.set_meta("phase", float(j)*0.7 + float(zone))
            dot.set_meta("speed", 0.7 + float(j%4)*0.12)
            add_child(dot)
            ambient.append(dot)

func _build_tasks():
    # Zone 0 - rainbow flowers
    var flowers = Node2D.new()
    flowers.position = Vector2(650,565)
    flowers.name = "RainbowFlowers"
    add_child(flowers)
    for i in range(7):
        _add_flower(flowers, Vector2(-90+i*30, sin(i*1.7)*9), [Color("#ff75c8"),Color("#a981ff"),Color("#69ddff"),Color("#ffe16a")][i%4])
    _register(flowers,"flowers",150)

    # Zone 1 - mushroom bounce run, 4 real targets.
    var mushroom_positions = [
        Vector2(1450,590),Vector2(1685,545),Vector2(1925,575),Vector2(2165,525)
    ]
    for i in range(mushroom_positions.size()):
        var m = _sprite_obj("mushroom_%d"%i, "res://assets/mushroom.svg", mushroom_positions[i], Vector2(0.55+0.07*(i%2),0.55+0.07*(i%2)), "mushroom")
        m.modulate = [Color("#ff7cc8"),Color("#8b8cff"),Color("#62d9ff"),Color("#ff9a72")][i]
        m.set_meta("chain_index",i)

    # Zone 2 - squirrel + endlessly respawning acorns.
    var squirrel = _sprite_obj("squirrel", "res://assets/squirrel.svg", Vector2(2950,550), Vector2(0.68,0.68), "squirrel")
    squirrel.set_meta("base_scale",squirrel.scale)
    for p in [Vector2(2680,590),Vector2(3190,588),Vector2(3470,585),Vector2(3600,565)]:
        _spawn_acorn(p)

    # Zone 3 - pond/frog and crystal cave puzzle.
    var puddle = _sprite_obj("magic_pond", "res://assets/puddle.svg", Vector2(4110,625), Vector2(1.05,1.05), "pond")
    puddle.modulate = Color("#87e8ff")
    var frog = _make_frog()
    frog.position = Vector2(4100,575)
    frog.visible = false
    frog.name = "frog"
    add_child(frog)
    frog.set_meta("kind","frog_visual")

    var crystal_positions = [Vector2(4580,575),Vector2(4740,535),Vector2(4905,585)]
    var crystal_colors = [Color("#75eaff"),Color("#cf78ff"),Color("#ff78c8")]
    for i in range(3):
        var c = _make_crystal(crystal_colors[i])
        c.position = crystal_positions[i]
        c.name = "crystal_%d"%i
        c.set_meta("crystal_index",i)
        add_child(c)

    # Zone 4 - portal gameplay layer over illustrated portal.
    var portal = Node2D.new()
    portal.position = Vector2(6070,440)
    portal.name = "RainbowPortal"
    add_child(portal)
    _build_portal_fx(portal)
    _register(portal,"portal",190)

    # A few optional bushes / surprise toys across the world.
    for data in [
        [Vector2(970,585),"bush"],[Vector2(2380,585),"bush"],
        [Vector2(3760,585),"bush"],[Vector2(5230,585),"bush"]
    ]:
        var b = _make_bush()
        b.position = data[0]
        add_child(b)
        _register(b,"bush",110)

func _build_hud():
    var layer = CanvasLayer.new()
    add_child(layer)

    var hud = Panel.new()
    hud.position = Vector2(22,18)
    hud.size = Vector2(585,78)
    hud.modulate = Color(0.11,0.12,0.20,0.83)
    layer.add_child(hud)

    star_label = _hud_label(layer,"★ 0",Vector2(50,38),Color("#ffe563"),30)
    candy_label = _hud_label(layer,"CANDY 0",Vector2(155,39),Color("#ff9ed4"),24)
    held_label = _hud_label(layer,"ACORN 0",Vector2(312,39),Color("#d99a56"),24)
    magic_label = _hud_label(layer,"MAGIC 0/5",Vector2(455,39),Color("#bb9bff"),22)

    goal_label = _hud_label(layer,"Wake the rainbow portal",Vector2(830,34),Color.WHITE,22)
    goal_label.size = Vector2(300,40)
    goal_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

    for i in range(5):
        var d = _circle(10,Color(0.45,0.42,0.58,0.65))
        d.position = Vector2(920+i*31,82)
        layer.add_child(d)
        task_dots.append(d)

    var sound = Button.new()
    sound.text = "♪"
    sound.position = Vector2(1195,22)
    sound.size = Vector2(62,62)
    sound.add_theme_font_size_override("font_size",30)
    sound.pressed.connect(_toggle_audio)
    layer.add_child(sound)

func _hud_label(layer,text,pos,col,size):
    var l = Label.new()
    l.text = text
    l.position = pos
    l.add_theme_font_size_override("font_size",size)
    l.add_theme_color_override("font_color",col)
    l.add_theme_color_override("font_shadow_color",Color(0,0,0,0.65))
    l.add_theme_constant_override("shadow_offset_x",2)
    l.add_theme_constant_override("shadow_offset_y",2)
    layer.add_child(l)
    return l

func _process(delta):
    var now = Time.get_ticks_msec()/1000.0
    for a in ambient:
        if is_instance_valid(a):
            var home = a.get_meta("home")
            var ph = a.get_meta("phase")
            var sp = a.get_meta("speed")
            a.position = home + Vector2(sin(now*sp+ph)*20.0, cos(now*sp*1.3+ph)*13.0)
            a.modulate.a = 0.48 + 0.42*(sin(now*2.0+ph)*0.5+0.5)

    if slide_active:
        _update_slide(delta)
        return

    if player:
        var zone = int(clamp(floor(player.global_position.x / VIEW_W),0,4))
        if not zone_seen.has(zone):
            zone_seen[zone] = true
            _announce_zone(zone)

        if pending_object != null and is_instance_valid(pending_object):
            if player.global_position.distance_to(pending_object.global_position) < 245.0 and not player.busy:
                var obj = pending_object
                pending_object = null
                player.stop()
                _activate(obj)

        # Nearby toys breathe/glow so the child knows they are alive.
        for o in interactables:
            if is_instance_valid(o) and o.visible:
                var d = player.global_position.distance_to(o.global_position)
                if d < 250:
                    var pulse = 1.0 + sin(now*4.0 + o.global_position.x*0.01)*0.025
                    if str(o.get_meta("kind")) not in ["mushroom","crystal"]:
                        o.scale = Vector2(pulse,pulse)
                elif str(o.get_meta("kind")) not in ["mushroom","crystal","squirrel"]:
                    o.scale = Vector2.ONE

func _announce_zone(zone):
    match zone:
        0: _say("Ooooh! Rainbow flowers! Tap the sparkly things and see what happens!")
        1: _say("GIANT mushrooms! Tap one. I want to bounce across ALL of them!")
        2: _say("A squirrel! I bet she could eat a ridiculous amount of acorns.")
        3: _say("Whoa... glowing water AND crystals. This place is weird. I love it!")
        4:
            if magic_acorns >= 5: _say("There it is! The rainbow portal! Let's GO!")
            else: _say("The portal is here! We still need a little more forest magic.")

func _input(e):
    if slide_active:
        return
    if e is InputEventScreenTouch:
        var wp = _screen_to_world(e.position)
        if e.pressed:
            if player.can_grab(wp):
                dragging = true
                pending_object = null
                player.begin_drag()
            else:
                _interact(wp)
        elif dragging:
            dragging = false
            player.end_drag()
    elif e is InputEventScreenDrag and dragging:
        player.update_drag(_screen_to_world(e.position))
    elif e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
        var mwp = _screen_to_world(e.position)
        if e.pressed:
            if player.can_grab(mwp):
                dragging = true
                pending_object = null
                player.begin_drag()
            else:
                _interact(mwp)
        elif dragging:
            dragging=false
            player.end_drag()
    elif e is InputEventMouseMotion and dragging and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        player.update_drag(_screen_to_world(e.position))

func _screen_to_world(p: Vector2) -> Vector2:
    return get_viewport().get_canvas_transform().affine_inverse() * p

func _interact(world_pos: Vector2):
    var best = null
    var best_d = 99999.0
    for o in interactables:
        if is_instance_valid(o) and o.visible:
            var radius = float(o.get_meta("radius"))
            var d = o.global_position.distance_to(world_pos)
            if d < radius and d < best_d:
                best = o
                best_d = d
    if best == null:
        return

    if player.global_position.distance_to(best.global_position) > 285.0:
        pending_object = best
        player.target_x = clamp(best.global_position.x - 115.0,70.0,6330.0)
        _spark(best.global_position+Vector2(0,-55),Color("#fff1a0"),10)
        return
    _activate(best)

func _activate(o):
    if player.busy:
        return
    var kind = str(o.get_meta("kind"))
    match kind:
        "flowers": await _flowers(o)
        "mushroom": await _mushroom_run()
        "acorn": _pickup_acorn(o)
        "squirrel": await _feed_squirrel(o)
        "pond": await _pond(o)
        "crystal": await _crystal(o)
        "bush": await _bush(o)
        "portal": await _portal(o)

func _flowers(o):
    player.react_to_magic()
    flower_taps += 1
    _sfx("res://audio/sparkle.wav",1.0 + flower_taps*0.05)
    _spark(o.global_position+Vector2(0,-60),[Color("#ff7fd1"),Color("#8fe8ff"),Color("#ffe873")][flower_taps%3],46)
    _spawn_butterflies(o.global_position,5+flower_taps*2)
    stars += 1
    if flower_taps % 3 == 0:
        candy += 1
        _reward(o.global_position+Vector2(0,-100),"CANDY!",Color("#ff9ed8"))
        if not magic_tasks.has("flowers"):
            await _award_magic("flowers",o.global_position,"The flowers made a MAGIC ACORN!")
        else:
            _say("Again! The butterflies are having a PARTY!")
    else:
        _reward(o.global_position+Vector2(0,-90),"★ +1",Color("#ffe86e"))
        _say(["Ooooh! More colors!","Butterflies! AGAIN!","That flower just sparkled at me!"][flower_taps%3])
    _update_hud()

func _mushroom_run():
    if player.busy:
        return
    mushroom_runs += 1
    var targets = []
    for i in range(4):
        var m = get_node_or_null("mushroom_%d"%i)
        if m != null:
            targets.append(m)
    if targets.size() < 4:
        return
    _say("BOING RUN! Here we gooooo!")
    player.stop()
    for i in range(targets.size()):
        var m = targets[i]
        _mushroom_squash(m)
        _sfx("res://audio/boing.wav",0.9 + i*0.08)
        player.jump_to(m.global_position+Vector2(0,-68),155.0+25.0*i,0.56)
        await player.action_finished
        stars += 1
        _spark(m.global_position+Vector2(0,-90),Color("#fff194"),24)
        _reward(m.global_position+Vector2(0,-125),"★",Color("#ffe45e"))
        if i == 2:
            candy += 1
            _reward(m.global_position+Vector2(42,-155),"CANDY!",Color("#ff91d0"))
        _update_hud()
        await get_tree().create_timer(0.08).timeout
    player.jump_to(Vector2(targets[targets.size()-1].global_position.x+150,GROUND_Y),145,0.55)
    await player.action_finished
    if not magic_tasks.has("mushrooms"):
        await _award_magic("mushrooms",targets[targets.size()-1].global_position,"WHAAAT! The mushrooms gave us a MAGIC ACORN!")
    else:
        _say("That was ridiculous. Do it again whenever you want!")

func _pickup_acorn(o):
    player.play_pickup()
    held_acorns += 1
    player.set_holding_acorn(true)
    stars += 1
    o.visible = false
    _sfx("res://audio/pickup.wav",1.0)
    _spark(o.global_position,Color("#ffe3a1"),18)
    _reward(o.global_position+Vector2(0,-55),"ACORN +1",Color("#ffd18b"))
    _update_hud()
    var delay = 3.5 + rng.randf_range(0.0,2.5)
    get_tree().create_timer(delay).timeout.connect(func():
        if is_instance_valid(o):
            o.visible = true
            _spark(o.global_position,Color("#ffe9a8"),12)
    )

func _feed_squirrel(o):
    if held_acorns <= 0:
        _say("She wants another acorn! There are LOADS around here.")
        _pulse(o)
        return
    held_acorns -= 1
    player.set_holding_acorn(held_acorns > 0)
    squirrel_feed_count += 1
    stars += 1
    _update_hud()
    _sfx("res://audio/sparkle.wav",1.05)
    await player.play_give(o.global_position.x)
    await _walk_nibble(o)
    _spark(o.global_position+Vector2(0,-65),Color("#ffd96a"),34)
    if squirrel_feed_count % 4 == 0:
        candy += 2
        _reward(o.global_position+Vector2(0,-105),"CANDY x2!",Color("#ff9ed9"))
    else:
        _reward(o.global_position+Vector2(0,-100),"NOM! ★ +1",Color("#ffe36e"))
    if squirrel_feed_count == 1:
        _say("NOM NOM! She wants MORE!")
    elif squirrel_feed_count == 2:
        _say("Look at those cheeks! One more!")
    elif squirrel_feed_count >= 3 and not magic_tasks.has("squirrel"):
        await _award_magic("squirrel",o.global_position,"Her cheeks were so full she dropped a MAGIC ACORN!")
    else:
        _say("She can apparently eat forever. Respect.")
    _update_hud()

func _walk_nibble(o):
    var old = o.scale
    var t = create_tween()
    t.tween_property(o,"rotation",-0.12,0.08)
    t.tween_property(o,"rotation",0.12,0.08)
    t.tween_property(o,"rotation",-0.08,0.08)
    t.tween_property(o,"rotation",0.08,0.08)
    t.tween_property(o,"rotation",0.0,0.08)
    await t.finished
    o.scale = old

func _pond(o):
    frog_splashes += 1
    stars += 1
    _sfx("res://audio/splash.wav",0.95+rng.randf_range(-0.04,0.08))
    _splash(o.global_position)
    player.jump_to(Vector2(player.global_position.x,GROUND_Y),85,0.45)
    var frog = get_node_or_null("frog")
    if frog:
        frog.visible = true
        frog.position = o.position + Vector2(rng.randf_range(-80,80),-50-rng.randf_range(0,45))
        var ft = create_tween()
        ft.tween_property(frog,"position:y",frog.position.y-45,0.18).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
        ft.tween_property(frog,"position:y",frog.position.y+45,0.20).set_ease(Tween.EASE_IN)
        ft.tween_interval(0.55)
        ft.tween_property(frog,"modulate:a",0.0,0.22)
        ft.finished.connect(func(): frog.visible=false; frog.modulate.a=1.0)
    _reward(o.global_position+Vector2(0,-75),"SPLASH! ★",Color("#a8efff"))
    if frog_splashes % 3 == 0:
        candy += 1
        if not magic_tasks.has("pond"):
            await _award_magic("pond",o.global_position,"The frog found a MAGIC ACORN under the water!")
        else:
            _say("RIBBIT! He came back with candy!")
    else:
        _say(["RIBBIT! Again!","He jumped SO high!","Splash him again!"][frog_splashes%3])
    _update_hud()

func _crystal(o):
    player.react_to_magic()
    var idx = int(o.get_meta("crystal_index"))
    stars += 1
    _sfx("res://audio/sparkle.wav",1.15+idx*0.08)
    _crystal_flash(o)
    _spark(o.global_position+Vector2(0,-45),[Color("#80efff"),Color("#d58cff"),Color("#ff91d3")][idx],34)
    crystal_lit[idx] = true
    _reward(o.global_position+Vector2(0,-95),"DING! ★",Color("#e9d9ff"))
    if crystal_lit.size() >= 3 and not magic_tasks.has("crystals"):
        await get_tree().create_timer(0.25).timeout
        candy += 1
        await _award_magic("crystals",Vector2(4740,520),"All three! The cave made a MAGIC ACORN!")
    elif crystal_lit.size() >= 3:
        candy += 1
        crystal_lit.clear()
        _say("Crystal song complete! Candy!")
    else:
        _say("DING! Find the other glowing crystals!")
    _update_hud()

func _bush(o):
    player.react_to_magic()
    _sfx("res://audio/sparkle.wav",0.85)
    var t = create_tween()
    for r in [-0.13,0.14,-0.09,0.08,0.0]:
        t.tween_property(o,"rotation",r,0.06)
    await t.finished
    stars += 1
    var surprise = rng.randi_range(0,3)
    if surprise == 0:
        candy += 1
        _reward(o.global_position+Vector2(0,-80),"CANDY!",Color("#ff9ed8"))
        _say("HA! The bush was hiding candy!")
    elif surprise == 1:
        _spawn_butterflies(o.global_position,7)
        _say("Butterfly bush!")
    elif surprise == 2:
        _spark(o.global_position,Color("#b9ff9b"),35)
        _reward(o.global_position+Vector2(0,-80),"★ +2",Color("#ffe56c"))
        stars += 1
        _say("DOUBLE stars!")
    else:
        _say("PFFFT! That bush sneezed!")
        _spark(o.global_position,Color("#d9ffbc"),20)
    _update_hud()

func _portal(o):
    if magic_acorns < 5:
        _say("It's almost awake! We need %d more magic acorn%s."%[5-magic_acorns,"" if 5-magic_acorns==1 else "s"])
        _portal_shimmer(o,false)
        return
    _say("THE PORTAL IS OPEN! Hold on... we're going down the magic slide!")
    _portal_shimmer(o,true)
    player.celebrate()
    await player.action_finished
    await get_tree().create_timer(0.3).timeout
    _start_slide()

func _award_magic(task_key, pos, line):
    if magic_tasks.has(task_key):
        return
    magic_tasks[task_key] = true
    magic_acorns += 1
    stars += 3
    _sfx("res://audio/sparkle.wav",1.2)
    _spark(pos+Vector2(0,-100),Color("#fff2a1"),70)
    _spark(pos+Vector2(0,-135),Color("#caa1ff"),45)
    _reward(pos+Vector2(0,-145),"MAGIC ACORN!",Color("#fff0a0"))
    player.celebrate()
    _update_hud()
    _say(line)
    await get_tree().create_timer(0.75).timeout
    if magic_acorns >= 5:
        goal_label.text = "PORTAL READY! →"
        _say("FIVE! We did it! The rainbow portal is awake!")
        var portal = get_node_or_null("RainbowPortal")
        if portal:
            _portal_shimmer(portal,true)

func _start_slide():
    slide_active = true
    pending_object = null
    player.set_slide_pose()
    slide_time = 0.0
    slide_reward_marks.clear()
    player.global_position = Vector2(6450,330)
    camera.position = Vector2(120,0)
    camera.position_smoothing_speed = 9.0
    _spark(player.global_position,Color("#fff3a0"),65)
    _sfx("res://audio/boing.wav",1.15)

func _update_slide(delta):
    slide_time += delta
    var t = clamp(slide_time/5.5,0.0,1.0)
    var x = 6450.0 + t*1110.0
    var y = 330.0 + 115.0*sin((x-80.0)/170.0) + 25.0*sin(x/47.0)
    player.global_position = Vector2(x,y)
    player.sprite.rotation = 0.08 + sin(slide_time*5.0)*0.06

    var marks = [0.12,0.24,0.36,0.48,0.62,0.75,0.88]
    for i in range(marks.size()):
        if t >= marks[i] and not slide_reward_marks.has(i):
            slide_reward_marks[i] = true
            if i % 3 == 2:
                candy += 1
                _reward(player.global_position+Vector2(0,-80),"CANDY!",Color("#ff9edb"))
            else:
                stars += 1
                _reward(player.global_position+Vector2(0,-80),"★",Color("#ffe66d"))
            _spark(player.global_position,Color("#fff4a7"),22)
            _sfx("res://audio/pickup.wav",1.0+float(i)*0.03)
            _update_hud()

    if t >= 1.0:
        slide_active = false
        player.finish_slide()
        player.global_position = Vector2(7560,GROUND_Y)
        camera.position = Vector2(0,-120)
        _forest_complete()

func _forest_complete():
    _spark(player.global_position+Vector2(0,-80),Color("#fff19a"),100)
    _spark(player.global_position+Vector2(-80,-120),Color("#ff9edb"),70)
    _spark(player.global_position+Vector2(80,-140),Color("#8feaff"),70)
    _say("YOU DID IT! Magical Forest complete! The next world is waiting for us!")
    var layer = CanvasLayer.new()
    add_child(layer)
    var panel = Panel.new()
    panel.position = Vector2(285,190)
    panel.size = Vector2(710,300)
    panel.modulate = Color(0.12,0.08,0.25,0.92)
    layer.add_child(panel)
    var title = Label.new()
    title.text = "MAGICAL FOREST COMPLETE!"
    title.position = Vector2(350,235)
    title.add_theme_font_size_override("font_size",38)
    title.add_theme_color_override("font_color",Color("#fff0a3"))
    layer.add_child(title)
    var sub = Label.new()
    sub.text = "★ %d     CANDY %d     MAGIC 5/5"%[stars,candy]
    sub.position = Vector2(425,310)
    sub.add_theme_font_size_override("font_size",27)
    sub.add_theme_color_override("font_color",Color.WHITE)
    layer.add_child(sub)
    var next = Label.new()
    next.text = "Next world: coming through the glowing gate..."
    next.position = Vector2(378,370)
    next.add_theme_font_size_override("font_size",22)
    next.add_theme_color_override("font_color",Color("#d7c5ff"))
    layer.add_child(next)
    var replay = Button.new()
    replay.text = "PLAY FOREST AGAIN"
    replay.position = Vector2(480,420)
    replay.size = Vector2(320,62)
    replay.add_theme_font_size_override("font_size",22)
    replay.pressed.connect(func(): get_tree().reload_current_scene())
    layer.add_child(replay)

func _update_hud():
    if star_label:
        star_label.text = "★ %d"%stars
        candy_label.text = "CANDY %d"%candy
        held_label.text = "ACORN %d"%held_acorns
        magic_label.text = "MAGIC %d/5"%magic_acorns
    for i in range(task_dots.size()):
        task_dots[i].color = Color("#ffd965") if i < magic_acorns else Color(0.45,0.42,0.58,0.65)

func _register(node,kind,radius):
    node.set_meta("kind",kind)
    node.set_meta("radius",radius)
    interactables.append(node)
    return node

func _sprite_obj(n,path,pos,sc,kind):
    var node = Node2D.new()
    node.name = n
    node.position = pos
    var sp = Sprite2D.new()
    sp.texture = load(path)
    sp.scale = sc
    node.add_child(sp)
    add_child(node)
    _register(node,kind,125)
    return node

func _spawn_acorn(pos):
    var a = _sprite_obj("acorn_%d"%interactables.size(),"res://assets/acorn.svg",pos,Vector2(0.38,0.38),"acorn")
    a.set_meta("radius",85)

func _add_flower(parent,pos,col):
    var f = Node2D.new()
    f.position = pos
    parent.add_child(f)
    var stem = Polygon2D.new()
    stem.polygon = PackedVector2Array([Vector2(-3,0),Vector2(3,0),Vector2(2,-30),Vector2(-2,-30)])
    stem.color = Color("#4ca65a")
    f.add_child(stem)
    for k in range(6):
        var pet = _circle(9,col)
        var ang = TAU*float(k)/6.0
        pet.position = Vector2(cos(ang)*11,-40+sin(ang)*11)
        f.add_child(pet)
    var center = _circle(7,Color("#ffe06d"))
    center.position = Vector2(0,-40)
    f.add_child(center)

func _make_frog():
    var n = Node2D.new()
    var body = _circle(26,Color("#7ad95e")); n.add_child(body)
    var e1 = _circle(9,Color("#9bf57e")); e1.position=Vector2(-14,-20); n.add_child(e1)
    var e2 = _circle(9,Color("#9bf57e")); e2.position=Vector2(14,-20); n.add_child(e2)
    var p1 = _circle(3,Color("#1f3824")); p1.position=Vector2(-14,-21); n.add_child(p1)
    var p2 = _circle(3,Color("#1f3824")); p2.position=Vector2(14,-21); n.add_child(p2)
    return n

func _make_crystal(col):
    var n = Node2D.new()
    var p = Polygon2D.new()
    p.polygon = PackedVector2Array([Vector2(0,-72),Vector2(28,-25),Vector2(17,20),Vector2(-18,20),Vector2(-28,-25)])
    p.color = col
    n.add_child(p)
    var shine = Polygon2D.new()
    shine.polygon = PackedVector2Array([Vector2(-3,-58),Vector2(9,-27),Vector2(4,5),Vector2(-4,-2)])
    shine.color = Color(1,1,1,0.45)
    n.add_child(shine)
    n.set_meta("base_color",col)
    _register(n,"crystal",95)
    return n

func _make_bush():
    var n = Node2D.new()
    for i in range(5):
        var c = _circle(30+float(i%2)*8, [Color("#397f52"),Color("#4e9e5f"),Color("#2f704a")][i%3])
        c.position = Vector2((i-2)*24,-abs(i-2)*5)
        n.add_child(c)
    for i in range(4):
        var berry = _circle(5,[Color("#ff8dca"),Color("#ffe36d"),Color("#a991ff")][i%3])
        berry.position = Vector2(-35+i*24,-25-(i%2)*14)
        n.add_child(berry)
    return n

func _build_portal_fx(portal):
    for i in range(3):
        var ring = Line2D.new()
        var pts = PackedVector2Array()
        var r = 72.0 + i*24.0
        for k in range(33):
            var a = TAU*float(k)/32.0
            pts.append(Vector2(cos(a)*r,sin(a)*r*1.35))
        ring.points = pts
        ring.width = 5.0 - i
        ring.default_color = [Color(0.78,0.48,1.0,0.65),Color(0.35,0.90,1.0,0.48),Color(1.0,0.78,0.35,0.42)][i]
        ring.antialiased = true
        portal.add_child(ring)
        ring.set_meta("portal_ring",true)

func _portal_shimmer(portal,strong):
    _spark(portal.global_position,Color("#dba6ff"),70 if strong else 30)
    _spark(portal.global_position+Vector2(0,-90),Color("#fff3a2"),50 if strong else 18)
    var t = create_tween()
    t.tween_property(portal,"scale",Vector2(1.10,1.10),0.18)
    t.tween_property(portal,"scale",Vector2.ONE,0.25)

func _mushroom_squash(n):
    var s = n.scale
    var t = create_tween()
    t.tween_property(n,"scale",Vector2(s.x*1.18,s.y*0.72),0.09)
    t.tween_property(n,"scale",Vector2(s.x*0.93,s.y*1.18),0.11)
    t.tween_property(n,"scale",s,0.16)

func _crystal_flash(n):
    var t = create_tween()
    t.tween_property(n,"scale",Vector2(1.22,1.22),0.12)
    t.tween_property(n,"scale",Vector2.ONE,0.22)

func _pulse(n):
    var s = n.scale
    var t = create_tween()
    t.tween_property(n,"scale",s*1.14,0.12)
    t.tween_property(n,"scale",s,0.20)

func _circle(radius,col):
    var p = Polygon2D.new()
    var pts = PackedVector2Array()
    for i in range(24):
        var a = TAU*float(i)/24.0
        pts.append(Vector2(cos(a)*radius,sin(a)*radius))
    p.polygon = pts
    p.color = col
    return p

func _spark(pos,col,count):
    var p = CPUParticles2D.new()
    p.position = pos
    p.one_shot = true
    p.amount = count
    p.lifetime = 0.95
    p.explosiveness = 0.96
    p.initial_velocity_min = 70
    p.initial_velocity_max = 205
    p.direction = Vector2(0,-1)
    p.spread = 180
    p.gravity = Vector2(0,165)
    p.scale_amount_min = 3
    p.scale_amount_max = 9
    p.color = col
    add_child(p)
    p.emitting = true
    get_tree().create_timer(1.4).timeout.connect(p.queue_free)

func _splash(pos):
    var p = CPUParticles2D.new()
    p.position = pos-Vector2(0,15)
    p.one_shot=true
    p.amount=42
    p.lifetime=0.75
    p.explosiveness=0.96
    p.initial_velocity_min=110
    p.initial_velocity_max=235
    p.direction=Vector2(0,-1)
    p.spread=95
    p.gravity=Vector2(0,450)
    p.scale_amount_min=3
    p.scale_amount_max=8
    p.color=Color("#9feaff")
    add_child(p)
    p.emitting=true
    get_tree().create_timer(1.2).timeout.connect(p.queue_free)

func _spawn_butterflies(pos,count):
    for i in range(count):
        var b = Node2D.new()
        b.position = pos+Vector2(rng.randf_range(-80,80),rng.randf_range(-20,30))
        var left = Polygon2D.new()
        left.polygon = PackedVector2Array([Vector2(0,0),Vector2(-15,-9),Vector2(-10,9)])
        left.color = [Color("#ff8ed5"),Color("#8adfff"),Color("#c69cff"),Color("#ffe269")][i%4]
        b.add_child(left)
        var right = Polygon2D.new()
        right.polygon = PackedVector2Array([Vector2(0,0),Vector2(15,-9),Vector2(10,9)])
        right.color=left.color
        b.add_child(right)
        add_child(b)
        var target = b.position+Vector2(rng.randf_range(-160,160),rng.randf_range(-180,-80))
        var t = create_tween().set_parallel(true)
        t.tween_property(b,"position",target,1.8+rng.randf_range(0,0.8)).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
        t.tween_property(b,"rotation",rng.randf_range(-0.7,0.7),1.4)
        t.tween_property(b,"modulate:a",0.0,2.2)
        t.finished.connect(b.queue_free)

func _reward(pos,text,col):
    var l=Label.new()
    l.text=text
    l.position=pos-Vector2(65,45)
    l.add_theme_font_size_override("font_size",26)
    l.add_theme_color_override("font_color",col)
    l.add_theme_color_override("font_shadow_color",Color(0,0,0,0.75))
    l.add_theme_constant_override("shadow_offset_x",2)
    l.add_theme_constant_override("shadow_offset_y",2)
    add_child(l)
    var tw=create_tween().set_parallel(true)
    tw.tween_property(l,"position:y",l.position.y-82,1.0)
    tw.tween_property(l,"modulate:a",0.0,1.0)
    tw.finished.connect(l.queue_free)

func _sfx(path,pitch:=1.0):
    sfx.stream=load(path)
    sfx.pitch_scale=pitch
    sfx.play()

func _say(text):
    if not DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
        return
    var voices=DisplayServer.tts_get_voices_for_language("en")
    if voices.size()==0:
        return
    if music:
        music.volume_db=-28
    DisplayServer.tts_speak(text,voices[0],76,1.12,1.05,0,true)
    get_tree().create_timer(max(1.2,text.length()*0.038)).timeout.connect(func():
        if music:
            music.volume_db=-19
    )

func _toggle_audio():
    var idx=AudioServer.get_bus_index("Master")
    AudioServer.set_bus_mute(idx,not AudioServer.is_bus_mute(idx))
