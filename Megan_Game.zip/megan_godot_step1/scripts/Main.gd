extends Node2D

const GROUND_Y:=615.0
var player:Node2D
var dragging=false
var interactables=[]
var stars=0
var candy=0
var acorns=0
var squirrel_feed_count=0
var mushroom_hits=0
var music:AudioStreamPlayer
var sfx:AudioStreamPlayer
var star_label:Label
var candy_label:Label
var acorn_label:Label
var rng=RandomNumberGenerator.new()

func _ready():
    rng.randomize()
    _build_scene()
    _say("Megan! Look at this forest! Let's see what we can find!")

func _build_scene():
    var bg=Sprite2D.new()
    bg.texture=load("res://assets/forest_zone.png")
    bg.position=Vector2(640,360)
    add_child(bg)

    # soft foreground shade grounds the player into the painted scene
    var shade=Polygon2D.new(); shade.polygon=PackedVector2Array([Vector2(0,585),Vector2(1280,585),Vector2(1280,720),Vector2(0,720)]); shade.color=Color(0.08,0.18,0.07,0.08); add_child(shade)

    player=Node2D.new(); player.set_script(load("res://scripts/Player.gd")); player.position=Vector2(155,GROUND_Y); add_child(player)

    _obj("squirrel",load("res://assets/squirrel.svg"),Vector2(320,555),Vector2(.68,.68),"squirrel")
    _obj("mushroom",load("res://assets/mushroom.svg"),Vector2(570,575),Vector2(.72,.72),"mushroom")
    _obj("puddle",load("res://assets/puddle.svg"),Vector2(820,632),Vector2(.70,.70),"puddle")
    _obj("flowers",null,Vector2(970,585),Vector2.ONE,"flowers")
    _spawn_acorn(Vector2(205,590)); _spawn_acorn(Vector2(735,590)); _spawn_acorn(Vector2(1035,590))
    _obj("portal",null,Vector2(1120,420),Vector2.ONE,"portal")

    # flowers overlay
    for i in range(7):
        var f=Polygon2D.new(); f.position=Vector2(910+i*20,595+sin(i)*6); f.polygon=PackedVector2Array([Vector2(-8,0),Vector2(0,-25),Vector2(8,0)]); f.color=[Color("#ff9fcf"),Color("#d8b1ff"),Color("#ffe077")][i%3]; add_child(f)

    music=AudioStreamPlayer.new(); music.stream=load("res://audio/forest_music.wav"); music.volume_db=-18; add_child(music); music.play(); music.finished.connect(func():music.play())
    sfx=AudioStreamPlayer.new(); add_child(sfx)
    _build_hud()

func _build_hud():
    var layer=CanvasLayer.new(); add_child(layer)
    var panel=GradientTexture2D.new()
    var hud=Panel.new(); hud.position=Vector2(24,20); hud.size=Vector2(430,72); hud.modulate=Color(1,1,1,.92); layer.add_child(hud)
    star_label=_hud_label(layer,"★ 0",Vector2(52,37),Color("#ffd94f"))
    candy_label=_hud_label(layer,"🍬 0",Vector2(180,37),Color.WHITE)
    acorn_label=_hud_label(layer,"● 0",Vector2(325,37),Color("#b8793d"))
    var sound=Button.new(); sound.text="♪"; sound.position=Vector2(1195,22); sound.size=Vector2(62,62); sound.add_theme_font_size_override("font_size",30); sound.pressed.connect(_toggle_audio); layer.add_child(sound)

func _hud_label(layer,text,pos,col):
    var l=Label.new(); l.text=text; l.position=pos; l.add_theme_font_size_override("font_size",30); l.add_theme_color_override("font_color",col); layer.add_child(l); return l

func _obj(n,tex,pos,sc,kind):
    var node=Node2D.new(); node.name=n; node.position=pos; node.set_meta("kind",kind)
    if tex:
        var sp=Sprite2D.new(); sp.texture=tex; sp.scale=sc; node.add_child(sp)
    add_child(node); interactables.append(node); return node

func _spawn_acorn(pos):
    var a=_obj("acorn_%s"%interactables.size(),load("res://assets/acorn.svg"),pos,Vector2(.36,.36),"acorn")
    a.set_meta("home",pos)

func _input(e):
    if e is InputEventScreenTouch:
        if e.pressed:
            if player.can_grab(e.position): dragging=true; player.begin_drag()
            else:_interact(e.position)
        elif dragging: dragging=false; player.end_drag()
    elif e is InputEventScreenDrag and dragging: player.update_drag(e.position)
    elif e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_LEFT:
        if e.pressed:
            if player.can_grab(e.position):dragging=true;player.begin_drag()
            else:_interact(e.position)
        elif dragging:dragging=false;player.end_drag()
    elif e is InputEventMouseMotion and dragging and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):player.update_drag(e.position)

func _interact(p:Vector2):
    var best=null; var bd=9999.0
    for o in interactables:
        if is_instance_valid(o) and o.visible:
            var d=o.position.distance_to(p)
            if d<bd:bd=d;best=o
    if best==null or bd>145:return
    if player.position.distance_to(best.position)>310:
        _pulse(best); _spark(best.position+Vector2(0,-45),Color("#fff1a0"),10); return
    _activate(best)

func _activate(o):
    match str(o.get_meta("kind")):
        "acorn":
            acorns+=1; o.visible=false; _sfx("res://audio/pickup.wav"); _reward(o.position,"ACORN!",Color("#ffe48b")); _update_hud()
            get_tree().create_timer(5.0+rng.randf_range(0,3)).timeout.connect(func(): if is_instance_valid(o): o.visible=true; _spark(o.position,Color("#ffe8a0"),14))
        "squirrel":
            if acorns>0:
                acorns-=1;squirrel_feed_count+=1;stars+=1;_update_hud();_sfx("res://audio/sparkle.wav");_spark(o.position+Vector2(0,-55),Color("#ffd86b"),30)
                if squirrel_feed_count%3==0:
                    candy+=1; _reward(o.position+Vector2(0,-80),"🍬  BONUS!",Color("#ff9fd5")); _say("Oh! Her cheeks are FULL! She found us a candy!")
                elif squirrel_feed_count%2==0:_reward(o.position+Vector2(0,-70),"★ +1  NOM NOM!",Color("#ffe66f"));_say("Again! She's getting chubby cheeks!")
                else:_reward(o.position+Vector2(0,-70),"★ +1",Color("#ffe66f"));_say("Aww! She loves it!")
                _update_hud(); _squirrel_wiggle(o)
            else:_say("She's hungry again! Can you find her another acorn?");_pulse(o)
        "mushroom":
            mushroom_hits+=1; _sfx("res://audio/boing.wav"); _mushroom_squash(o); player.bounce_on(o.position.x,190+min(mushroom_hits,3)*18); stars+=1
            _spark(o.position+Vector2(0,-100),Color("#fff2a1"),34); _reward(o.position+Vector2(0,-130),"★ +1",Color("#ffe25d"));
            if mushroom_hits%3==0:candy+=1;_reward(o.position+Vector2(45,-170),"🍬!",Color("#ff91d0"));_say("BOING! Whoa! A candy popped out!")
            else:_say(["BOING! Again!","Wheee! Higher!","That mushroom is SO bouncy!"][mushroom_hits%3])
            _update_hud()
        "puddle":
            _sfx("res://audio/splash.wav");player.little_hop(100);_splash(o.position);stars+=1;_reward(o.position+Vector2(0,-60),"SPLASH!  ★ +1",Color("#b8efff"));_update_hud()
            if rng.randf()<.35:_say("Ribbit! Did a frog just laugh at us?")
        "flowers":
            _sfx("res://audio/sparkle.wav");_spark(o.position+Vector2(0,-45),Color("#ffb6e7"),45);stars+=1;_reward(o.position+Vector2(0,-95),"BUTTERFLIES!  ★ +1",Color("#ffd6f1"));_update_hud();_say("Ooooh! We woke up the butterflies!")
        "portal":
            if stars>=5:_portal_party(o.position);_say("Woooow! We found the magic way to the next adventure!")
            else:_say("The portal is sparkling... I think it wants more magic stars!");_spark(o.position,Color("#dcb5ff"),24)

func _update_hud():star_label.text="★ %d"%stars;candy_label.text="🍬 %d"%candy;acorn_label.text="● %d"%acorns
func _reward(pos,text,col):
    var l=Label.new();l.text=text;l.position=pos-Vector2(55,40);l.add_theme_font_size_override("font_size",28);l.add_theme_color_override("font_color",col);l.add_theme_color_override("font_shadow_color",Color(0,0,0,.7));l.add_theme_constant_override("shadow_offset_x",2);l.add_theme_constant_override("shadow_offset_y",2);add_child(l)
    var tw=create_tween().set_parallel(true);tw.tween_property(l,"position:y",l.position.y-80,1.0);tw.tween_property(l,"modulate:a",0.0,1.0);tw.finished.connect(l.queue_free)
func _pulse(n):var s=n.scale;var t=create_tween();t.tween_property(n,"scale",s*1.1,.12);t.tween_property(n,"scale",s,.2)
func _mushroom_squash(n):var s=n.scale;var t=create_tween();t.tween_property(n,"scale",Vector2(s.x*1.18,s.y*.72),.1);t.tween_property(n,"scale",Vector2(s.x*.92,s.y*1.16),.12);t.tween_property(n,"scale",s,.16)
func _squirrel_wiggle(n):var r=n.rotation;var t=create_tween();for a in [-.13,.13,-.1,.1,0.0]:t.tween_property(n,"rotation",a,.08)
func _spark(pos,col,count):
    var p=CPUParticles2D.new();p.position=pos;p.one_shot=true;p.amount=count;p.lifetime=.9;p.explosiveness=.95;p.initial_velocity_min=70;p.initial_velocity_max=190;p.direction=Vector2(0,-1);p.spread=180;p.gravity=Vector2(0,150);p.scale_amount_min=3;p.scale_amount_max=8;p.color=col;add_child(p);p.emitting=true;get_tree().create_timer(1.3).timeout.connect(p.queue_free)
func _splash(pos):
    var p=CPUParticles2D.new();p.position=pos-Vector2(0,20);p.one_shot=true;p.amount=38;p.lifetime=.7;p.explosiveness=.95;p.initial_velocity_min=100;p.initial_velocity_max=220;p.direction=Vector2(0,-1);p.spread=90;p.gravity=Vector2(0,430);p.scale_amount_min=3;p.scale_amount_max=8;p.color=Color("#9be8ff");add_child(p);p.emitting=true;get_tree().create_timer(1.1).timeout.connect(p.queue_free)
func _portal_party(pos):_spark(pos,Color("#fff2a6"),70);_spark(pos+Vector2(-50,-100),Color("#e3b0ff"),55);stars+=2;_update_hud();_reward(Vector2(1060,220),"SECRET PATH! ★★",Color("#fff1a3"))
func _sfx(path):sfx.stream=load(path);sfx.play()
func _say(text):
    if not DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):return
    var v=DisplayServer.tts_get_voices_for_language("en");if v.size()==0:return
    if music:music.volume_db=-28
    DisplayServer.tts_speak(text,v[0],76,1.1,1.04,0,true)
    get_tree().create_timer(max(1.3,text.length()*.04)).timeout.connect(func():if music:music.volume_db=-18)
func _toggle_audio():var i=AudioServer.get_bus_index("Master");AudioServer.set_bus_mute(i,not AudioServer.is_bus_mute(i))
