extends Control

var elapsed := 0.0
var progress := 0.0
var bar_fill: ColorRect
var sparkle_root: Control

func _ready():
    _build_ui()

func _build_ui():
    var bg = TextureRect.new()
    bg.texture = load("res://assets/loading_bg.jpg")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    add_child(bg)

    var veil = ColorRect.new()
    veil.color = Color(0.07,0.04,0.16,0.34)
    veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(veil)

    sparkle_root = Control.new()
    sparkle_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    sparkle_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(sparkle_root)
    for i in range(22):
        var s = Label.new()
        s.text = "✦" if i % 3 else "·"
        s.position = Vector2(80 + (i*137)%1130, 60 + (i*83)%560)
        s.add_theme_font_size_override("font_size", 18 + (i%4)*5)
        s.add_theme_color_override("font_color", Color(1.0,0.88,0.48,0.30 + 0.04*(i%5)))
        s.set_meta("phase", float(i)*0.53)
        sparkle_root.add_child(s)

    var logo = Label.new()
    logo.text = "MEGAN'S"
    logo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    logo.position = Vector2(290,190)
    logo.size = Vector2(700,70)
    logo.add_theme_font_size_override("font_size", 54)
    logo.add_theme_color_override("font_color", Color.WHITE)
    logo.add_theme_color_override("font_shadow_color", Color(0.18,0.04,0.30,0.9))
    logo.add_theme_constant_override("shadow_offset_x",4)
    logo.add_theme_constant_override("shadow_offset_y",5)
    add_child(logo)

    var title = Label.new()
    title.text = "MAGICAL ADVENTURE"
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.position = Vector2(160,245)
    title.size = Vector2(960,95)
    title.add_theme_font_size_override("font_size", 72)
    title.add_theme_color_override("font_color", Color("ffe9ff"))
    title.add_theme_color_override("font_shadow_color", Color(0.18,0.03,0.35,0.95))
    title.add_theme_constant_override("shadow_offset_x",5)
    title.add_theme_constant_override("shadow_offset_y",6)
    add_child(title)

    var hint = Label.new()
    hint.text = "Opening the magic..."
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint.position = Vector2(390,485)
    hint.size = Vector2(500,42)
    hint.add_theme_font_size_override("font_size", 22)
    hint.add_theme_color_override("font_color", Color(1,1,1,0.88))
    add_child(hint)

    var frame = ColorRect.new()
    frame.position = Vector2(360,540)
    frame.size = Vector2(560,14)
    frame.color = Color(1,1,1,0.15)
    add_child(frame)
    bar_fill = ColorRect.new()
    bar_fill.position = Vector2(364,544)
    bar_fill.size = Vector2(0,6)
    bar_fill.color = Color("ffd76d")
    add_child(bar_fill)

func _process(delta):
    elapsed += delta
    progress = min(1.0, elapsed / 1.65)
    if bar_fill:
        bar_fill.size.x = 552.0 * ease(progress, 0.7)
    if sparkle_root:
        var t = Time.get_ticks_msec()/1000.0
        for c in sparkle_root.get_children():
            var p = c.get_meta("phase")
            c.modulate.a = 0.35 + 0.65*(sin(t*2.0+p)*0.5+0.5)
            c.position.y += sin(t*1.2+p)*0.018
    if elapsed >= 1.75:
        set_process(false)
        get_tree().change_scene_to_file("res://scenes/Menu.tscn")
