extends CharacterBody2D

signal landed_on(collider, impact)

const SPEED := 410.0
const ACCEL := 2100.0
const AIR_ACCEL := 1200.0
const FRICTION := 2600.0
const GRAVITY := 1850.0
const JUMP_SPEED := -720.0

var move_axis := 0.0
var jump_requested := false
var facing := 1.0
var state := "idle"
var held_visible := false
var controls_enabled := true
var previous_vy := 0.0
var walk_clock := 0.0
var state_clock := 0.0
var blink_clock := 2.0
var blink_duration := 0.0
var hair_offset := Vector2.ZERO
var hair_velocity := Vector2.ZERO

var visual: Node2D
var body: Node2D
var head_pivot: Node2D
var bun_pivot: Node2D
var left_arm: Node2D
var right_arm: Node2D
var left_leg: Node2D
var right_leg: Node2D
var left_lower: Node2D
var right_lower: Node2D
var dress: Sprite2D
var head: Sprite2D
var bun: Sprite2D
var acorn_sprite: Sprite2D
var eyelid_l: Polygon2D
var eyelid_r: Polygon2D
var shadow: Polygon2D

var head_tex = preload("res://assets/megan_head_rig.svg")
var dress_tex = preload("res://assets/megan_dress_rig.svg")
var bun_tex = preload("res://assets/megan_bun_rig.svg")
var acorn_tex = preload("res://assets/acorn.svg")

func _ready():
    floor_snap_length = 8.0
    floor_stop_on_slope = true
    _build_collision()
    _build_rig()

func _build_collision():
    var cs = CollisionShape2D.new()
    var shape = CapsuleShape2D.new()
    shape.radius = 24.0
    shape.height = 142.0
    cs.shape = shape
    cs.position = Vector2(0,-71)
    add_child(cs)

func _build_rig():
    shadow = _ellipse(42,11,Color(0.04,0.025,0.06,0.25))
    shadow.position = Vector2(0,-2)
    shadow.z_index = -1
    add_child(shadow)

    visual = Node2D.new()
    visual.scale = Vector2(0.70,0.70)
    visual.position = Vector2(0,-1)
    add_child(visual)

    body = Node2D.new()
    body.position = Vector2(0,-174)
    visual.add_child(body)

    left_leg = _limb(Color("ffd7c0"),18,60)
    left_leg.position = Vector2(-18,50)
    body.add_child(left_leg)
    left_lower = _limb(Color("ffd7c0"),17,58)
    left_lower.position = Vector2(0,54)
    left_leg.add_child(left_lower)
    var ls = _shoe(); ls.position=Vector2(6,55); left_lower.add_child(ls)

    right_leg = _limb(Color("ffd7c0"),18,60)
    right_leg.position = Vector2(18,50)
    body.add_child(right_leg)
    right_lower = _limb(Color("ffd7c0"),17,58)
    right_lower.position = Vector2(0,54)
    right_leg.add_child(right_lower)
    var rs = _shoe(); rs.position=Vector2(6,55); right_lower.add_child(rs)

    left_arm = _limb(Color("ffd7c0"),15,57)
    left_arm.position = Vector2(-42,-22)
    body.add_child(left_arm)
    var lh = _ellipse(10,10,Color("ffd7c0")); lh.position=Vector2(0,55); left_arm.add_child(lh)

    right_arm = _limb(Color("ffd7c0"),15,57)
    right_arm.position = Vector2(42,-22)
    body.add_child(right_arm)
    var rh = _ellipse(10,10,Color("ffd7c0")); rh.position=Vector2(0,55); right_arm.add_child(rh)

    acorn_sprite = Sprite2D.new()
    acorn_sprite.texture = acorn_tex
    acorn_sprite.scale = Vector2(0.25,0.25)
    acorn_sprite.position = Vector2(5,58)
    acorn_sprite.visible = false
    right_arm.add_child(acorn_sprite)

    dress = Sprite2D.new()
    dress.texture = dress_tex
    dress.scale = Vector2(0.79,0.79)
    body.add_child(dress)

    head_pivot = Node2D.new()
    head_pivot.position = Vector2(0,-84)
    body.add_child(head_pivot)

    bun_pivot = Node2D.new()
    bun_pivot.position = Vector2(39,-53)
    head_pivot.add_child(bun_pivot)
    bun = Sprite2D.new()
    bun.texture = bun_tex
    bun.scale = Vector2(0.72,0.72)
    bun_pivot.add_child(bun)

    head = Sprite2D.new()
    head.texture = head_tex
    head.scale = Vector2(0.72,0.72)
    head.position = Vector2(0,-8)
    head_pivot.add_child(head)

    eyelid_l = _ellipse(7.6,5.5,Color("ffd7c0")); eyelid_l.position=Vector2(-14,-11); eyelid_l.visible=false; head_pivot.add_child(eyelid_l)
    eyelid_r = _ellipse(7.6,5.5,Color("ffd7c0")); eyelid_r.position=Vector2(14,-11); eyelid_r.visible=false; head_pivot.add_child(eyelid_r)

func set_move_axis(v: float):
    move_axis = clamp(v,-1.0,1.0) if controls_enabled else 0.0

func request_jump():
    if controls_enabled:
        jump_requested = true

func show_acorn(v: bool):
    held_visible = v
    acorn_sprite.visible = v

func bounce(power := 930.0):
    velocity.y = -power
    state = "bounce"
    state_clock = 0.0

func play_action(kind: String):
    state = kind
    state_clock = 0.0

func lock_controls(v: bool):
    controls_enabled = not v
    if v:
        move_axis = 0.0
        velocity.x = 0.0

func _physics_process(delta):
    previous_vy = velocity.y
    if not is_on_floor():
        velocity.y += GRAVITY * delta

    if controls_enabled:
        var accel = ACCEL if is_on_floor() else AIR_ACCEL
        if abs(move_axis) > 0.01:
            velocity.x = move_toward(velocity.x, move_axis*SPEED, accel*delta)
            facing = sign(move_axis)
        else:
            velocity.x = move_toward(velocity.x,0.0,FRICTION*delta)
        if jump_requested and is_on_floor():
            velocity.y = JUMP_SPEED
            state = "jump"
            state_clock = 0.0
    else:
        velocity.x = move_toward(velocity.x,0.0,FRICTION*delta)
    jump_requested = false

    move_and_slide()

    if previous_vy > 170.0:
        for i in range(get_slide_collision_count()):
            var c = get_slide_collision(i)
            if c.get_normal().y < -0.7:
                landed_on.emit(c.get_collider(), previous_vy)
                break

    _update_state(delta)
    _animate(delta)

func _update_state(delta):
    state_clock += delta
    if state in ["pickup","give","celebrate"] and state_clock < 0.65:
        return
    if not is_on_floor():
        state = "rise" if velocity.y < -80 else "fall"
    elif abs(velocity.x) > 30:
        state = "walk"
    else:
        state = "idle"

func _animate(delta):
    walk_clock += delta
    visual.scale.x = abs(visual.scale.x) * facing
    var speed_ratio = clamp(abs(velocity.x)/SPEED,0.0,1.0)
    if state == "walk":
        var p = walk_clock*(8.5+4.0*speed_ratio)
        var s = sin(p)
        body.position.y = -174 + abs(s)*3
        body.rotation = s*0.025
        left_arm.rotation = 0.08 + s*0.72
        right_arm.rotation = -0.08 - s*0.72
        left_leg.rotation = -s*0.62
        right_leg.rotation = s*0.62
        left_lower.rotation = max(0.0,s)*0.42
        right_lower.rotation = max(0.0,-s)*0.42
        head_pivot.rotation = -s*0.026
        shadow.scale = Vector2(1.0+abs(s)*0.06,1.0-abs(s)*0.03)
    elif state in ["rise","fall","bounce","jump"]:
        var rising = velocity.y < 0
        left_arm.rotation = lerp(left_arm.rotation,-0.88 if rising else -0.55,0.16)
        right_arm.rotation = lerp(right_arm.rotation,0.88 if rising else 0.55,0.16)
        left_leg.rotation = lerp(left_leg.rotation,-0.25,0.18)
        right_leg.rotation = lerp(right_leg.rotation,0.28,0.18)
        left_lower.rotation = lerp(left_lower.rotation,0.52,0.18)
        right_lower.rotation = lerp(right_lower.rotation,0.48,0.18)
        body.rotation = lerp(body.rotation, -0.03*facing if rising else 0.04*facing, 0.10)
        var air = clamp(abs(velocity.y)/900.0,0.0,1.0)
        shadow.scale = Vector2(0.9-air*0.22,0.9-air*0.22)
        shadow.modulate.a = 0.75-air*0.35
    elif state == "pickup":
        body.rotation = lerp(body.rotation,0.10*facing,0.15)
        right_arm.rotation = lerp(right_arm.rotation,-0.95*facing,0.16)
        head_pivot.rotation = lerp(head_pivot.rotation,0.12*facing,0.15)
    elif state == "give":
        right_arm.rotation = lerp(right_arm.rotation,-1.25*facing,0.18)
        left_arm.rotation = lerp(left_arm.rotation,-0.45*facing,0.16)
        head_pivot.rotation = lerp(head_pivot.rotation,-0.08*facing,0.15)
    elif state == "celebrate":
        left_arm.rotation = -1.35 + sin(state_clock*9)*0.12
        right_arm.rotation = 1.35 - sin(state_clock*9)*0.12
        body.position.y = -174 + abs(sin(state_clock*8))*4
    else:
        var t = Time.get_ticks_msec()/1000.0
        var b = sin(t*2.0)
        body.position.y = -174+b*1.1
        body.rotation = lerp(body.rotation,0.0,0.08)
        left_arm.rotation = lerp(left_arm.rotation,0.06+b*0.02,0.08)
        right_arm.rotation = lerp(right_arm.rotation,-0.06-b*0.02,0.08)
        left_leg.rotation = lerp(left_leg.rotation,-0.02,0.10)
        right_leg.rotation = lerp(right_leg.rotation,0.02,0.10)
        left_lower.rotation = lerp(left_lower.rotation,0.0,0.10)
        right_lower.rotation = lerp(right_lower.rotation,0.0,0.10)
        head_pivot.rotation = sin(t*0.75)*0.012
        shadow.scale = shadow.scale.lerp(Vector2.ONE,0.08)
        shadow.modulate.a = lerp(shadow.modulate.a,1.0,0.08)

    _blink(delta)
    _hair(delta)

func _blink(delta):
    blink_clock -= delta
    if blink_duration > 0:
        blink_duration -= delta
        eyelid_l.visible = blink_duration > 0.035
        eyelid_r.visible = eyelid_l.visible
    elif blink_clock <= 0:
        blink_duration = 0.12
        blink_clock = randf_range(2.0,4.8)

func _hair(delta):
    var target = Vector2(-facing*velocity.x*0.026, clamp(velocity.y*0.025,-18.0,18.0))
    hair_velocity += (target-hair_offset)*20.0*delta
    hair_velocity *= exp(-7.0*delta)
    hair_offset += hair_velocity*delta
    hair_offset.x = clamp(hair_offset.x,-18.0,18.0)
    hair_offset.y = clamp(hair_offset.y,-18.0,18.0)
    bun_pivot.position = Vector2(39,-53)+hair_offset
    bun_pivot.rotation = hair_offset.x*0.012-hair_offset.y*0.006

func _limb(col:Color,width:float,length:float)->Node2D:
    var n=Node2D.new(); var l=Line2D.new(); l.points=PackedVector2Array([Vector2.ZERO,Vector2(0,length)]); l.width=width; l.default_color=col; l.antialiased=true; l.begin_cap_mode=Line2D.LINE_CAP_ROUND; l.end_cap_mode=Line2D.LINE_CAP_ROUND; n.add_child(l); return n

func _shoe()->Polygon2D:
    var p=Polygon2D.new(); p.polygon=PackedVector2Array([Vector2(-10,-6),Vector2(13,-6),Vector2(22,3),Vector2(17,10),Vector2(-11,10),Vector2(-16,4)]); p.color=Color("fff8ff"); return p

func _ellipse(rx:float,ry:float,col:Color)->Polygon2D:
    var p=Polygon2D.new()
    var pts=PackedVector2Array()
    for i in range(24):
        var a=TAU*float(i)/24.0
        pts.append(Vector2(cos(a)*rx,sin(a)*ry))
    p.polygon=pts
    p.color=col
    return p
