extends Node2D

var target_x := 180.0
var dragging := false
var moving := false
var speed := 620.0
var facing := 1.0
var walk_time := 0.0
var jumping := false
var idle_tex = preload("res://assets/megan_idle.svg")
var walk1_tex = preload("res://assets/megan_walk1.svg")
var walk2_tex = preload("res://assets/megan_walk2.svg")
var sprite: Sprite2D

func _ready():
    sprite = Sprite2D.new()
    sprite.texture = idle_tex
    sprite.scale = Vector2(0.64,0.64)
    sprite.position = Vector2(0,-82)
    add_child(sprite)
    target_x = global_position.x

func _process(delta):
    if jumping: return
    var dist = target_x-global_position.x
    moving = abs(dist)>3.0
    if moving:
        facing = sign(dist)
        global_position.x = move_toward(global_position.x,target_x,speed*delta)
        walk_time += delta
        sprite.texture = walk1_tex if int(walk_time*8.0)%2==0 else walk2_tex
        sprite.position.y = -82 + sin(walk_time*16.0)*2.5
        sprite.rotation = sin(walk_time*16.0)*0.018
    else:
        sprite.texture=idle_tex
        sprite.position.y=-82
        sprite.rotation=0
    sprite.scale.x=abs(sprite.scale.x)*facing

func can_grab(screen_pos:Vector2)->bool:
    return screen_pos.distance_to(global_position+Vector2(0,-80))<120.0
func begin_drag(): dragging=true
func update_drag(screen_pos:Vector2):
    if dragging and not jumping: target_x=clamp(screen_pos.x,90.0,1190.0)
func end_drag():
    dragging=false
    target_x=global_position.x

func bounce_on(x:float,height:=205.0):
    if jumping:return
    jumping=true
    facing=sign(x-global_position.x) if abs(x-global_position.x)>2 else facing
    target_x=x
    var start=global_position
    var tw=create_tween()
    tw.set_trans(Tween.TRANS_QUAD)
    tw.set_ease(Tween.EASE_OUT)
    tw.tween_property(self,"global_position",Vector2(x,start.y-height),0.34)
    tw.set_ease(Tween.EASE_IN)
    tw.tween_property(self,"global_position",Vector2(x,start.y),0.32)
    tw.finished.connect(func(): jumping=false; target_x=global_position.x)

func little_hop(height:=95.0): bounce_on(global_position.x,height)
