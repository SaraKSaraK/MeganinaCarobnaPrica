extends Node2D

signal action_finished

var target_x := 180.0
var dragging := false
var moving := false
var speed := 560.0
var facing := 1.0
var walk_time := 0.0
var busy := false
var ground_y := 610.0

# `sprite` intentionally remains public because Main.gd rotates it during the magic slide.
# It is now a complete character rig rather than one flat picture.
var sprite: Node2D
var shadow: Polygon2D
var body: Node2D
var head_pivot: Node2D
var bun_pivot: Node2D
var left_arm: Node2D
var right_arm: Node2D
var left_leg: Node2D
var right_leg: Node2D
var left_lower_leg: Node2D
var right_lower_leg: Node2D
var left_hand: Polygon2D
var right_hand: Polygon2D
var left_shoe: Polygon2D
var right_shoe: Polygon2D
var held_acorn_sprite: Sprite2D
var eyelid_left: Polygon2D
var eyelid_right: Polygon2D
var hair_strand: Line2D
var dress: Sprite2D
var head: Sprite2D
var bun: Sprite2D

var action_state := "idle"
var action_clock := 0.0
var idle_clock := 0.0
var blink_clock := 1.8
var blink_duration := 0.0
var look_clock := 0.0
var look_bias := 0.0
var last_global_y := 610.0
var vertical_speed := 0.0
var bun_offset := Vector2.ZERO
var bun_velocity := Vector2.ZERO
var strand_angle := 0.0
var strand_velocity := 0.0
var landing_clock := 0.0

var head_tex = preload("res://assets/megan_head_rig.svg")
var dress_tex = preload("res://assets/megan_dress_rig.svg")
var bun_tex = preload("res://assets/megan_bun_rig.svg")
var acorn_tex = preload("res://assets/acorn.svg")

const BODY_Y := -175.0

func _ready():
    _build_rig()
    target_x = global_position.x
    last_global_y = global_position.y

func _build_rig():
    shadow = Polygon2D.new()
    shadow.polygon = PackedVector2Array([Vector2(-45,0),Vector2(-31,-8),Vector2(31,-8),Vector2(45,0),Vector2(31,8),Vector2(-31,8)])
    shadow.color = Color(0.05,0.04,0.09,0.24)
    shadow.position = Vector2(0,-3)
    add_child(shadow)

    sprite = Node2D.new()
    sprite.position = Vector2(0,-3)
    sprite.scale = Vector2(0.72,0.72)
    add_child(sprite)

    body = Node2D.new()
    body.position = Vector2(0,BODY_Y)
    sprite.add_child(body)

    # Legs are true articulated two-bone limbs.
    left_leg = _make_limb(Color("#ffd8bf"), 18, 61)
    left_leg.position = Vector2(-19,51)
    body.add_child(left_leg)
    left_lower_leg = _make_limb(Color("#ffd8bf"), 17, 58)
    left_lower_leg.position = Vector2(0,55)
    left_leg.add_child(left_lower_leg)
    left_shoe = _shoe(Color("#fff8ff"))
    left_shoe.position = Vector2(5,55)
    left_lower_leg.add_child(left_shoe)

    right_leg = _make_limb(Color("#ffd8bf"), 18, 61)
    right_leg.position = Vector2(19,51)
    body.add_child(right_leg)
    right_lower_leg = _make_limb(Color("#ffd8bf"), 17, 58)
    right_lower_leg.position = Vector2(0,55)
    right_leg.add_child(right_lower_leg)
    right_shoe = _shoe(Color("#fff8ff"))
    right_shoe.position = Vector2(5,55)
    right_lower_leg.add_child(right_shoe)

    # Arms sit behind/around dress and swing independently.
    left_arm = _make_limb(Color("#ffd8bf"), 15, 57)
    left_arm.position = Vector2(-43,-23)
    body.add_child(left_arm)
    left_hand = _circle_poly(10,Color("#ffd8bf"))
    left_hand.position = Vector2(0,55)
    left_arm.add_child(left_hand)

    right_arm = _make_limb(Color("#ffd8bf"), 15, 57)
    right_arm.position = Vector2(43,-23)
    body.add_child(right_arm)
    right_hand = _circle_poly(10,Color("#ffd8bf"))
    right_hand.position = Vector2(0,55)
    right_arm.add_child(right_hand)

    held_acorn_sprite = Sprite2D.new()
    held_acorn_sprite.texture = acorn_tex
    held_acorn_sprite.scale = Vector2(0.23,0.23)
    held_acorn_sprite.position = Vector2(3,58)
    held_acorn_sprite.visible = false
    right_arm.add_child(held_acorn_sprite)

    dress = Sprite2D.new()
    dress.texture = dress_tex
    dress.position = Vector2(0,-2)
    dress.scale = Vector2(0.78,0.78)
    body.add_child(dress)

    head_pivot = Node2D.new()
    head_pivot.position = Vector2(0,-82)
    body.add_child(head_pivot)

    # Hair bun is separate so it can lag behind the skull.
    bun_pivot = Node2D.new()
    bun_pivot.position = Vector2(39,-53)
    head_pivot.add_child(bun_pivot)
    bun = Sprite2D.new()
    bun.texture = bun_tex
    bun.scale = Vector2(0.72,0.72)
    bun.position = Vector2(0,0)
    bun_pivot.add_child(bun)

    # A loose strand gets spring motion too.
    hair_strand = Line2D.new()
    hair_strand.points = PackedVector2Array([Vector2(-34,-35),Vector2(-45,-14),Vector2(-37,8)])
    hair_strand.width = 8.0
    hair_strand.default_color = Color("#5a3427")
    hair_strand.antialiased = true
    head_pivot.add_child(hair_strand)

    head = Sprite2D.new()
    head.texture = head_tex
    head.scale = Vector2(0.72,0.72)
    head.position = Vector2(0,-8)
    head_pivot.add_child(head)

    # Skin-coloured eyelids briefly cover the drawn eyes to create real blinking.
    eyelid_left = _ellipse_poly(7.8,5.8,Color("#ffd8bf"))
    eyelid_left.position = Vector2(-14.4,-10.8)
    eyelid_left.visible = false
    head_pivot.add_child(eyelid_left)
    eyelid_right = _ellipse_poly(7.8,5.8,Color("#ffd8bf"))
    eyelid_right.position = Vector2(14.4,-10.8)
    eyelid_right.visible = false
    head_pivot.add_child(eyelid_right)

func _make_limb(col: Color, width: float, length: float) -> Node2D:
    var n = Node2D.new()
    var line = Line2D.new()
    line.points = PackedVector2Array([Vector2.ZERO,Vector2(0,length)])
    line.width = width
    line.default_color = col
    line.antialiased = true
    line.begin_cap_mode = Line2D.LINE_CAP_ROUND
    line.end_cap_mode = Line2D.LINE_CAP_ROUND
    n.add_child(line)
    var highlight = Line2D.new()
    highlight.points = PackedVector2Array([Vector2(-width*0.17,5),Vector2(-width*0.17,length-7)])
    highlight.width = max(2.0,width*0.17)
    highlight.default_color = Color(1,1,1,0.18)
    highlight.antialiased = true
    highlight.begin_cap_mode = Line2D.LINE_CAP_ROUND
    highlight.end_cap_mode = Line2D.LINE_CAP_ROUND
    n.add_child(highlight)
    return n

func _shoe(col: Color) -> Polygon2D:
    var p = Polygon2D.new()
    p.polygon = PackedVector2Array([Vector2(-10,-6),Vector2(13,-6),Vector2(22,3),Vector2(17,10),Vector2(-11,10),Vector2(-16,4)])
    p.color = col
    return p

func _circle_poly(r: float, col: Color) -> Polygon2D:
    return _ellipse_poly(r,r,col)

func _ellipse_poly(rx: float, ry: float, col: Color) -> Polygon2D:
    var p = Polygon2D.new()
    var pts = PackedVector2Array()
    for i in range(24):
        var a = TAU * float(i) / 24.0
        pts.append(Vector2(cos(a)*rx,sin(a)*ry))
    p.polygon = pts
    p.color = col
    return p

func _process(delta):
    vertical_speed = (global_position.y - last_global_y) / max(delta,0.0001)
    last_global_y = global_position.y
    action_clock += delta

    _update_blink(delta)
    _update_hair_physics(delta)

    if busy:
        _animate_busy(delta)
        return

    var dist = target_x - global_position.x
    moving = abs(dist) > 3.0
    if moving:
        facing = sign(dist)
        global_position.x = move_toward(global_position.x, target_x, speed * delta)
        walk_time += delta
        action_state = "walk"
        _animate_walk(delta)
    else:
        action_state = "idle"
        idle_clock += delta
        _animate_idle(delta)

    sprite.scale.x = abs(sprite.scale.x) * facing

func _animate_walk(_delta):
    var phase = walk_time * 11.2
    var s = sin(phase)
    var c = cos(phase)
    body.position.y = BODY_Y + abs(s)*2.8
    body.rotation = s * 0.025
    head_pivot.position.y = -82.0 - abs(s)*1.8
    head_pivot.rotation = -s*0.035 + c*0.012

    left_arm.rotation = 0.10 + s*0.72
    right_arm.rotation = -0.10 - s*0.72
    left_leg.rotation = -s*0.62
    right_leg.rotation = s*0.62
    left_lower_leg.rotation = max(0.0,s)*0.42 - 0.06
    right_lower_leg.rotation = max(0.0,-s)*0.42 - 0.06
    left_shoe.rotation = -left_lower_leg.rotation*0.42
    right_shoe.rotation = -right_lower_leg.rotation*0.42

    # Slight torso compression/extension gives actual weight instead of paper-doll translation.
    body.scale = Vector2(1.0 + abs(s)*0.015,1.0 - abs(s)*0.025)
    shadow.scale = Vector2(1.02 + abs(s)*0.10,0.94 - abs(s)*0.04)
    shadow.modulate.a = 0.90

func _animate_idle(_delta):
    var t = Time.get_ticks_msec()/1000.0
    var breathe = sin(t*2.0)
    body.position.y = BODY_Y + breathe*1.2
    body.scale = Vector2(1.0-breathe*0.004,1.0+breathe*0.007)
    body.rotation = sin(t*0.65)*0.008

    look_clock -= get_process_delta_time()
    if look_clock <= 0.0:
        look_clock = 2.2 + randf()*2.4
        look_bias = randf_range(-0.055,0.055)
    head_pivot.rotation = lerp(head_pivot.rotation,look_bias + sin(t*0.9)*0.012,0.05)
    head_pivot.position.y = -82.0 + breathe*0.6
    left_arm.rotation = lerp(left_arm.rotation,0.07+sin(t*1.1)*0.025,0.08)
    right_arm.rotation = lerp(right_arm.rotation,-0.07-sin(t*1.1)*0.025,0.08)
    left_leg.rotation = lerp(left_leg.rotation,-0.025,0.1)
    right_leg.rotation = lerp(right_leg.rotation,0.025,0.1)
    left_lower_leg.rotation = lerp(left_lower_leg.rotation,0.0,0.1)
    right_lower_leg.rotation = lerp(right_lower_leg.rotation,0.0,0.1)
    body.scale = body.scale.lerp(Vector2.ONE,0.03)
    shadow.scale = shadow.scale.lerp(Vector2.ONE,0.08)

func _animate_busy(_delta):
    match action_state:
        "jump":
            var lift = clamp(-vertical_speed/650.0,-1.0,1.0)
            # Arms rise in the air, knees bend on descent, head lags slightly.
            left_arm.rotation = lerp(left_arm.rotation,-0.95 + lift*0.12,0.15)
            right_arm.rotation = lerp(right_arm.rotation,0.95 - lift*0.12,0.15)
            left_leg.rotation = lerp(left_leg.rotation,-0.28 + lift*0.14,0.15)
            right_leg.rotation = lerp(right_leg.rotation,0.30 - lift*0.14,0.15)
            left_lower_leg.rotation = lerp(left_lower_leg.rotation,0.55,0.15)
            right_lower_leg.rotation = lerp(right_lower_leg.rotation,0.55,0.15)
            head_pivot.rotation = lerp(head_pivot.rotation,-lift*0.05,0.12)
            body.scale = body.scale.lerp(Vector2(0.98,1.03),0.12)
            var air = clamp(abs(global_position.y-ground_y)/220.0,0.0,1.0)
            shadow.scale = Vector2(1.0-air*0.38,1.0-air*0.38)
            shadow.modulate.a = 1.0-air*0.55
        "celebrate":
            var q = sin(action_clock*9.0)
            left_arm.rotation = -1.45 + q*0.10
            right_arm.rotation = 1.45 - q*0.10
            left_leg.rotation = -0.12
            right_leg.rotation = 0.12
            head_pivot.rotation = sin(action_clock*4.5)*0.09
            body.scale = Vector2(1.0-q*0.025,1.0+q*0.025)
        "pickup":
            left_arm.rotation = lerp(left_arm.rotation,-0.35,0.15)
            right_arm.rotation = lerp(right_arm.rotation,0.55,0.15)
            head_pivot.rotation = lerp(head_pivot.rotation,0.10*facing,0.12)
        "give":
            left_arm.rotation = lerp(left_arm.rotation,-0.15,0.12)
            right_arm.rotation = lerp(right_arm.rotation,-1.05*facing,0.12)
            head_pivot.rotation = lerp(head_pivot.rotation,-0.08*facing,0.12)
        "slide":
            left_arm.rotation = -1.0
            right_arm.rotation = 0.85
            left_leg.rotation = -0.35
            right_leg.rotation = 0.42
            left_lower_leg.rotation = 0.45
            right_lower_leg.rotation = 0.30
            head_pivot.rotation = -0.09

func _update_hair_physics(delta):
    # Spring-damped secondary motion. Horizontal movement and vertical jumping tug the bun
    # after the head instead of gluing it to the skull.
    var target = Vector2(-facing * (16.0 if moving else 0.0),clamp(vertical_speed*0.035,-18.0,18.0))
    if action_state == "jump":
        target.y += clamp(vertical_speed*0.055,-20.0,20.0)
    var stiffness = 22.0
    var damping = 7.5
    bun_velocity += (target-bun_offset)*stiffness*delta
    bun_velocity *= exp(-damping*delta)
    bun_offset += bun_velocity*delta
    bun_offset.x = clamp(bun_offset.x,-18.0,18.0)
    bun_offset.y = clamp(bun_offset.y,-20.0,20.0)
    bun_pivot.position = Vector2(39,-53) + bun_offset
    bun_pivot.rotation = bun_offset.x*0.012 - bun_offset.y*0.008

    var strand_target = clamp(-facing*(0.18 if moving else 0.0) + vertical_speed*0.0008,-0.32,0.32)
    strand_velocity += (strand_target-strand_angle)*18.0*delta
    strand_velocity *= exp(-7.0*delta)
    strand_angle += strand_velocity*delta
    hair_strand.rotation = strand_angle

func _update_blink(delta):
    blink_clock -= delta
    if blink_duration > 0.0:
        blink_duration -= delta
        var show = blink_duration > 0.04
        eyelid_left.visible = show
        eyelid_right.visible = show
        if blink_duration <= 0.0:
            eyelid_left.visible = false
            eyelid_right.visible = false
    elif blink_clock <= 0.0:
        blink_duration = 0.13
        blink_clock = randf_range(2.0,4.6)

func can_grab(world_pos: Vector2) -> bool:
    return world_pos.distance_to(global_position + Vector2(0,-88)) < 118.0 and not busy

func begin_drag():
    if busy:
        return
    dragging = true

func update_drag(world_pos: Vector2):
    if dragging and not busy:
        target_x = clamp(world_pos.x,70.0,6330.0)

func end_drag():
    dragging = false
    target_x = global_position.x

func stop():
    target_x = global_position.x
    dragging = false

func face_toward(x: float):
    if abs(x-global_position.x) > 2.0:
        facing = sign(x-global_position.x)
        sprite.scale.x = abs(sprite.scale.x)*facing

func jump_to(dest: Vector2, height := 180.0, duration := 0.68):
    if busy:
        return
    busy = true
    stop()
    face_toward(dest.x)
    action_state = "jump"
    action_clock = 0.0

    # Anticipation crouch before launch.
    var prep = create_tween()
    prep.tween_property(body,"scale",Vector2(1.08,0.88),0.09).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    prep.parallel().tween_property(body,"position:y",BODY_Y+9.0,0.09)
    await prep.finished

    var start = global_position
    var mid = Vector2((start.x+dest.x)*0.5,min(start.y,dest.y)-height)
    var tw = create_tween()
    tw.set_trans(Tween.TRANS_QUAD)
    tw.set_ease(Tween.EASE_OUT)
    tw.tween_property(self,"global_position",mid,duration*0.5)
    tw.set_ease(Tween.EASE_IN)
    tw.tween_property(self,"global_position",dest,duration*0.5)
    await tw.finished

    # Landing has compression, hair overshoot and recovery.
    landing_clock = 0.16
    var land = create_tween()
    land.tween_property(body,"scale",Vector2(1.10,0.82),0.07)
    land.parallel().tween_property(body,"position:y",BODY_Y+9.0,0.07)
    land.tween_property(body,"scale",Vector2(0.97,1.05),0.08).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    land.parallel().tween_property(body,"position:y",BODY_Y-3.0,0.08)
    land.tween_property(body,"scale",Vector2.ONE,0.10)
    land.parallel().tween_property(body,"position:y",BODY_Y,0.10)
    await land.finished

    busy = false
    target_x = global_position.x
    action_state = "idle"
    shadow.modulate.a = 1.0
    action_finished.emit()

func bounce_here(height := 170.0, duration := 0.56):
    jump_to(Vector2(global_position.x,ground_y),height,duration)

func celebrate():
    if busy:
        return
    busy = true
    stop()
    action_state = "celebrate"
    action_clock = 0.0
    var tw = create_tween()
    tw.tween_property(body,"position:y",BODY_Y-26.0,0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.parallel().tween_property(body,"rotation",-0.05*facing,0.18)
    tw.tween_property(body,"position:y",BODY_Y,0.22)
    tw.parallel().tween_property(body,"rotation",0.04*facing,0.22)
    tw.tween_property(body,"rotation",0.0,0.12)
    tw.tween_interval(0.10)
    await tw.finished
    busy = false
    action_state = "idle"
    action_finished.emit()

func set_holding_acorn(value: bool):
    if held_acorn_sprite:
        held_acorn_sprite.visible = value

func play_pickup():
    if busy:
        return
    busy = true
    stop()
    action_state = "pickup"
    action_clock = 0.0
    var tw = create_tween()
    tw.tween_property(body,"rotation",0.08*facing,0.10)
    tw.parallel().tween_property(body,"position:y",BODY_Y+11.0,0.10)
    tw.tween_interval(0.10)
    tw.tween_property(body,"rotation",0.0,0.15)
    tw.parallel().tween_property(body,"position:y",BODY_Y,0.15)
    tw.finished.connect(func():
        busy=false
        action_state="idle"
        action_finished.emit()
    )

func play_give(target_x_pos: float):
    if busy:
        return
    busy = true
    stop()
    face_toward(target_x_pos)
    action_state = "give"
    action_clock = 0.0
    var tw = create_tween()
    tw.tween_property(body,"position:x",5.0*facing,0.12)
    tw.tween_interval(0.18)
    tw.tween_property(body,"position:x",0.0,0.15)
    await tw.finished
    busy=false
    action_state="idle"
    action_finished.emit()

func react_to_magic():
    if busy:
        return
    head_pivot.rotation = -0.08*facing
    var tw = create_tween()
    tw.tween_property(head_pivot,"scale",Vector2(1.07,1.07),0.10).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.tween_property(head_pivot,"scale",Vector2.ONE,0.16)

func set_slide_pose():
    busy = true
    action_state = "slide"
    action_clock = 0.0
    sprite.rotation = 0.16*facing

func finish_slide():
    busy = false
    action_state = "celebrate"
    sprite.rotation = 0.0
    target_x = global_position.x
