extends Node2D

const W := 5120.0
const H := 720.0
const GROUND := 610.0
const PLAYER_START := Vector2(180,610)
const BERRY_TEX = preload("res://assets/berry.svg")
const STONE_TEX = preload("res://assets/magic_stone.svg")

var player: CharacterBody2D
var camera: Camera2D
var left_down=false
var right_down=false
var action_btn: Button
var hint: Label
var objective: Label
var stone_icons: Array=[]
var held_berry=false
var stones=0
var candies=0
var stars=0
var checkpoint_x=180.0
var wall_broken=false
var bridge_down=false
var cage_open=false
var creature_hit=false
var gate_open=false
var berry_bushes:Array=[]
var break_wall:Node2D
var bridge:Node2D
var target:Node2D
var cage:Node2D
var lever:Node2D
var creature:Node2D
var gate:Node2D
var sfx:AudioStreamPlayer
var music:AudioStreamPlayer
var fade:ColorRect
var last_action=""
var elapsed=0.0
var candy_nodes:Array=[]
var butterfly_nodes:Array=[]

func _ready():
    randomize()
    _world()
    _player()
    _ui()
    _audio()
    _say("Whoa! That cheeky forest sprite stole the three Rainbow Stones! Let's get them back!")

func _world():
    var bg=Sprite2D.new(); bg.texture=load("res://assets/forest_panorama.jpg"); bg.position=Vector2(W/2,360); bg.z_index=-100; add_child(bg)
    var shade=ColorRect.new(); shade.position=Vector2(0,0); shade.size=Vector2(W,H); shade.color=Color(0.04,0.08,0.09,0.06); shade.z_index=-90; add_child(shade)
    # playable land sections
    _ground_segment(0,1580)
    _ground_segment(2050,5120)
    _water(1580,2050)
    _platform(Vector2(650,510),Vector2(220,28))
    _platform(Vector2(1130,470),Vector2(230,28))
    _platform(Vector2(2300,500),Vector2(230,28))
    _platform(Vector2(2740,455),Vector2(210,28))
    _platform(Vector2(3240,500),Vector2(230,28))
    _platform(Vector2(3650,455),Vector2(200,28))
    _ambient()
    _berry_bush(Vector2(420,GROUND-15))
    _berry_bush(Vector2(2140,GROUND-15))
    _berry_bush(Vector2(3440,GROUND-15))
    _cracked_wall()
    _mushroom(Vector2(1000,GROUND),920)
    _stone(Vector2(1220,410),1)
    _bridge_puzzle()
    _cage_puzzle()
    _mushroom(Vector2(2630,GROUND),980)
    _creature_section()
    _mushroom(Vector2(3500,GROUND),940)
    _finish_gate()
    _bounds()

func _ground_segment(a:float,b:float):
    var body=StaticBody2D.new(); body.position=Vector2((a+b)/2,GROUND+70); body.set_meta("kind","ground"); add_child(body)
    var cs=CollisionShape2D.new(); var r=RectangleShape2D.new(); r.size=Vector2(b-a,140); cs.shape=r; body.add_child(cs)
    var p=Polygon2D.new(); p.polygon=PackedVector2Array([Vector2(a,GROUND),Vector2(b,GROUND),Vector2(b,H),Vector2(a,H)]); p.color=Color("35542b"); p.z_index=-4; add_child(p)
    var lip=Polygon2D.new(); lip.polygon=PackedVector2Array([Vector2(a,GROUND-18),Vector2(b,GROUND-18),Vector2(b,GROUND+10),Vector2(a,GROUND+10)]); lip.color=Color("79b94f"); lip.z_index=-3; add_child(lip)

func _water(a:float,b:float):
    var p=Polygon2D.new(); p.polygon=PackedVector2Array([Vector2(a,GROUND+8),Vector2(b,GROUND+8),Vector2(b,H),Vector2(a,H)]); p.color=Color(0.18,0.62,0.86,0.72); p.z_index=-2; add_child(p)
    for x in [1650.0,1790.0,1930.0]: _platform(Vector2(x,565),Vector2(110,22))

func _platform(pos:Vector2,size:Vector2):
    var b=StaticBody2D.new(); b.position=pos; b.set_meta("kind","ledge"); add_child(b)
    var cs=CollisionShape2D.new(); var r=RectangleShape2D.new(); r.size=size; cs.shape=r; b.add_child(cs)
    var p=Polygon2D.new(); p.polygon=PackedVector2Array([Vector2(-size.x/2,-size.y/2),Vector2(size.x/2,-size.y/2),Vector2(size.x/2,size.y/2),Vector2(-size.x/2,size.y/2)]); p.color=Color("628d3e"); b.add_child(p)
    var lip=Polygon2D.new(); lip.polygon=PackedVector2Array([Vector2(-size.x/2,-size.y/2),Vector2(size.x/2,-size.y/2),Vector2(size.x/2,-size.y/2+7),Vector2(-size.x/2,-size.y/2+7)]); lip.color=Color("b7df76"); b.add_child(lip)

func _ambient():
    for i in range(42):
        var f=Node2D.new(); f.position=Vector2(80+i*118,GROUND-18); f.z_index=3; f.set_meta("phase",i*.41); add_child(f)
        var stem=Line2D.new(); stem.points=PackedVector2Array([Vector2(0,15),Vector2(0,-15)]); stem.width=3; stem.default_color=Color("4e8e3b"); f.add_child(stem)
        for k in range(5):
            var pet=_ellipse(7,4,[Color("ff82c3"),Color("77ddff"),Color("a990ff"),Color("ffd867")][i%4]); pet.position=Vector2(cos(TAU*k/5)*7,-15+sin(TAU*k/5)*7); f.add_child(pet)
    for p in [Vector2(300,260),Vector2(1380,300),Vector2(2200,260),Vector2(3100,310),Vector2(4200,250)]:
        var b=Node2D.new(); b.set_script(load("res://scripts/Butterfly.gd")); b.position=p; b.z_index=12; add_child(b); butterfly_nodes.append(b)
    for x in range(250,5000,310):
        var star=_ellipse(5,5,Color(1,0.88,0.32,0.75)); star.position=Vector2(x,350+(x%170)); star.set_meta("phase",float(x)*.01); star.z_index=2; add_child(star)

func _berry_bush(pos:Vector2):
    var n=Node2D.new(); n.position=pos; n.set_meta("kind","berry_bush"); n.set_meta("cool",0.0); add_child(n); berry_bushes.append(n)
    for q in [Vector2(-35,0),Vector2(0,-18),Vector2(35,0),Vector2(-12,12),Vector2(20,15)]:
        var leaf=_ellipse(42,28,Color("2f8a45")); leaf.position=q; n.add_child(leaf)
    for q in [Vector2(-24,-15),Vector2(4,-28),Vector2(27,-7),Vector2(0,5)]:
        var berry=_ellipse(7,7,Color("ff4f72")); berry.position=q; n.add_child(berry)

func _cracked_wall():
    break_wall=StaticBody2D.new(); break_wall.position=Vector2(830,500); break_wall.set_meta("kind","break_wall"); break_wall.set_meta("hits",0); add_child(break_wall)
    var cs=CollisionShape2D.new(); var r=RectangleShape2D.new(); r.size=Vector2(70,220); cs.shape=r; break_wall.add_child(cs)
    var p=Polygon2D.new(); p.polygon=PackedVector2Array([Vector2(-35,-110),Vector2(35,-110),Vector2(35,110),Vector2(-35,110)]); p.color=Color("7d6b61"); break_wall.add_child(p); break_wall.set_meta("visual",p)
    for y in [-70.0,-10.0,50.0]:
        var l=Line2D.new(); l.points=PackedVector2Array([Vector2(-8,y-20),Vector2(5,y),Vector2(-12,y+22)]); l.width=4; l.default_color=Color("392f2c"); break_wall.add_child(l)

func _mushroom(pos:Vector2,power:float):
    var b=StaticBody2D.new(); b.position=pos; b.set_meta("kind","mushroom"); b.set_meta("power",power); b.set_meta("last",-10.0); add_child(b)
    var cs=CollisionShape2D.new(); var r=RectangleShape2D.new(); r.size=Vector2(150,16); cs.shape=r; cs.position=Vector2(0,-48); b.add_child(cs)
    var stem=Polygon2D.new(); stem.polygon=PackedVector2Array([Vector2(-18,0),Vector2(18,0),Vector2(12,-48),Vector2(-12,-48)]); stem.color=Color("f1dfc7"); b.add_child(stem)
    var cap=_ellipse(80,35,Color("c35cff")); cap.position=Vector2(0,-52); b.add_child(cap); b.set_meta("cap",cap)

func _stone(pos:Vector2,id:int):
    var a=Area2D.new(); a.position=pos; a.set_meta("kind","stone"); a.set_meta("id",id); add_child(a)
    var cs=CollisionShape2D.new(); var c=CircleShape2D.new(); c.radius=38; cs.shape=c; a.add_child(cs)
    var s=Sprite2D.new(); s.texture=STONE_TEX; s.scale=Vector2(.58,.58); a.add_child(s)
    a.body_entered.connect(func(body):
        if body == player:
            _collect_stone(a)
    )

func _bridge_puzzle():
    target=Node2D.new(); target.position=Vector2(1510,430); target.set_meta("kind","target"); add_child(target)
    var ring=_ellipse(34,34,Color("ffcf4f")); target.add_child(ring); var inner=_ellipse(21,21,Color("ff5e75")); target.add_child(inner)
    bridge=StaticBody2D.new(); bridge.position=Vector2(1815,520); bridge.rotation=-1.05; bridge.set_meta("kind","bridge"); add_child(bridge)
    var cs=CollisionShape2D.new(); var r=RectangleShape2D.new(); r.size=Vector2(390,28); cs.shape=r; bridge.add_child(cs)
    var p=Polygon2D.new(); p.polygon=PackedVector2Array([Vector2(-195,-14),Vector2(195,-14),Vector2(195,14),Vector2(-195,14)]); p.color=Color("9b6738"); bridge.add_child(p)

func _cage_puzzle():
    cage=Node2D.new(); cage.position=Vector2(2920,520); cage.set_meta("kind","cage"); add_child(cage)
    for x in [-65.0,-32.0,0.0,32.0,65.0]:
        var l=Line2D.new(); l.points=PackedVector2Array([Vector2(x,-85),Vector2(x,75)]); l.width=8; l.default_color=Color("6b4f7f"); cage.add_child(l)
    for y in [-80.0,70.0]:
        var l=Line2D.new(); l.points=PackedVector2Array([Vector2(-75,y),Vector2(75,y)]); l.width=8; l.default_color=Color("6b4f7f"); cage.add_child(l)
    _stone(Vector2(2920,510),2)
    lever=Node2D.new(); lever.position=Vector2(2740,390); lever.set_meta("kind","lever"); add_child(lever)
    var base=_ellipse(24,24,Color("59496d")); lever.add_child(base)
    var arm=Line2D.new(); arm.points=PackedVector2Array([Vector2(0,0),Vector2(0,-55)]); arm.width=10; arm.default_color=Color("f4d15f"); lever.add_child(arm); lever.set_meta("arm",arm)

func _creature_section():
    creature=Node2D.new(); creature.position=Vector2(3850,GROUND-75); creature.set_meta("kind","creature"); add_child(creature)
    var body=_ellipse(48,55,Color("5bd8c4")); creature.add_child(body)
    var ear1=Polygon2D.new(); ear1.polygon=PackedVector2Array([Vector2(-35,-35),Vector2(-55,-85),Vector2(-8,-55)]); ear1.color=Color("5bd8c4"); creature.add_child(ear1)
    var ear2=Polygon2D.new(); ear2.polygon=PackedVector2Array([Vector2(35,-35),Vector2(55,-85),Vector2(8,-55)]); ear2.color=Color("5bd8c4"); creature.add_child(ear2)
    for x in [-16.0,16.0]:
        var e=_ellipse(5,7,Color("1c2230"))
        e.position=Vector2(x,-10)
        creature.add_child(e)
    var held=Sprite2D.new(); held.texture=STONE_TEX; held.scale=Vector2(.35,.35); held.position=Vector2(0,-85); creature.add_child(held); creature.set_meta("stone",held)

func _finish_gate():
    gate=Node2D.new(); gate.position=Vector2(4680,430); gate.set_meta("kind","gate"); add_child(gate)
    for x in [-120.0,120.0]:
        var pillar=Polygon2D.new(); pillar.polygon=PackedVector2Array([Vector2(x-28,180),Vector2(x+28,180),Vector2(x+28,-160),Vector2(x-28,-160)]); pillar.color=Color("7d68b5"); gate.add_child(pillar)
    var arch=Line2D.new()
    var pts=PackedVector2Array()
    for i in range(17):
        var a=PI+PI*i/16.0
        pts.append(Vector2(cos(a)*120,sin(a)*120-40))
    arch.points=pts
    arch.width=30
    arch.default_color=Color("a68ce8")
    gate.add_child(arch)
    for i in range(3):
        var slot=_ellipse(22,22,Color(0.18,0.17,0.25,0.9)); slot.position=Vector2(-60+i*60,-55); gate.add_child(slot); stone_icons.append(slot)
    var blocker=StaticBody2D.new(); blocker.position=Vector2(4680,470); blocker.set_meta("kind","gate_block"); add_child(blocker); var cs=CollisionShape2D.new(); var r=RectangleShape2D.new(); r.size=Vector2(180,280); cs.shape=r; blocker.add_child(cs); gate.set_meta("blocker",blocker)

func _bounds():
    for x in [-40.0,W+40.0]:
        var b=StaticBody2D.new(); b.position=Vector2(x,360); add_child(b); var cs=CollisionShape2D.new(); var r=RectangleShape2D.new(); r.size=Vector2(80,720); cs.shape=r; b.add_child(cs)

func _player():
    player=CharacterBody2D.new(); player.set_script(load("res://scripts/Player.gd")); player.position=PLAYER_START; player.z_index=20; add_child(player); player.landed_on.connect(_landed)
    camera=Camera2D.new(); camera.position=Vector2(110, -70); camera.position_smoothing_enabled=true; camera.position_smoothing_speed=5.5; camera.limit_left=0; camera.limit_right=int(W); camera.limit_top=0; camera.limit_bottom=720; player.add_child(camera); camera.make_current()

func _ui():
    var layer=CanvasLayer.new(); add_child(layer)
    var top=Panel.new(); top.position=Vector2(28,22); top.size=Vector2(310,80); layer.add_child(top)
    objective=Label.new(); objective.position=Vector2(20,13); objective.size=Vector2(270,55); objective.text="RAINBOW STONES   ◇ ◇ ◇\nFind the stolen stones"; objective.add_theme_font_size_override("font_size",22); top.add_child(objective)
    hint=Label.new(); hint.position=Vector2(380,28); hint.size=Vector2(520,60); hint.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; hint.add_theme_font_size_override("font_size",21); hint.add_theme_color_override("font_color",Color("fff1a8")); layer.add_child(hint)
    var left=_button("◀",Vector2(42,545),Vector2(112,112)); var right=_button("▶",Vector2(164,545),Vector2(112,112)); var jump=_button("↑",Vector2(1025,545),Vector2(112,112)); action_btn=_button("✦",Vector2(1145,545),Vector2(112,112)); layer.add_child(left);layer.add_child(right);layer.add_child(jump);layer.add_child(action_btn)
    left.button_down.connect(func(): left_down=true); left.button_up.connect(func(): left_down=false)
    right.button_down.connect(func(): right_down=true); right.button_up.connect(func(): right_down=false)
    jump.pressed.connect(func(): player.request_jump())
    action_btn.pressed.connect(_action)
    fade=ColorRect.new(); fade.position=Vector2.ZERO; fade.size=Vector2(1280,720); fade.color=Color(0.15,0.04,0.30,0); fade.mouse_filter=Control.MOUSE_FILTER_IGNORE; layer.add_child(fade)

func _button(t:String,pos:Vector2,size:Vector2)->Button:
    var b=Button.new(); b.text=t; b.position=pos; b.size=size; b.add_theme_font_size_override("font_size",38); b.modulate=Color(1,1,1,.86); return b

func _audio():
    music=AudioStreamPlayer.new(); music.stream=load("res://audio/forest_music.wav"); music.volume_db=-18; add_child(music); music.play()
    sfx=AudioStreamPlayer.new(); add_child(sfx)

func _process(delta):
    elapsed+=delta
    if player:
        player.set_move_axis((-1.0 if left_down else 0.0)+(1.0 if right_down else 0.0))
        if player.position.y>700: _recover()
        checkpoint_x=max(checkpoint_x, player.position.x-100 if player.position.x<1550 or player.position.x>2050 else checkpoint_x)
    _animate_world(delta)
    _context()

func _animate_world(delta):
    if creature and not creature_hit and player:
        var d=player.position.x-creature.position.x
        if d>-650 and d<0: creature.position.x=min(4240.0,creature.position.x+delta*75.0)
        creature.position.y=GROUND-75+sin(elapsed*5)*5
    for b in butterfly_nodes: if is_instance_valid(b): pass
    for c in candy_nodes:
        if is_instance_valid(c): c.rotation+=delta*2.2

func _context():
    if not player:return
    var best=""; var txt=""
    if held_berry: best="throw"; txt="Throw berry!"
    for b in berry_bushes:
        if player.position.distance_to(b.position)<115 and not held_berry: best="berry"; txt="Pick a magic berry"
    if player.position.distance_to(lever.position)<105 and not cage_open: best="lever"; txt="Pull the lever!"
    if creature and player.position.distance_to(creature.position)<480 and held_berry and not creature_hit: best="throw"; txt="Bonk the thief!"
    if gate and player.position.distance_to(gate.position)<190 and stones>=3: best="finish"; txt="The Rainbow Gate is open!"
    last_action=best; hint.text=txt
    action_btn.text={"berry":"🤲","throw":"➤","lever":"☝","finish":"✨"}.get(best,"✦")
    action_btn.disabled=(best=="")

func _action():
    match last_action:
        "berry": _pickup_berry()
        "throw": _throw_berry()
        "lever": _pull_lever()
        "finish": _finish()

func _pickup_berry():
    held_berry=true; player.show_acorn(true); player.acorn_sprite.texture=BERRY_TEX; player.acorn_sprite.modulate=Color.WHITE; player.play_action("pickup"); _play("res://audio/pickup.wav"); _say("Got one! I can throw this!")

func _throw_berry():
    if not held_berry:return
    held_berry=false; player.show_acorn(false); player.play_action("give")
    var berry=Area2D.new(); berry.position=player.position+Vector2(player.facing*45,-100); berry.z_index=22; add_child(berry)
    var sp=Sprite2D.new(); sp.texture=BERRY_TEX; sp.scale=Vector2(.35,.35); berry.add_child(sp)
    var dir=player.facing; var vx=620.0*dir; var vy=-230.0; var life=0.0
    var tw=create_tween(); tw.set_parallel(true); tw.tween_property(berry,"position:x",berry.position.x+dir*520,0.72).set_trans(Tween.TRANS_QUAD); tw.tween_property(berry,"position:y",berry.position.y-80,0.34).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT); tw.chain().tween_property(berry,"position:y",GROUND-20,0.38).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    # resolve hit based on direction/range immediately, visuals continue
    var fromx=player.position.x; var tox=fromx+dir*560
    if not wall_broken and _between(break_wall.position.x,fromx,tox): _break_wall()
    elif not bridge_down and _between(target.position.x,fromx,tox): _lower_bridge()
    elif creature and not creature_hit and _between(creature.position.x,fromx,tox): _hit_creature()
    tw.finished.connect(func(): if is_instance_valid(berry): berry.queue_free())

func _between(x:float,a:float,b:float)->bool: return x>=min(a,b)-40 and x<=max(a,b)+40

func _break_wall():
    wall_broken=true; _play("res://audio/splash.wav"); _say("CRASH! Secret path!")
    var tw=create_tween(); tw.tween_property(break_wall,"scale",Vector2(1.25,.65),.12); tw.tween_property(break_wall,"rotation",.35,.18); tw.tween_property(break_wall,"modulate:a",0.0,.25); tw.finished.connect(func(): break_wall.queue_free())
    _burst(Vector2(830,500),Color("d2b48c"),18)

func _lower_bridge():
    bridge_down=true; _play("res://audio/sparkle.wav"); _say("Yes! The bridge is coming down!")
    var tw=create_tween(); tw.tween_property(bridge,"rotation",0.0,.8).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
    target.modulate=Color("9dff9a")

func _pull_lever():
    cage_open=true; _play("res://audio/sparkle.wav"); _say("You found the lever!")
    var arm=lever.get_meta("arm") as Line2D; arm.rotation=1.2
    var tw=create_tween(); tw.tween_property(cage,"position:y",300,.75).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN); tw.tween_callback(func(): cage.visible=false)

func _hit_creature():
    creature_hit=true; _play("res://audio/boing.wav"); _say("BONK! It dropped the last stone!")
    var st=creature.get_meta("stone") as Sprite2D; st.visible=false
    var tw=create_tween(); tw.tween_property(creature,"rotation",TAU*1.5,.65); tw.parallel().tween_property(creature,"position:y",GROUND-170,.3); tw.tween_property(creature,"position:y",GROUND-75,.3)
    _stone(creature.position+Vector2(-80,10),3)

func _landed(collider,impact):
    if collider and collider.has_meta("kind") and collider.get_meta("kind")=="mushroom":
        var now=Time.get_ticks_msec()/1000.0
        if now-float(collider.get_meta("last"))>.45:
            collider.set_meta("last",now); player.bounce(float(collider.get_meta("power"))); _play("res://audio/boing.wav")
            var cap=collider.get_meta("cap") as Node2D; var tw=create_tween(); tw.tween_property(cap,"scale",Vector2(1.15,.55),.08); tw.tween_property(cap,"scale",Vector2.ONE,.16).set_trans(Tween.TRANS_BACK)
            _spawn_candy(collider.position+Vector2(0,-95))

func _spawn_candy(pos:Vector2):
    var a=Area2D.new(); a.position=pos; a.z_index=18; add_child(a); candy_nodes.append(a)
    var cs=CollisionShape2D.new(); var c=CircleShape2D.new(); c.radius=22; cs.shape=c; a.add_child(cs)
    var p=Polygon2D.new(); p.polygon=PackedVector2Array([Vector2(-18,-10),Vector2(18,-10),Vector2(18,10),Vector2(-18,10)]); p.color=Color("ff5f9f"); a.add_child(p)
    for x in [-28.0,28.0]:
        var w=Polygon2D.new()
        w.polygon=PackedVector2Array([Vector2(x,0),Vector2(x-sign(x)*14,-14),Vector2(x-sign(x)*14,14)])
        w.color=Color("ffd2e6")
        a.add_child(w)
    var dest=pos+Vector2(randf_range(-60,60),80); var tw=create_tween(); tw.tween_property(a,"position",dest,.45).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
    a.body_entered.connect(func(body):
        if body==player and is_instance_valid(a):
            candies+=1
            _play("res://audio/pickup.wav")
            a.queue_free()
    )

func _collect_stone(a:Area2D):
    if not is_instance_valid(a):return
    # Stone 2 cannot be collected before cage opens
    if int(a.get_meta("id"))==2 and not cage_open:return
    stones+=1; _play("res://audio/sparkle.wav"); _burst(a.position,Color("8df8ff"),22); a.queue_free(); player.play_action("celebrate")
    var marks=""
    for i in range(3):
        marks += "◆ " if i<stones else "◇ "
    objective.text="RAINBOW STONES   "+marks+"\n"+(["Find the stolen stones","Two more!","One more!","Take them to the Rainbow Gate!"][stones])
    _say(["","First stone! Two more!","Two stones! One more!","All three! To the Rainbow Gate!"][stones])
    if stones>=3: _open_gate()

func _open_gate():
    gate_open=true
    for i in range(stone_icons.size()):
        stone_icons[i].color=Color("78f5ff")
    var blocker=gate.get_meta("blocker") as Node; if is_instance_valid(blocker): blocker.queue_free()
    _burst(gate.position+Vector2(0,-80),Color("d99cff"),35)

func _finish():
    player.lock_controls(true); _say("Rainbow Gate restored! Adventure complete!"); player.play_action("celebrate")
    var tw=create_tween(); tw.tween_property(fade,"color:a",.92,1.1); tw.tween_callback(_level_complete)

func _level_complete():
    objective.text="LEVEL COMPLETE!  ★\nThe Rainbow Gate is shining again!"
    hint.text="You did it!"
    var tw=create_tween(); tw.tween_interval(1.4); tw.tween_property(fade,"color:a",0.0,.8); tw.tween_callback(func(): player.position=Vector2(4860,GROUND); player.lock_controls(false))

func _recover():
    player.position=Vector2(clamp(checkpoint_x,100.0,W-200.0),GROUND-10); player.velocity=Vector2.ZERO; _say("Splash! Back we go!")

func _burst(pos:Vector2,col:Color,count:int):
    for i in range(count):
        var d=_ellipse(randf_range(3,7),randf_range(3,7),col); d.position=pos; d.z_index=40; add_child(d)
        var ang=randf_range(0,TAU); var dist=randf_range(50,150); var tw=create_tween(); tw.tween_property(d,"position",pos+Vector2(cos(ang),sin(ang))*dist,.55); tw.parallel().tween_property(d,"modulate:a",0.0,.55); tw.finished.connect(func(): d.queue_free())

func _play(path:String):
    sfx.stream=load(path)
    sfx.play()
func _say(text:String):
    hint.text=text
    if DisplayServer.has_feature("tts"): DisplayServer.tts_speak(text,"",55,1.05,1.05,1)

func _ellipse(rx:float,ry:float,col:Color)->Polygon2D:
    var p=Polygon2D.new()
    var pts=PackedVector2Array()
    for i in range(24):
        var a=TAU*i/24.0
        pts.append(Vector2(cos(a)*rx,sin(a)*ry))
    p.polygon=pts
    p.color=col
    return p
