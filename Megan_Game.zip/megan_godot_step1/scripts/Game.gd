extends Node2D

const VIEW_W := 1280.0
const GROUND_Y := 612.0
const WORLD_W := 3500.0

var player
var camera: Camera2D
var music: AudioStreamPlayer
var sfx: AudioStreamPlayer
var left_down := false
var right_down := false
var held_acorn := false
var squirrel_fed := false
var portal_ready := false
var portal_transitioning := false
var acorn_area: Area2D
var squirrel: Node2D
var squirrel_mouth: Node2D
var portal: Node2D
var action_button: Button
var hint_label: Label
var fade: ColorRect
var mushroom_nodes := []
var grass_nodes := []
var flower_nodes := []
var butterflies := []
var time_alive := 0.0
var secret_arrived := false

func _ready():
    _build_world()
    _build_player()
    _build_ui()
    _start_audio()
    _say("Ooooh! Look at this forest! Let's see what we can make happen!")

func _build_world():
    _build_far_background()
    _build_ground()
    _build_foreground_life()
    _build_mushrooms()
    _build_acorn()
    _build_squirrel()
    _build_portal()
    _build_secret_area()

func _build_far_background():
    var bg = Sprite2D.new()
    bg.texture = load("res://assets/far_forest.jpg")
    bg.position = Vector2(WORLD_W/2.0,360)
    bg.scale = Vector2(WORLD_W/3584.0,1.0)
    bg.z_index = -50
    add_child(bg)

    var haze = Polygon2D.new()
    haze.polygon = PackedVector2Array([Vector2(0,0),Vector2(WORLD_W,0),Vector2(WORLD_W,720),Vector2(0,720)])
    haze.color = Color(0.12,0.16,0.24,0.10)
    haze.z_index = -45
    add_child(haze)

    for i in range(13):
        var trunk = Polygon2D.new()
        var x = 100 + i*270
        trunk.polygon = PackedVector2Array([Vector2(x-24,610),Vector2(x+24,610),Vector2(x+14,260-(i%3)*35),Vector2(x-9,260-(i%3)*35)])
        trunk.color = Color(0.18,0.19,0.12,0.35)
        trunk.z_index = -15
        add_child(trunk)
        for j in range(3):
            var crown = _ellipse_poly(90-j*14,70-j*10,Color(0.15,0.33+0.03*j,0.18,0.34))
            crown.position = Vector2(x + (j-1)*34,260-(i%3)*35+j*32)
            crown.z_index=-16
            add_child(crown)

func _build_ground():
    var ground = StaticBody2D.new()
    ground.name = "Ground"
    ground.set_meta("kind","ground")
    add_child(ground)

    var cs = CollisionShape2D.new()
    var rect = RectangleShape2D.new()
    rect.size = Vector2(WORLD_W,230)
    cs.shape = rect
    cs.position = Vector2(WORLD_W/2.0,GROUND_Y+115)
    ground.add_child(cs)

    var soil = Polygon2D.new()
    soil.polygon = PackedVector2Array([Vector2(0,GROUND_Y),Vector2(WORLD_W,GROUND_Y),Vector2(WORLD_W,720),Vector2(0,720)])
    soil.color = Color("405f2f")
    soil.z_index = -2
    add_child(soil)

    var moss = Polygon2D.new()
    moss.polygon = PackedVector2Array([Vector2(0,GROUND_Y-17),Vector2(WORLD_W,GROUND_Y-17),Vector2(WORLD_W,GROUND_Y+10),Vector2(0,GROUND_Y+10)])
    moss.color = Color("80b84b")
    moss.z_index = -1
    add_child(moss)

    _platform(Vector2(760,515),Vector2(230,28),Color("6c963d"),"ledge")
    _platform(Vector2(1610,500),Vector2(250,26),Color("739f42"),"ledge")

func _platform(pos:Vector2,size:Vector2,col:Color,kind:String):
    var b=StaticBody2D.new(); b.position=pos; b.set_meta("kind",kind); add_child(b)
    var cs=CollisionShape2D.new(); var r=RectangleShape2D.new(); r.size=size; cs.shape=r; b.add_child(cs)
    var p=Polygon2D.new(); p.polygon=PackedVector2Array([Vector2(-size.x/2,-size.y/2),Vector2(size.x/2,-size.y/2),Vector2(size.x/2,size.y/2),Vector2(-size.x/2,size.y/2)]); p.color=col; b.add_child(p)
    var lip=Polygon2D.new(); lip.polygon=PackedVector2Array([Vector2(-size.x/2,-size.y/2),Vector2(size.x/2,-size.y/2),Vector2(size.x/2,-size.y/2+7),Vector2(-size.x/2,-size.y/2+7)]); lip.color=Color("acd56a"); b.add_child(lip)

func _build_foreground_life():
    for i in range(58):
        var blade=Line2D.new(); var x=25+i*61; var h=16+(i%5)*5; blade.points=PackedVector2Array([Vector2(x,GROUND_Y),Vector2(x-3,GROUND_Y-h)]); blade.width=4.0; blade.default_color=Color(0.27,0.55+0.04*(i%3),0.18,0.86); blade.antialiased=true; blade.set_meta("home_x",x); blade.set_meta("phase",float(i)*0.57); blade.z_index=4; add_child(blade); grass_nodes.append(blade)
    for i in range(18):
        var f=Node2D.new(); f.position=Vector2(120+i*176,GROUND_Y-16); f.set_meta("phase",float(i)*0.8); f.z_index=5; add_child(f); flower_nodes.append(f)
        var stem=Line2D.new(); stem.points=PackedVector2Array([Vector2(0,12),Vector2(0,-14)]); stem.width=4; stem.default_color=Color("4f8f3c"); f.add_child(stem)
        for j in range(5):
            var pet=_ellipse_poly(8,4,[Color("ff8ccf"),Color("a890ff"),Color("73dcff"),Color("ffdc70")][i%4]); pet.position=Vector2(cos(TAU*j/5.0)*7,-15+sin(TAU*j/5.0)*7); pet.rotation=TAU*j/5.0; f.add_child(pet)
        var cen=_ellipse_poly(4,4,Color("ffe07a")); cen.position=Vector2(0,-15); f.add_child(cen)

    for p in [Vector2(540,280),Vector2(1130,340),Vector2(1840,260)]:
        var b=Node2D.new(); b.set_script(load("res://scripts/Butterfly.gd")); b.position=p; b.z_index=10; add_child(b); butterflies.append(b)

func _build_mushrooms():
    var data=[ [Vector2(500,GROUND_Y),70.0,Color("ff6f9d")], [Vector2(1040,GROUND_Y),82.0,Color("8a7cff")], [Vector2(1450,GROUND_Y),68.0,Color("65d8ff")] ]
    for d in data:
        var b=StaticBody2D.new(); b.position=d[0]; b.set_meta("kind","mushroom"); b.set_meta("power",860.0 + d[1]*1.2); add_child(b); mushroom_nodes.append(b)
        var cap_col=CollisionShape2D.new(); var cap_shape=RectangleShape2D.new(); cap_shape.size=Vector2(d[1]*1.75,18); cap_col.shape=cap_shape; cap_col.position=Vector2(0,-42); b.add_child(cap_col)
        var stem=Polygon2D.new(); stem.polygon=PackedVector2Array([Vector2(-18,0),Vector2(18,0),Vector2(12,-45),Vector2(-12,-45)]); stem.color=Color("f3e2c8"); b.add_child(stem)
        var cap=_ellipse_poly(d[1],34,d[2]); cap.position=Vector2(0,-47); cap.set_meta("base_scale",Vector2.ONE); b.add_child(cap); b.set_meta("cap_node",cap)
        for k in range(4):
            var spot=_ellipse_poly(7+(k%2)*2,4+(k%2),Color(1,1,1,0.72)); spot.position=Vector2(-d[1]*0.48+k*d[1]*0.32,-53+abs(k-1.5)*5); b.add_child(spot)

func _build_acorn():
    acorn_area=Area2D.new(); acorn_area.position=Vector2(885,GROUND_Y-42); acorn_area.set_meta("kind","acorn"); add_child(acorn_area)
    var cs=CollisionShape2D.new(); var sh=CircleShape2D.new(); sh.radius=28; cs.shape=sh; acorn_area.add_child(cs)
    var spr=Sprite2D.new(); spr.texture=load("res://assets/acorn.svg"); spr.scale=Vector2(0.34,0.34); acorn_area.add_child(spr)
    var glow=_ellipse_poly(35,12,Color(1.0,0.82,0.31,0.16)); glow.position=Vector2(0,18); glow.z_index=-1; acorn_area.add_child(glow)

func _build_squirrel():
    squirrel=Node2D.new(); squirrel.position=Vector2(1290,GROUND_Y-34); squirrel.set_meta("kind","squirrel"); squirrel.z_index=8; add_child(squirrel)
    var tail=_ellipse_poly(38,52,Color("c97838")); tail.position=Vector2(-33,-37); tail.rotation=-0.42; squirrel.add_child(tail)
    var body=_ellipse_poly(31,39,Color("d68a49")); body.position=Vector2(0,-27); squirrel.add_child(body)
    var head=_ellipse_poly(29,28,Color("e19a56")); head.position=Vector2(21,-67); squirrel.add_child(head)
    var chest=_ellipse_poly(16,25,Color("f4d0a0")); chest.position=Vector2(8,-28); squirrel.add_child(chest)
    for x in [10,30]:
        var eye=_ellipse_poly(4.5,5,Color("2b1d20")); eye.position=Vector2(x,-72); squirrel.add_child(eye)
    for x in [7,32]:
        var ear=Polygon2D.new(); ear.polygon=PackedVector2Array([Vector2(x-7,-86),Vector2(x,-108),Vector2(x+8,-87)]); ear.color=Color("d8894a"); squirrel.add_child(ear)
    squirrel_mouth=Node2D.new(); squirrel_mouth.position=Vector2(41,-60); squirrel.add_child(squirrel_mouth)
    var mouth=_ellipse_poly(7,5,Color("633b32")); squirrel_mouth.add_child(mouth)
    var bubble=Label.new(); bubble.text="♡"; bubble.position=Vector2(-9,-125); bubble.add_theme_font_size_override("font_size",30); bubble.add_theme_color_override("font_color",Color("ff7aa8")); bubble.visible=false; bubble.name="Heart"; squirrel.add_child(bubble)

func _build_portal():
    portal=Node2D.new(); portal.position=Vector2(2180,GROUND_Y-126); portal.set_meta("kind","portal"); portal.z_index=7; add_child(portal)
    for r in [96.0,80.0,64.0,48.0]:
        var ring=_ring_poly(r,8.0,[Color("ff8ee7"),Color("9d75ff"),Color("6de6ff"),Color("fff1a0")][int(r/16)%4]); portal.add_child(ring); ring.set_meta("base_r",r)
    var core=_ellipse_poly(43,82,Color(0.45,0.22,0.78,0.48)); portal.add_child(core)
    var aura=_ellipse_poly(115,135,Color(0.67,0.35,1.0,0.10)); aura.z_index=-1; portal.add_child(aura)

func _build_secret_area():
    var x0=2780.0
    var arch=Polygon2D.new(); arch.polygon=PackedVector2Array([Vector2(x0,GROUND_Y),Vector2(x0+620,GROUND_Y),Vector2(x0+620,220),Vector2(x0,220)]); arch.color=Color(0.07,0.13,0.18,0.24); arch.z_index=-1; add_child(arch)
    for i in range(9):
        var c=_ellipse_poly(20+i%3*5,12+i%2*5,[Color("7bf3ff"),Color("c882ff"),Color("ff9cdc")][i%3]); c.position=Vector2(x0+70+i*62,GROUND_Y-40-(i%3)*28); c.rotation=-0.35+0.08*i; add_child(c)
    var sign=Label.new(); sign.text="SECRET GLADE"; sign.position=Vector2(x0+145,260); sign.size=Vector2(350,60); sign.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; sign.add_theme_font_size_override("font_size",34); sign.add_theme_color_override("font_color",Color("fff1b4")); add_child(sign)

func _build_player():
    player=CharacterBody2D.new(); player.set_script(load("res://scripts/Player.gd")); player.position=Vector2(220,GROUND_Y); player.z_index=12; add_child(player)
    player.landed_on.connect(_on_player_landed)
    for b in butterflies: b.player=player
    camera=Camera2D.new(); camera.position=Vector2(180,-110); camera.position_smoothing_enabled=true; camera.position_smoothing_speed=7.0; camera.limit_left=0; camera.limit_right=int(WORLD_W); camera.limit_top=0; camera.limit_bottom=720; player.add_child(camera); camera.make_current()

func _build_ui():
    var layer=CanvasLayer.new(); add_child(layer)
    var top=Panel.new(); top.position=Vector2(28,24); top.size=Vector2(350,70); top.modulate=Color(0.08,0.05,0.15,0.84); layer.add_child(top)
    var title=Label.new(); title.text="GOLD STANDARD PLAYGROUND"; title.position=Vector2(52,42); title.size=Vector2(310,30); title.add_theme_font_size_override("font_size",18); title.add_theme_color_override("font_color",Color("ffe6aa")); layer.add_child(title)
    hint_label=Label.new(); hint_label.text="Explore. Try things."; hint_label.position=Vector2(46,68); hint_label.size=Vector2(315,28); hint_label.add_theme_font_size_override("font_size",17); hint_label.add_theme_color_override("font_color",Color.WHITE); layer.add_child(hint_label)

    var left=_make_control_button("◀",Vector2(42,552),Vector2(118,118)); left.button_down.connect(func(): left_down=true); left.button_up.connect(func(): left_down=false); layer.add_child(left)
    var right=_make_control_button("▶",Vector2(174,552),Vector2(118,118)); right.button_down.connect(func(): right_down=true); right.button_up.connect(func(): right_down=false); layer.add_child(right)
    var jump=_make_control_button("↑",Vector2(987,552),Vector2(118,118)); jump.pressed.connect(func(): player.request_jump()); layer.add_child(jump)
    action_button=_make_control_button("✋",Vector2(1122,552),Vector2(118,118)); action_button.pressed.connect(_do_action); layer.add_child(action_button)

    var home=Button.new(); home.text="⌂"; home.position=Vector2(1192,24); home.size=Vector2(60,60); home.add_theme_font_size_override("font_size",28); home.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/Menu.tscn")); layer.add_child(home)

    fade=ColorRect.new(); fade.color=Color(0.04,0.02,0.10,0.0); fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); fade.mouse_filter=Control.MOUSE_FILTER_IGNORE; layer.add_child(fade)

func _make_control_button(txt:String,pos:Vector2,size:Vector2)->Button:
    var b=Button.new(); b.text=txt; b.position=pos; b.size=size; b.add_theme_font_size_override("font_size",45)
    var st=StyleBoxFlat.new(); st.bg_color=Color(0.08,0.06,0.14,0.64); st.corner_radius_top_left=58; st.corner_radius_top_right=58; st.corner_radius_bottom_left=58; st.corner_radius_bottom_right=58; st.border_width_left=3; st.border_width_right=3; st.border_width_top=3; st.border_width_bottom=3; st.border_color=Color(1,1,1,0.45); b.add_theme_stylebox_override("normal",st)
    var pr=st.duplicate(); pr.bg_color=Color(0.45,0.24,0.72,0.82); b.add_theme_stylebox_override("pressed",pr); b.add_theme_stylebox_override("hover",pr); return b

func _start_audio():
    music=AudioStreamPlayer.new(); music.stream=load("res://audio/forest_music.wav"); music.volume_db=-22; add_child(music); music.play(); music.finished.connect(func(): music.play())
    sfx=AudioStreamPlayer.new(); add_child(sfx)

func _process(delta):
    time_alive += delta
    if player:
        var axis=(1.0 if right_down else 0.0)-(1.0 if left_down else 0.0)
        player.set_move_axis(axis)
        _update_nearby_hint()
    _animate_world(delta)

func _animate_world(_delta):
    var t=Time.get_ticks_msec()/1000.0
    for g in grass_nodes:
        var p=g.get_meta("phase")
        g.rotation=sin(t*1.55+p)*0.075
    for f in flower_nodes:
        var p=f.get_meta("phase")
        f.rotation=sin(t*1.35+p)*0.055
    for m in mushroom_nodes:
        var cap=m.get_meta("cap_node")
        if is_instance_valid(cap) and not cap.has_meta("squishing"):
            cap.position.y=-47+sin(t*1.2+m.position.x*0.01)*1.2
    if portal:
        portal.rotation=sin(t*0.7)*0.012
        for i in range(portal.get_child_count()):
            var c=portal.get_child(i)
            if c is Polygon2D and c.has_meta("base_r"):
                c.rotation += 0.003*(1 if i%2==0 else -1)
                c.modulate.a = (0.95 if portal_ready else 0.35) * (0.85+0.15*sin(t*2.0+i))
    if squirrel and not squirrel_fed:
        squirrel.position.y=(GROUND_Y-34)+sin(t*3.2)*1.5
        squirrel.rotation=sin(t*2.4)*0.025

func _update_nearby_hint():
    if portal_transitioning: return
    var kind=""
    if acorn_area and acorn_area.visible and player.global_position.distance_to(acorn_area.global_position)<125:
        kind="acorn"
    elif squirrel and player.global_position.distance_to(squirrel.global_position)<155:
        kind="squirrel"
    elif portal and player.global_position.distance_to(portal.global_position)<175:
        kind="portal"
    if kind=="acorn":
        action_button.text="🤲"; hint_label.text="Pick up the acorn"
    elif kind=="squirrel":
        action_button.text="🥜" if held_acorn else "♡"; hint_label.text="The squirrel is watching you..."
    elif kind=="portal":
        action_button.text="✦"; hint_label.text="Enter the portal" if portal_ready else "The portal is still sleepy"
    else:
        action_button.text="✋"; hint_label.text="Explore. Jump. Try things."

func _do_action():
    if portal_transitioning: return
    if acorn_area and acorn_area.visible and player.global_position.distance_to(acorn_area.global_position)<135:
        held_acorn=true; acorn_area.visible=false; player.show_acorn(true); player.play_action("pickup"); _play("res://audio/pickup.wav"); _say("Ooooh, an acorn! I know somebody who might LOVE this."); return
    if squirrel and player.global_position.distance_to(squirrel.global_position)<165:
        if held_acorn and not squirrel_fed:
            held_acorn=false; player.show_acorn(false); player.play_action("give"); squirrel_fed=true; portal_ready=true; _squirrel_eat(); _say("Awww! Look at those cheeks! Wait... the portal woke up!"); return
        elif not squirrel_fed:
            _say("Hmm... I think it's hungry."); _squirrel_react(); return
        else:
            _squirrel_react(); return
    if portal and player.global_position.distance_to(portal.global_position)<185:
        if portal_ready: _enter_portal()
        else: _say("It's not ready yet. Maybe somebody nearby can help us wake it!")

func _on_player_landed(collider,impact):
    if collider and collider.has_meta("kind") and collider.get_meta("kind")=="mushroom" and not portal_transitioning:
        var power=float(collider.get_meta("power")); player.bounce(power); _squish_mushroom(collider); _play("res://audio/boing.wav")
        if impact>600: hint_label.text="BOING! You did that."

func _squish_mushroom(m):
    var cap=m.get_meta("cap_node")
    if not is_instance_valid(cap):
        return
    cap.set_meta("squishing",true)
    var tw=create_tween(); tw.tween_property(cap,"scale",Vector2(1.16,0.55),0.07); tw.tween_property(cap,"scale",Vector2(0.92,1.18),0.10); tw.tween_property(cap,"scale",Vector2.ONE,0.18); tw.tween_callback(func(): cap.remove_meta("squishing"))

func _squirrel_react():
    if not squirrel: return
    var tw=create_tween(); tw.tween_property(squirrel,"scale",Vector2(1.08,0.94),0.09); tw.tween_property(squirrel,"scale",Vector2(0.96,1.05),0.10); tw.tween_property(squirrel,"scale",Vector2.ONE,0.14)

func _squirrel_eat():
    _play("res://audio/pickup.wav")
    var heart=squirrel.get_node("Heart") as Label; heart.visible=true
    var ac=Sprite2D.new(); ac.texture=load("res://assets/acorn.svg"); ac.scale=Vector2(0.24,0.24); ac.position=Vector2(43,-61); squirrel.add_child(ac)
    var tw=create_tween(); tw.tween_property(ac,"rotation",0.45,0.18); tw.tween_property(ac,"scale",Vector2(0.10,0.10),0.65); tw.tween_callback(ac.queue_free); tw.parallel().tween_property(squirrel,"scale",Vector2(1.12,0.94),0.45); tw.tween_property(squirrel,"scale",Vector2.ONE,0.22)
    var pt=create_tween(); pt.tween_interval(0.35); pt.tween_callback(func(): _portal_wake_fx())

func _portal_wake_fx():
    _play("res://audio/sparkle.wav")
    var tw=create_tween(); tw.tween_property(portal,"scale",Vector2(1.13,1.13),0.20); tw.tween_property(portal,"scale",Vector2.ONE,0.28)
    for i in range(18):
        var sp=_ellipse_poly(4+(i%3),4+(i%3),Color("ffe67a")); sp.position=portal.position+Vector2(randf_range(-90,90),randf_range(-120,120)); sp.z_index=20; add_child(sp)
        var st=create_tween(); st.tween_property(sp,"position",portal.position+Vector2(randf_range(-20,20),randf_range(-60,60)),0.45+randf()*0.3); st.parallel().tween_property(sp,"modulate:a",0.0,0.55); st.tween_callback(sp.queue_free)

func _enter_portal():
    portal_transitioning=true; player.lock_controls(true); hint_label.text="WHOAAA..."
    var dest=Vector2(2940,GROUND_Y)
    var tw=create_tween(); tw.tween_property(player,"global_position",portal.global_position+Vector2(0,110),0.40).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT); tw.parallel().tween_property(player,"scale",Vector2(0.18,0.18),0.45); tw.parallel().tween_property(player,"rotation",0.55,0.45); tw.tween_property(fade,"color:a",1.0,0.20); tw.tween_callback(func(): _portal_arrive(dest))

func _portal_arrive(dest:Vector2):
    player.global_position=dest; player.scale=Vector2(1,1); player.rotation=0; camera.position=Vector2(140,-110); secret_arrived=true
    var tw=create_tween(); tw.tween_property(fade,"color:a",0.0,0.42); tw.tween_callback(func(): player.lock_controls(false)); tw.tween_callback(func(): portal_transitioning=false); tw.tween_callback(func(): player.play_action("celebrate")); _say("Waaaau! A secret glade! The portal really took us somewhere!")

func _play(path:String):
    if sfx: sfx.stream=load(path); sfx.play()

func _say(text:String):
    if music:
        music.volume_db=-27
        var t=create_tween(); t.tween_interval(1.0); t.tween_property(music,"volume_db",-22.0,0.8)
    if DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
        var voices=DisplayServer.tts_get_voices_for_language("en")
        var voice=""
        if voices.size()>0: voice=voices[0]
        DisplayServer.tts_speak(text,voice,52,1.12,1.06)

func _ellipse_poly(rx:float,ry:float,col:Color)->Polygon2D:
    var p=Polygon2D.new(); var pts=PackedVector2Array()
    for i in range(28):
        var a=TAU*float(i)/28.0
        pts.append(Vector2(cos(a)*rx,sin(a)*ry))
    p.polygon=pts; p.color=col; return p

func _ring_poly(r:float,width:float,col:Color)->Polygon2D:
    var p=Polygon2D.new(); var pts=PackedVector2Array()
    for i in range(64):
        var a=TAU*float(i)/32.0
        var rr=r if i<32 else r-width
        var idx=i if i<32 else 63-i
        a=TAU*float(idx)/32.0
        pts.append(Vector2(cos(a)*rr,sin(a)*rr*1.28))
    p.polygon=pts; p.color=col; return p
