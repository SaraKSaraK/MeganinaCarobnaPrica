extends Node2D

const VIEW_W := 1280.0
const VIEW_H := 720.0
const GROUND_Y := 612.0
const WORLD_W := 3600.0
const PORTAL_X := 2260.0
const GLADE_X := 2860.0

var player: CharacterBody2D
var camera: Camera2D
var music: AudioStreamPlayer
var sfx: AudioStreamPlayer
var left_down := false
var right_down := false
var held_acorn := false
var squirrel_fed := false
var portal_ready := false
var portal_transitioning := false
var secret_arrived := false

var acorn_area: Area2D
var squirrel: Node2D
var portal: Node2D
var return_portal: Node2D
var chest: Node2D
var chest_open := false
var action_button: Button
var hint_label: Label
var candy_label: Label
var star_label: Label
var squirrel_goal: Label
var fade: ColorRect

var mushroom_nodes: Array = []
var grass_nodes: Array = []
var flower_nodes: Array = []
var butterflies: Array = []
var candies: Array = []
var stars: Array = []
var magic_flowers: Array = []
var fireflies: Array = []
var candy_count := 0
var star_count := 0
var time_alive := 0.0
var last_hint := ""
var intro_hint_time := 5.5

func _ready():
    randomize()
    _build_world()
    _build_player()
    _build_ui()
    _start_audio()
    _say("Ooooh! This forest is alive. Bounce, explore, and see what reacts!")

func _build_world():
    _build_background()
    _build_ground()
    _build_ambient_life()
    _build_mushrooms()
    _build_acorn()
    _build_squirrel()
    _build_magic_flowers()
    _build_stars()
    _build_portal()
    _build_secret_glade()
    _build_world_bounds()

func _build_background():
    # One coherent painterly base, with soft section overlays instead of transparent clip-art trees.
    var bg = Sprite2D.new()
    bg.texture = load("res://assets/title_bg.jpg")
    bg.position = Vector2(WORLD_W * 0.5, 360)
    bg.scale = Vector2(WORLD_W / 1280.0, 1.0)
    bg.z_index = -80
    add_child(bg)

    var veil = Polygon2D.new()
    veil.polygon = PackedVector2Array([Vector2(0,0), Vector2(WORLD_W,0), Vector2(WORLD_W,VIEW_H), Vector2(0,VIEW_H)])
    veil.color = Color(0.06,0.10,0.13,0.08)
    veil.z_index = -70
    add_child(veil)

    # Glade gets a warmer luminous atmosphere so teleporting feels like a new place.
    var glade_glow = Polygon2D.new()
    glade_glow.polygon = PackedVector2Array([Vector2(2720,0), Vector2(WORLD_W,0), Vector2(WORLD_W,VIEW_H), Vector2(2720,VIEW_H)])
    glade_glow.color = Color(0.45,0.16,0.55,0.10)
    glade_glow.z_index = -60
    add_child(glade_glow)

    # Foreground silhouettes at edges only, never over the player.
    for x in [40.0, 2500.0, 3550.0]:
        var bush = _ellipse_poly(190,85,Color(0.04,0.18,0.09,0.52))
        bush.position = Vector2(x,665)
        bush.z_index = 30
        add_child(bush)

func _build_ground():
    var ground = StaticBody2D.new()
    ground.name = "Ground"
    ground.set_meta("kind","ground")
    add_child(ground)

    var cs = CollisionShape2D.new()
    var rect = RectangleShape2D.new()
    rect.size = Vector2(WORLD_W,230)
    cs.shape = rect
    cs.position = Vector2(WORLD_W*0.5,GROUND_Y+115)
    ground.add_child(cs)

    var soil = Polygon2D.new()
    soil.polygon = PackedVector2Array([Vector2(0,GROUND_Y),Vector2(WORLD_W,GROUND_Y),Vector2(WORLD_W,VIEW_H),Vector2(0,VIEW_H)])
    soil.color = Color("38552c")
    soil.z_index = -3
    add_child(soil)

    var moss = Polygon2D.new()
    moss.polygon = PackedVector2Array([Vector2(0,GROUND_Y-18),Vector2(WORLD_W,GROUND_Y-18),Vector2(WORLD_W,GROUND_Y+12),Vector2(0,GROUND_Y+12)])
    moss.color = Color("79b64b")
    moss.z_index = -2
    add_child(moss)

    _platform(Vector2(770,518),Vector2(250,30),Color("668f3d"),"ledge")
    _platform(Vector2(1640,505),Vector2(275,28),Color("6f9d43"),"ledge")
    _platform(Vector2(3030,500),Vector2(240,28),Color("6f9d43"),"ledge")

func _platform(pos:Vector2,size:Vector2,col:Color,kind:String):
    var b=StaticBody2D.new()
    b.position=pos
    b.set_meta("kind",kind)
    add_child(b)
    var cs=CollisionShape2D.new()
    var r=RectangleShape2D.new()
    r.size=size
    cs.shape=r
    b.add_child(cs)
    var p=Polygon2D.new()
    p.polygon=PackedVector2Array([Vector2(-size.x*0.5,-size.y*0.5),Vector2(size.x*0.5,-size.y*0.5),Vector2(size.x*0.5,size.y*0.5),Vector2(-size.x*0.5,size.y*0.5)])
    p.color=col
    b.add_child(p)
    var lip=Polygon2D.new()
    lip.polygon=PackedVector2Array([Vector2(-size.x*0.5,-size.y*0.5),Vector2(size.x*0.5,-size.y*0.5),Vector2(size.x*0.5,-size.y*0.5+8),Vector2(-size.x*0.5,-size.y*0.5+8)])
    lip.color=Color("b4db73")
    b.add_child(lip)

func _build_ambient_life():
    for i in range(70):
        var blade=Line2D.new()
        var x=20.0+i*51.0
        var h=15.0+(i%6)*4.0
        blade.points=PackedVector2Array([Vector2(x,GROUND_Y),Vector2(x-3,GROUND_Y-h)])
        blade.width=3.5
        blade.default_color=Color(0.25,0.55+0.035*(i%3),0.16,0.82)
        blade.antialiased=true
        blade.set_meta("phase",float(i)*0.47)
        blade.z_index=4
        add_child(blade)
        grass_nodes.append(blade)

    for i in range(22):
        var f=Node2D.new()
        f.position=Vector2(100+i*158,GROUND_Y-16)
        f.set_meta("phase",float(i)*0.71)
        f.z_index=5
        add_child(f)
        flower_nodes.append(f)
        var stem=Line2D.new()
        stem.points=PackedVector2Array([Vector2(0,12),Vector2(0,-16)])
        stem.width=3.5
        stem.default_color=Color("4f8f3c")
        f.add_child(stem)
        for j in range(5):
            var pet=_ellipse_poly(8,4,[Color("ff8ccf"),Color("a890ff"),Color("73dcff"),Color("ffdc70")][i%4])
            pet.position=Vector2(cos(TAU*j/5.0)*7,-16+sin(TAU*j/5.0)*7)
            pet.rotation=TAU*j/5.0
            f.add_child(pet)
        var cen=_ellipse_poly(4,4,Color("ffe07a"))
        cen.position=Vector2(0,-16)
        f.add_child(cen)

    for p in [Vector2(420,285),Vector2(1090,325),Vector2(1770,275),Vector2(2980,300)]:
        var b=Node2D.new()
        b.set_script(load("res://scripts/Butterfly.gd"))
        b.position=p
        b.z_index=11
        add_child(b)
        butterflies.append(b)

    for i in range(18):
        var ff=_ellipse_poly(3.2,3.2,Color(1.0,0.88,0.32,0.78))
        ff.position=Vector2(180+i*187, 330+(i%4)*45)
        ff.set_meta("home",ff.position)
        ff.set_meta("phase",float(i)*0.63)
        ff.z_index=2
        add_child(ff)
        fireflies.append(ff)

func _build_mushrooms():
    var data=[
        [Vector2(510,GROUND_Y),74.0,Color("ff6f9d"),920.0],
        [Vector2(1045,GROUND_Y),88.0,Color("8a7cff"),965.0],
        [Vector2(1470,GROUND_Y),72.0,Color("65d8ff"),900.0],
        [Vector2(3170,GROUND_Y),80.0,Color("ffb84f"),1000.0]
    ]
    for idx in range(data.size()):
        var d=data[idx]
        var b=StaticBody2D.new()
        b.position=d[0]
        b.set_meta("kind","mushroom")
        b.set_meta("power",d[3])
        b.set_meta("bounce_count",0)
        b.set_meta("last_bounce",-10.0)
        b.set_meta("index",idx)
        add_child(b)
        mushroom_nodes.append(b)

        var cap_col=CollisionShape2D.new()
        var cap_shape=RectangleShape2D.new()
        cap_shape.size=Vector2(d[1]*1.72,16)
        cap_col.shape=cap_shape
        cap_col.position=Vector2(0,-43)
        b.add_child(cap_col)

        var stem=Polygon2D.new()
        stem.polygon=PackedVector2Array([Vector2(-18,0),Vector2(18,0),Vector2(12,-46),Vector2(-12,-46)])
        stem.color=Color("f2e1c7")
        b.add_child(stem)
        var cap=_ellipse_poly(d[1],35,d[2])
        cap.position=Vector2(0,-49)
        b.add_child(cap)
        b.set_meta("cap_node",cap)
        for k in range(5):
            var spot=_ellipse_poly(7+(k%2)*2,4+(k%2),Color(1,1,1,0.80))
            spot.position=Vector2(-d[1]*0.52+k*d[1]*0.26,-55+abs(k-2)*3)
            b.add_child(spot)

func _build_acorn():
    acorn_area=Area2D.new()
    acorn_area.position=Vector2(890,GROUND_Y-42)
    acorn_area.set_meta("kind","acorn")
    add_child(acorn_area)
    var cs=CollisionShape2D.new()
    var sh=CircleShape2D.new()
    sh.radius=28
    cs.shape=sh
    acorn_area.add_child(cs)
    var spr=Sprite2D.new()
    spr.texture=load("res://assets/acorn.svg")
    spr.scale=Vector2(0.34,0.34)
    acorn_area.add_child(spr)
    var glow=_ellipse_poly(38,14,Color(1.0,0.80,0.28,0.18))
    glow.position=Vector2(0,18)
    glow.z_index=-1
    acorn_area.add_child(glow)

func _build_squirrel():
    squirrel=Node2D.new()
    squirrel.position=Vector2(1300,GROUND_Y-34)
    squirrel.set_meta("kind","squirrel")
    squirrel.z_index=8
    add_child(squirrel)
    var tail=_ellipse_poly(39,54,Color("c97838")); tail.position=Vector2(-34,-39); tail.rotation=-0.42; squirrel.add_child(tail)
    var body=_ellipse_poly(31,40,Color("d68a49")); body.position=Vector2(0,-28); squirrel.add_child(body)
    var head=_ellipse_poly(29,28,Color("e19a56")); head.position=Vector2(21,-68); squirrel.add_child(head)
    var chestp=_ellipse_poly(16,25,Color("f4d0a0")); chestp.position=Vector2(8,-29); squirrel.add_child(chestp)
    for x in [10,30]:
        var eye=_ellipse_poly(4.5,5,Color("2b1d20")); eye.position=Vector2(x,-73); squirrel.add_child(eye)
    for x in [7,32]:
        var ear=Polygon2D.new(); ear.polygon=PackedVector2Array([Vector2(x-7,-87),Vector2(x,-109),Vector2(x+8,-88)]); ear.color=Color("d8894a"); squirrel.add_child(ear)
    var heart=Label.new(); heart.name="Heart"; heart.text="♡"; heart.position=Vector2(-8,-132); heart.add_theme_font_size_override("font_size",34); heart.add_theme_color_override("font_color",Color("ff7aa8")); heart.visible=false; squirrel.add_child(heart)

func _build_magic_flowers():
    for i in range(3):
        var f=Node2D.new()
        f.position=Vector2(1720+i*150,GROUND_Y-28)
        f.set_meta("kind","magic_flower")
        f.set_meta("awake",false)
        f.set_meta("idx",i)
        f.z_index=9
        add_child(f)
        magic_flowers.append(f)
        var stem=Line2D.new(); stem.points=PackedVector2Array([Vector2(0,22),Vector2(0,-18)]); stem.width=7; stem.default_color=Color("4e9745"); stem.antialiased=true; f.add_child(stem)
        for j in range(6):
            var pet=_ellipse_poly(18,9,[Color("ff7dc9"),Color("b979ff"),Color("70e9ff")][i])
            pet.position=Vector2(cos(TAU*j/6.0)*15,-20+sin(TAU*j/6.0)*15)
            pet.rotation=TAU*j/6.0
            pet.scale=Vector2(0.6,0.6)
            f.add_child(pet)
        var c=_ellipse_poly(8,8,Color("ffd55f")); c.position=Vector2(0,-20); f.add_child(c)

func _build_stars():
    for p in [Vector2(760,430),Vector2(1120,390),Vector2(1635,415),Vector2(2010,520),Vector2(3020,414)]:
        _spawn_star(p)

func _spawn_star(pos:Vector2):
    var s=Node2D.new()
    s.position=pos
    s.set_meta("home",pos)
    s.set_meta("phase",randf_range(0,TAU))
    s.set_meta("collected",false)
    s.z_index=15
    add_child(s)
    var poly=Polygon2D.new()
    var pts=PackedVector2Array()
    for i in range(10):
        var a=-PI/2.0 + i*PI/5.0
        var r=17.0 if i%2==0 else 7.0
        pts.append(Vector2(cos(a)*r,sin(a)*r))
    poly.polygon=pts
    poly.color=Color("ffe262")
    s.add_child(poly)
    var halo=_ellipse_poly(26,26,Color(1.0,0.88,0.22,0.12)); halo.z_index=-1; s.add_child(halo)
    stars.append(s)

func _build_portal():
    portal=_make_portal(Vector2(PORTAL_X,GROUND_Y-128),false)
    portal.set_meta("kind","portal")

func _make_portal(pos:Vector2,small:bool)->Node2D:
    var p=Node2D.new()
    p.position=pos
    p.z_index=7
    add_child(p)
    var base=68.0 if small else 100.0
    for i in range(4):
        var r=base-i*17.0
        var ring=_ring_poly(r,8.0,[Color("ff8ee7"),Color("9d75ff"),Color("6de6ff"),Color("fff1a0")][i])
        ring.set_meta("ring",true)
        p.add_child(ring)
    var core=_ellipse_poly(base*0.45,base*0.82,Color(0.45,0.22,0.78,0.56))
    p.add_child(core)
    var aura=_ellipse_poly(base*1.18,base*1.35,Color(0.67,0.35,1.0,0.10))
    aura.z_index=-1
    p.add_child(aura)
    return p

func _build_secret_glade():
    # A playable reward area, not an empty sign.
    var title=Label.new()
    title.text="SECRET GLADE"
    title.position=Vector2(2850,238)
    title.size=Vector2(430,55)
    title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size",32)
    title.add_theme_color_override("font_color",Color("fff1b4"))
    title.z_index=2
    add_child(title)

    # Treasure chest.
    chest=Node2D.new()
    chest.position=Vector2(3330,GROUND_Y-45)
    chest.set_meta("kind","chest")
    chest.z_index=9
    add_child(chest)
    var box=Polygon2D.new(); box.polygon=PackedVector2Array([Vector2(-48,-28),Vector2(48,-28),Vector2(44,25),Vector2(-44,25)]); box.color=Color("a66431"); chest.add_child(box)
    var lid=Polygon2D.new(); lid.name="Lid"; lid.polygon=PackedVector2Array([Vector2(-52,-30),Vector2(52,-30),Vector2(42,-61),Vector2(-42,-61)]); lid.color=Color("d38b43"); chest.add_child(lid)
    var band=Polygon2D.new(); band.polygon=PackedVector2Array([Vector2(-7,-60),Vector2(7,-60),Vector2(7,25),Vector2(-7,25)]); band.color=Color("ffd36d"); chest.add_child(band)
    var lock=_ellipse_poly(10,12,Color("fff0a0")); lock.position=Vector2(0,-17); chest.add_child(lock)

    # Three giant bell flowers: each has a different reaction and releases a candy once.
    for i in range(3):
        var bf=Node2D.new(); bf.position=Vector2(2880+i*145,GROUND_Y-26); bf.set_meta("kind","bell_flower"); bf.set_meta("played",false); bf.set_meta("idx",i); bf.z_index=8; add_child(bf)
        var stem=Line2D.new(); stem.points=PackedVector2Array([Vector2(0,22),Vector2(0,-33)]); stem.width=8; stem.default_color=Color("4a9440"); bf.add_child(stem)
        var bell=Polygon2D.new(); bell.name="Bell"; bell.polygon=PackedVector2Array([Vector2(-28,-38),Vector2(28,-38),Vector2(19,-72),Vector2(-19,-72)]); bell.color=[Color("ff7fb4"),Color("9a84ff"),Color("61ddff")][i]; bf.add_child(bell)
        magic_flowers.append(bf)

    return_portal=_make_portal(Vector2(2785,GROUND_Y-90),true)
    return_portal.set_meta("kind","return_portal")

func _build_world_bounds():
    _wall(Vector2(-18,360),Vector2(36,720))
    _wall(Vector2(WORLD_W+18,360),Vector2(36,720))
    # Hard divider: the Secret Glade cannot be reached by simply walking past the portal.
    _wall(Vector2(2635,360),Vector2(38,720))

func _wall(pos:Vector2,size:Vector2):
    var b=StaticBody2D.new(); b.position=pos; add_child(b)
    var cs=CollisionShape2D.new(); var r=RectangleShape2D.new(); r.size=size; cs.shape=r; b.add_child(cs)

func _build_player():
    player=CharacterBody2D.new()
    player.set_script(load("res://scripts/Player.gd"))
    player.position=Vector2(220,GROUND_Y)
    player.z_index=12
    add_child(player)
    player.landed_on.connect(_on_player_landed)
    for b in butterflies:
        b.player=player
    camera=Camera2D.new()
    camera.position=Vector2(145,-110)
    camera.position_smoothing_enabled=true
    camera.position_smoothing_speed=6.5
    camera.limit_left=0
    camera.limit_right=2630
    camera.limit_top=0
    camera.limit_bottom=720
    player.add_child(camera)
    camera.make_current()

func _build_ui():
    var layer=CanvasLayer.new()
    add_child(layer)

    var hud=PanelContainer.new()
    hud.position=Vector2(24,22)
    hud.size=Vector2(330,84)
    var hud_style=StyleBoxFlat.new(); hud_style.bg_color=Color(0.04,0.04,0.08,0.68); hud_style.corner_radius_top_left=22; hud_style.corner_radius_top_right=22; hud_style.corner_radius_bottom_left=22; hud_style.corner_radius_bottom_right=22; hud_style.border_width_left=2; hud_style.border_width_right=2; hud_style.border_width_top=2; hud_style.border_width_bottom=2; hud_style.border_color=Color(1,1,1,0.20); hud.add_theme_stylebox_override("panel",hud_style); layer.add_child(hud)
    var row=HBoxContainer.new(); row.add_theme_constant_override("separation",18); hud.add_child(row)
    candy_label=Label.new(); candy_label.text="🍬 0 / 4"; candy_label.add_theme_font_size_override("font_size",28); candy_label.add_theme_color_override("font_color",Color("fff1b4")); row.add_child(candy_label)
    star_label=Label.new(); star_label.text="⭐ 0"; star_label.add_theme_font_size_override("font_size",28); star_label.add_theme_color_override("font_color",Color("fff1b4")); row.add_child(star_label)
    squirrel_goal=Label.new(); squirrel_goal.text="🐿 ○"; squirrel_goal.add_theme_font_size_override("font_size",28); squirrel_goal.add_theme_color_override("font_color",Color("fff1b4")); row.add_child(squirrel_goal)

    hint_label=Label.new()
    hint_label.text="Bounce on a mushroom. Something might pop out!"
    hint_label.position=Vector2(350,36)
    hint_label.size=Vector2(580,48)
    hint_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    hint_label.add_theme_font_size_override("font_size",20)
    hint_label.add_theme_color_override("font_color",Color.WHITE)
    hint_label.add_theme_color_override("font_shadow_color",Color(0,0,0,0.85))
    hint_label.add_theme_constant_override("shadow_offset_x",2)
    hint_label.add_theme_constant_override("shadow_offset_y",2)
    layer.add_child(hint_label)

    var left=_make_control_button("◀",Vector2(42,552),Vector2(118,118)); left.button_down.connect(func(): left_down=true); left.button_up.connect(func(): left_down=false); layer.add_child(left)
    var right=_make_control_button("▶",Vector2(174,552),Vector2(118,118)); right.button_down.connect(func(): right_down=true); right.button_up.connect(func(): right_down=false); layer.add_child(right)
    var jump=_make_control_button("↑",Vector2(987,552),Vector2(118,118)); jump.pressed.connect(func(): player.request_jump()); layer.add_child(jump)
    action_button=_make_control_button("✋",Vector2(1122,552),Vector2(118,118)); action_button.pressed.connect(_do_action); layer.add_child(action_button)

    var home=Button.new(); home.text="⌂"; home.position=Vector2(1192,24); home.size=Vector2(60,60); home.add_theme_font_size_override("font_size",28); home.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/Menu.tscn")); layer.add_child(home)

    fade=ColorRect.new(); fade.color=Color(0.04,0.02,0.10,0.0); fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); fade.mouse_filter=Control.MOUSE_FILTER_IGNORE; layer.add_child(fade)

func _make_control_button(txt:String,pos:Vector2,size:Vector2)->Button:
    var b=Button.new(); b.text=txt; b.position=pos; b.size=size; b.add_theme_font_size_override("font_size",45)
    var st=StyleBoxFlat.new(); st.bg_color=Color(0.08,0.06,0.14,0.66); st.corner_radius_top_left=58; st.corner_radius_top_right=58; st.corner_radius_bottom_left=58; st.corner_radius_bottom_right=58; st.border_width_left=3; st.border_width_right=3; st.border_width_top=3; st.border_width_bottom=3; st.border_color=Color(1,1,1,0.44); b.add_theme_stylebox_override("normal",st)
    var pr=st.duplicate(); pr.bg_color=Color(0.45,0.24,0.72,0.86); b.add_theme_stylebox_override("pressed",pr); b.add_theme_stylebox_override("hover",pr)
    return b

func _start_audio():
    music=AudioStreamPlayer.new(); music.stream=load("res://audio/forest_music.wav"); music.volume_db=-22; add_child(music); music.play(); music.finished.connect(func(): music.play())
    sfx=AudioStreamPlayer.new(); add_child(sfx)

func _process(delta):
    time_alive += delta
    intro_hint_time -= delta
    if player:
        var axis=(1.0 if right_down else 0.0)-(1.0 if left_down else 0.0)
        player.set_move_axis(axis)
        # Absolute safety net: never let the character walk beyond the camera/world.
        player.global_position.x=clamp(player.global_position.x,52.0,WORLD_W-52.0)
        _update_nearby_hint()
    _animate_world(delta)
    _update_candies(delta)
    _update_stars(delta)

func _animate_world(_delta):
    var t=Time.get_ticks_msec()/1000.0
    for g in grass_nodes:
        g.rotation=sin(t*1.55+float(g.get_meta("phase")))*0.075
    for f in flower_nodes:
        f.rotation=sin(t*1.35+float(f.get_meta("phase")))*0.055
    for ff in fireflies:
        var h=ff.get_meta("home")
        var p=float(ff.get_meta("phase"))
        ff.position=h+Vector2(sin(t*0.8+p)*14,cos(t*1.05+p)*11)
        ff.modulate.a=0.35+0.65*(sin(t*2.2+p)*0.5+0.5)
    for m in mushroom_nodes:
        var cap=m.get_meta("cap_node")
        if is_instance_valid(cap) and not cap.has_meta("squishing"):
            cap.position.y=-49+sin(t*1.2+m.position.x*0.01)*1.1
    for p in [portal,return_portal]:
        if p:
            p.rotation=sin(t*0.7+p.position.x*0.001)*0.012
            for i in range(p.get_child_count()):
                var c=p.get_child(i)
                if c is Polygon2D and c.has_meta("ring"):
                    c.rotation += 0.003*(1 if i%2==0 else -1)
                    if p==portal:
                        c.modulate.a=(0.98 if portal_ready else 0.28)*(0.84+0.16*sin(t*2.0+i))
    if squirrel and not squirrel_fed:
        squirrel.position.y=(GROUND_Y-34)+sin(t*3.2)*1.4
        squirrel.rotation=sin(t*2.4)*0.024

func _update_nearby_hint():
    if portal_transitioning:
        return
    var kind=""
    var target:Node2D=null
    if acorn_area and acorn_area.visible and player.global_position.distance_to(acorn_area.global_position)<125:
        kind="acorn"; target=acorn_area
    elif squirrel and player.global_position.distance_to(squirrel.global_position)<155:
        kind="squirrel"; target=squirrel
    else:
        for f in magic_flowers:
            if is_instance_valid(f) and f.has_meta("kind") and player.global_position.distance_to(f.global_position)<120:
                kind=str(f.get_meta("kind")); target=f; break
    if kind=="":
        if portal and player.global_position.distance_to(portal.global_position)<175:
            kind="portal"; target=portal
        elif chest and player.global_position.distance_to(chest.global_position)<155:
            kind="chest"; target=chest
        elif return_portal and player.global_position.distance_to(return_portal.global_position)<150:
            kind="return_portal"; target=return_portal

    if kind=="acorn":
        action_button.text="🤲"; _set_hint("Pick up the acorn")
    elif kind=="squirrel":
        action_button.text="🥜" if held_acorn else "♡"; _set_hint("Give it the acorn!" if held_acorn else "That squirrel looks hungry...")
    elif kind=="magic_flower":
        action_button.text="🌸"; _set_hint("Wake the sleepy flower")
    elif kind=="bell_flower":
        action_button.text="🔔"; _set_hint("Ring the giant flower")
    elif kind=="portal":
        action_button.text="✦"; _set_hint("Enter the portal!" if portal_ready else "The portal needs 4 candies and a happy squirrel")
    elif kind=="chest":
        action_button.text="🎁"; _set_hint("Open the treasure chest" if not chest_open else "The treasure chest is open")
    elif kind=="return_portal":
        action_button.text="↩"; _set_hint("Back to the forest")
    else:
        action_button.text="✋"
        if intro_hint_time<=0:
            _set_hint("Explore. Bounce. Try things.")

func _set_hint(txt:String):
    if txt==last_hint:
        return
    last_hint=txt
    hint_label.text=txt

func _do_action():
    if portal_transitioning:
        return
    if acorn_area and acorn_area.visible and player.global_position.distance_to(acorn_area.global_position)<135:
        held_acorn=true; acorn_area.visible=false; player.show_acorn(true); player.play_action("pickup"); _play("res://audio/pickup.wav"); _burst_sparkles(acorn_area.global_position,Color("ffd66b"),8); _say("Ooooh, an acorn! I know somebody who would LOVE this."); return
    if squirrel and player.global_position.distance_to(squirrel.global_position)<165:
        if held_acorn and not squirrel_fed:
            held_acorn=false; player.show_acorn(false); player.play_action("give"); squirrel_fed=true; squirrel_goal.text="🐿 ✓"; _squirrel_eat(); _check_portal_ready(); _say("Awww! Look at those cheeks! Now find enough candy to wake the portal!"); return
        elif not squirrel_fed:
            _say("Hmm... I think it's hungry."); _squirrel_react(); return
        else:
            _squirrel_react(); return
    for f in magic_flowers:
        if is_instance_valid(f) and f.has_meta("kind") and player.global_position.distance_to(f.global_position)<125:
            var k=str(f.get_meta("kind"))
            if k=="magic_flower": _wake_magic_flower(f)
            elif k=="bell_flower": _ring_bell_flower(f)
            return
    if portal and player.global_position.distance_to(portal.global_position)<185:
        if portal_ready: _enter_portal()
        else:
            var remaining=max(0,4-candy_count)
            if not squirrel_fed: _say("The portal is sleepy. Help the squirrel and find candy from the mushrooms!")
            else: _say("Almost! We need %d more candy!" % remaining)
        return
    if chest and player.global_position.distance_to(chest.global_position)<165:
        _open_chest(); return
    if return_portal and player.global_position.distance_to(return_portal.global_position)<160:
        _return_to_forest(); return

func _on_player_landed(collider,impact):
    if collider and collider.has_meta("kind") and collider.get_meta("kind")=="mushroom" and not portal_transitioning:
        var now=Time.get_ticks_msec()/1000.0
        var last=float(collider.get_meta("last_bounce"))
        if now-last<0.45:
            return
        collider.set_meta("last_bounce",now)
        collider.set_meta("bounce_count",int(collider.get_meta("bounce_count"))+1)
        var power=float(collider.get_meta("power"))
        player.bounce(power)
        _squish_mushroom(collider)
        _play("res://audio/boing.wav")
        _spawn_candy(collider.global_position+Vector2(0,-100), true)
        _burst_sparkles(collider.global_position+Vector2(0,-70),Color("fff17d"),7)
        _set_hint("BOING! Candy popped out!")
        if int(collider.get_meta("bounce_count"))==1:
            _say("BOING! Hahaha! It gave us candy!")

func _spawn_candy(pos:Vector2,from_bounce:=false):
    var n=Node2D.new()
    n.position=pos
    n.z_index=17
    add_child(n)
    var body=_ellipse_poly(14,10,[Color("ff79b5"),Color("8c82ff"),Color("5ee4ff"),Color("ffd35c")][randi()%4]); n.add_child(body)
    var wrap_l=Polygon2D.new(); wrap_l.polygon=PackedVector2Array([Vector2(-13,-7),Vector2(-27,-13),Vector2(-24,8),Vector2(-13,6)]); wrap_l.color=body.color.lightened(0.18); n.add_child(wrap_l)
    var wrap_r=Polygon2D.new(); wrap_r.polygon=PackedVector2Array([Vector2(13,-7),Vector2(27,-13),Vector2(24,8),Vector2(13,6)]); wrap_r.color=body.color.lightened(0.18); n.add_child(wrap_r)
    var halo=_ellipse_poly(22,15,Color(1,1,1,0.12)); halo.z_index=-1; n.add_child(halo)
    var entry={"node":n,"vel":Vector2(randf_range(-155,155),randf_range(-510,-390) if from_bounce else -360.0),"age":0.0,"phase":randf_range(0,TAU),"resting":false}
    candies.append(entry)

func _update_candies(delta):
    for i in range(candies.size()-1,-1,-1):
        var d=candies[i]
        var n=d["node"] as Node2D
        if not is_instance_valid(n):
            candies.remove_at(i); continue
        d["age"]=float(d["age"])+delta
        if not bool(d["resting"]):
            var v:Vector2=d["vel"]
            v.y += 980.0*delta
            n.position += v*delta
            if n.position.y>=GROUND_Y-22:
                n.position.y=GROUND_Y-22
                if abs(v.y)>120:
                    v.y=-abs(v.y)*0.36; v.x*=0.76
                else:
                    v=Vector2.ZERO; d["resting"]=true
            d["vel"]=v
        else:
            n.position.y=(GROUND_Y-22)+sin(time_alive*4.0+float(d["phase"]))*3.5
            n.rotation=sin(time_alive*3.0+float(d["phase"]))*0.12
        if float(d["age"])>0.12 and player and n.global_position.distance_to(player.global_position+Vector2(0,-50))<62:
            _collect_candy(n)
            candies.remove_at(i)
        else:
            candies[i]=d

func _collect_candy(n:Node2D):
    candy_count+=1
    candy_label.text="🍬 %d / 4" % min(candy_count,4)
    _play("res://audio/pickup.wav")
    _burst_sparkles(n.global_position,Color("fff17d"),9)
    n.queue_free()
    _check_portal_ready()
    if candy_count==1: _say("Candy! Let's see how many the forest is hiding!")
    elif candy_count==4 and squirrel_fed: _say("Four candies! The portal is awake!")

func _update_stars(_delta):
    for s in stars:
        if not is_instance_valid(s) or bool(s.get_meta("collected")):
            continue
        var home:Vector2=s.get_meta("home")
        var ph=float(s.get_meta("phase"))
        s.position=home+Vector2(0,sin(time_alive*2.6+ph)*7)
        s.rotation += 0.012
        if player and s.global_position.distance_to(player.global_position+Vector2(0,-65))<58:
            s.set_meta("collected",true)
            star_count+=1
            star_label.text="⭐ %d" % star_count
            _play("res://audio/sparkle.wav")
            _burst_sparkles(s.global_position,Color("ffe65b"),12)
            var tw=create_tween(); tw.tween_property(s,"scale",Vector2(1.6,1.6),0.12); tw.parallel().tween_property(s,"modulate:a",0.0,0.18); tw.tween_callback(s.queue_free)

func _check_portal_ready():
    var ready=squirrel_fed and candy_count>=4
    if ready and not portal_ready:
        portal_ready=true
        _portal_wake_fx()
        _say("Waaaau! Look! The portal woke up!")

func _squish_mushroom(m):
    var cap=m.get_meta("cap_node")
    if not is_instance_valid(cap): return
    cap.set_meta("squishing",true)
    var tw=create_tween(); tw.tween_property(cap,"scale",Vector2(1.18,0.52),0.065); tw.tween_property(cap,"scale",Vector2(0.90,1.20),0.10); tw.tween_property(cap,"scale",Vector2.ONE,0.18); tw.tween_callback(func(): cap.remove_meta("squishing"))

func _squirrel_react():
    if not squirrel: return
    var tw=create_tween(); tw.tween_property(squirrel,"scale",Vector2(1.09,0.93),0.08); tw.tween_property(squirrel,"scale",Vector2(0.96,1.06),0.10); tw.tween_property(squirrel,"scale",Vector2.ONE,0.14)

func _squirrel_eat():
    _play("res://audio/pickup.wav")
    var heart=squirrel.get_node("Heart") as Label
    heart.visible=true
    var ac=Sprite2D.new(); ac.texture=load("res://assets/acorn.svg"); ac.scale=Vector2(0.24,0.24); ac.position=Vector2(43,-61); squirrel.add_child(ac)
    var tw=create_tween(); tw.tween_property(ac,"rotation",0.45,0.18); tw.tween_property(ac,"scale",Vector2(0.10,0.10),0.58); tw.tween_callback(ac.queue_free); tw.parallel().tween_property(squirrel,"scale",Vector2(1.13,0.93),0.42); tw.tween_property(squirrel,"scale",Vector2.ONE,0.22)
    _spawn_star(squirrel.global_position+Vector2(0,-145))

func _wake_magic_flower(f:Node2D):
    if bool(f.get_meta("awake")):
        var tw=create_tween(); tw.tween_property(f,"rotation",-0.12,0.10); tw.tween_property(f,"rotation",0.12,0.10); tw.tween_property(f,"rotation",0.0,0.12)
        return
    f.set_meta("awake",true)
    _play("res://audio/sparkle.wav")
    var tw=create_tween(); tw.tween_property(f,"scale",Vector2(1.35,0.75),0.12); tw.tween_property(f,"scale",Vector2(0.92,1.35),0.14); tw.tween_property(f,"scale",Vector2.ONE,0.22)
    for c in f.get_children():
        if c is Polygon2D:
            create_tween().tween_property(c,"scale",Vector2(1.0,1.0),0.28)
    _burst_sparkles(f.global_position+Vector2(0,-50),Color("ffb4ee"),12)
    _spawn_candy(f.global_position+Vector2(0,-75),false)
    _say("It woke up! And it had a surprise!")

func _ring_bell_flower(f:Node2D):
    var bell=f.get_node("Bell") as Polygon2D
    var tw=create_tween(); tw.tween_property(bell,"rotation",0.34,0.10); tw.tween_property(bell,"rotation",-0.30,0.12); tw.tween_property(bell,"rotation",0.0,0.16)
    _play("res://audio/sparkle.wav")
    _burst_sparkles(f.global_position+Vector2(0,-65),bell.color,7)
    if not bool(f.get_meta("played")):
        f.set_meta("played",true)
        _spawn_candy(f.global_position+Vector2(0,-95),false)

func _portal_wake_fx():
    _play("res://audio/sparkle.wav")
    var tw=create_tween(); tw.tween_property(portal,"scale",Vector2(1.16,1.16),0.20); tw.tween_property(portal,"scale",Vector2.ONE,0.30)
    _burst_sparkles(portal.global_position,Color("ffe67a"),24)

func _enter_portal():
    portal_transitioning=true
    player.lock_controls(true)
    _set_hint("WHOAAA...")
    var dest=Vector2(GLADE_X,GROUND_Y)
    var tw=create_tween()
    tw.tween_property(player,"global_position",portal.global_position+Vector2(0,110),0.40).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tw.parallel().tween_property(player,"scale",Vector2(0.16,0.16),0.45)
    tw.parallel().tween_property(player,"rotation",0.55,0.45)
    tw.tween_property(fade,"color:a",1.0,0.20)
    tw.tween_callback(func(): _portal_arrive(dest))

func _portal_arrive(dest:Vector2):
    player.global_position=dest
    camera.limit_left=2700
    camera.limit_right=int(WORLD_W)
    player.scale=Vector2.ONE
    player.rotation=0
    secret_arrived=true
    var tw=create_tween(); tw.tween_property(fade,"color:a",0.0,0.42); tw.tween_callback(func(): player.lock_controls(false)); tw.tween_callback(func(): portal_transitioning=false); tw.tween_callback(func(): player.play_action("celebrate"))
    _burst_sparkles(dest+Vector2(0,-80),Color("c98cff"),18)
    _say("Waaaau! A secret glade! Ring the flowers and find the treasure chest!")

func _return_to_forest():
    if portal_transitioning: return
    portal_transitioning=true; player.lock_controls(true)
    var tw=create_tween(); tw.tween_property(fade,"color:a",1.0,0.20); tw.tween_callback(func(): _return_arrive())

func _return_arrive():
    player.global_position=Vector2(PORTAL_X-160,GROUND_Y); camera.limit_left=0; camera.limit_right=2630; player.scale=Vector2.ONE; player.rotation=0
    var tw=create_tween(); tw.tween_property(fade,"color:a",0.0,0.35); tw.tween_callback(func(): player.lock_controls(false)); tw.tween_callback(func(): portal_transitioning=false)

func _open_chest():
    if chest_open:
        _say("We already found the treasure!")
        return
    chest_open=true
    _play("res://audio/sparkle.wav")
    var lid=chest.get_node("Lid") as Polygon2D
    var tw=create_tween(); tw.tween_property(lid,"position",Vector2(0,-22),0.14); tw.parallel().tween_property(lid,"rotation",-0.55,0.18)
    for i in range(6):
        _spawn_candy(chest.global_position+Vector2(randf_range(-25,25),-85-randf_range(0,30)),true)
    _spawn_star(chest.global_position+Vector2(0,-170))
    _burst_sparkles(chest.global_position+Vector2(0,-70),Color("ffe66e"),28)
    _say("TREASURE! Hahaha! Candy everywhere!")

func _burst_sparkles(pos:Vector2,col:Color,count:int):
    for i in range(count):
        var sp=_ellipse_poly(3.0+(i%3)*1.4,3.0+(i%3)*1.4,col)
        sp.position=pos
        sp.z_index=25
        add_child(sp)
        var dest=pos+Vector2(randf_range(-95,95),randf_range(-95,55))
        var st=create_tween(); st.tween_property(sp,"position",dest,0.35+randf()*0.28).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT); st.parallel().tween_property(sp,"modulate:a",0.0,0.55); st.tween_callback(sp.queue_free)

func _play(path:String):
    if sfx:
        sfx.stream=load(path)
        sfx.play()

func _say(text:String):
    if music:
        music.volume_db=-27
        var t=create_tween(); t.tween_interval(1.0); t.tween_property(music,"volume_db",-22.0,0.8)
    if DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
        var voices=DisplayServer.tts_get_voices_for_language("en")
        var voice=""
        if voices.size()>0: voice=voices[0]
        DisplayServer.tts_speak(text,voice,52,1.12,1.06)

func _ellipse_poly(rx:float,ry:float,col:Color)->Polygon2D:
    var p=Polygon2D.new()
    var pts=PackedVector2Array()
    for i in range(28):
        var a=TAU*float(i)/28.0
        pts.append(Vector2(cos(a)*rx,sin(a)*ry))
    p.polygon=pts
    p.color=col
    return p

func _ring_poly(r:float,width:float,col:Color)->Polygon2D:
    var p=Polygon2D.new()
    var pts=PackedVector2Array()
    for i in range(32):
        var a=TAU*float(i)/32.0
        pts.append(Vector2(cos(a)*r,sin(a)*r*1.28))
    for i in range(31,-1,-1):
        var a=TAU*float(i)/32.0
        pts.append(Vector2(cos(a)*(r-width),sin(a)*(r-width)*1.28))
    p.polygon=pts
    p.color=col
    return p
