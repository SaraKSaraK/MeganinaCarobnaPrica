extends Node2D

var world_width := 4800.0
var ground_y := 570.0
var rng := RandomNumberGenerator.new()

func _ready():
    rng.seed = 424242
    queue_redraw()

func _draw():
    # Sky
    draw_rect(Rect2(0, 0, world_width, 720), Color("#9edaf0"))
    # Far haze bands
    for i in range(12):
        var x = i * 430.0 - 150.0
        draw_circle(Vector2(x, 330), 300.0, Color(0.55, 0.76, 0.70, 0.32))
        draw_circle(Vector2(x + 180, 350), 250.0, Color(0.42, 0.67, 0.58, 0.28))
    # Ground layers
    draw_rect(Rect2(0, 500, world_width, 220), Color("#6eaa68"))
    draw_rect(Rect2(0, 555, world_width, 165), Color("#86c66f"))
    draw_rect(Rect2(0, 612, world_width, 108), Color("#6fb25e"))

    # Path
    var path := PackedVector2Array([
        Vector2(0, 545), Vector2(world_width, 545), Vector2(world_width, 660), Vector2(0, 660)
    ])
    draw_colored_polygon(path, Color("#c8a878"))
    for i in range(60):
        var sx = 50.0 + i * 78.0
        var sy = 590.0 + sin(i * 1.7) * 18.0
        draw_circle(Vector2(sx, sy), 6.0 + (i % 3), Color(0.55,0.42,0.28,0.28))

    # Mid forest trunks / canopies
    for i in range(24):
        var x = 80.0 + i * 205.0
        var h = 170.0 + float((i * 37) % 90)
        draw_rect(Rect2(x, 420-h, 34, h+130), Color("#7b553d"))
        draw_circle(Vector2(x+18, 390-h), 92.0, Color("#4f9163"))
        draw_circle(Vector2(x-38, 420-h), 70.0, Color("#62a875"))
        draw_circle(Vector2(x+72, 420-h), 75.0, Color("#5da16e"))
        draw_circle(Vector2(x+20, 365-h), 55.0, Color(0.75,0.92,0.63,0.18))

    # Foreground bushes + flower patches
    for i in range(46):
        var x = 35.0 + i * 105.0
        var y = 520.0 + float((i*19)%50)
        draw_circle(Vector2(x, y), 25.0 + float(i%4)*5.0, Color("#4f995b"))
        draw_circle(Vector2(x+22, y+4), 20.0, Color("#66ad63"))
        if i % 2 == 0:
            draw_circle(Vector2(x+7, y-10), 4.0, Color("#f6b8db"))
            draw_circle(Vector2(x+18, y+2), 4.0, Color("#f9e07c"))
            draw_circle(Vector2(x-10, y+5), 4.0, Color("#d8c0ff"))

    # Decorative crystals / magical plants near gate
    for j in range(10):
        var bx = 3880.0 + j * 65.0
        var col = [Color("#d8b5ff"),Color("#9edcf6"),Color("#ffe38e")][j%3]
        var pts := PackedVector2Array([Vector2(bx,555),Vector2(bx+12,515-(j%3)*8),Vector2(bx+24,555)])
        draw_colored_polygon(pts,col)

