extends Control

var music: AudioStreamPlayer
var play_button: Button
var entering := false
var fade: ColorRect
var floaters := []

func _ready():
    _build_ui()
    music = AudioStreamPlayer.new()
    music.stream = load("res://audio/forest_music.wav")
    music.volume_db = -20
    add_child(music)
    music.play()
    music.finished.connect(_on_music_finished)

func _build_ui():
    var bg = TextureRect.new()
    bg.texture = load("res://assets/title_bg.jpg")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    add_child(bg)

    var left_glow = ColorRect.new()
    left_glow.position = Vector2(0,0)
    left_glow.size = Vector2(700,720)
    left_glow.color = Color(0.055,0.03,0.12,0.28)
    add_child(left_glow)

    for i in range(18):
        var f = Label.new()
        f.text = "✦"
        f.position = Vector2(70+(i*151)%1120, 60+(i*97)%560)
        f.add_theme_font_size_override("font_size",18+(i%4)*6)
        f.add_theme_color_override("font_color", Color(1.0,0.86,0.36,0.48))
        f.mouse_filter = Control.MOUSE_FILTER_IGNORE
        f.set_meta("home",f.position)
        f.set_meta("phase",float(i)*0.73)
        add_child(f)
        floaters.append(f)

    var eyebrow = Label.new()
    eyebrow.text = "A magical world that notices you"
    eyebrow.position = Vector2(75,142)
    eyebrow.size = Vector2(650,40)
    eyebrow.add_theme_font_size_override("font_size",24)
    eyebrow.add_theme_color_override("font_color",Color("ffe7a5"))
    add_child(eyebrow)

    var title = Label.new()
    title.text = "MEGAN'S\nMAGICAL ADVENTURE"
    title.position = Vector2(68,180)
    title.size = Vector2(700,190)
    title.add_theme_font_size_override("font_size",64)
    title.add_theme_color_override("font_color",Color.WHITE)
    title.add_theme_color_override("font_shadow_color",Color(0.13,0.02,0.24,0.95))
    title.add_theme_constant_override("shadow_offset_x",4)
    title.add_theme_constant_override("shadow_offset_y",5)
    add_child(title)

    var sub = Label.new()
    sub.text = "Explore • Play • Discover"
    sub.position = Vector2(78,382)
    sub.size = Vector2(560,40)
    sub.add_theme_font_size_override("font_size",28)
    sub.add_theme_color_override("font_color",Color(1,1,1,0.92))
    add_child(sub)

    play_button = Button.new()
    play_button.text = "PLAY  ✦"
    play_button.position = Vector2(80,458)
    play_button.size = Vector2(360,92)
    play_button.add_theme_font_size_override("font_size",38)
    play_button.add_theme_color_override("font_color",Color.WHITE)
    play_button.add_theme_color_override("font_hover_color",Color.WHITE)
    play_button.add_theme_color_override("font_pressed_color",Color("fff2bd"))
    var normal = StyleBoxFlat.new()
    normal.bg_color = Color(0.47,0.20,0.76,0.94)
    normal.corner_radius_top_left = 30
    normal.corner_radius_top_right = 30
    normal.corner_radius_bottom_left = 30
    normal.corner_radius_bottom_right = 30
    normal.border_width_left=3; normal.border_width_right=3; normal.border_width_top=3; normal.border_width_bottom=3
    normal.border_color=Color(1,0.78,1,0.85)
    normal.shadow_color=Color(0.1,0.02,0.2,0.45)
    normal.shadow_size=10
    play_button.add_theme_stylebox_override("normal",normal)
    var hover = normal.duplicate()
    hover.bg_color = Color(0.56,0.27,0.84,0.98)
    play_button.add_theme_stylebox_override("hover",hover)
    play_button.add_theme_stylebox_override("pressed",hover)
    play_button.pressed.connect(_start_game)
    add_child(play_button)

    var note = Label.new()
    note.text = "No ads • No timers • Just adventure"
    note.position = Vector2(84,570)
    note.size = Vector2(500,35)
    note.add_theme_font_size_override("font_size",19)
    note.add_theme_color_override("font_color",Color(1,1,1,0.73))
    add_child(note)

    var version = Label.new()
    version.text = "Gold Standard Playtest • v0.6"
    version.position = Vector2(930,675)
    version.size = Vector2(320,28)
    version.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    version.add_theme_font_size_override("font_size",16)
    version.add_theme_color_override("font_color",Color(1,1,1,0.55))
    add_child(version)

    fade = ColorRect.new()
    fade.color = Color(0.06,0.03,0.12,0.0)
    fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(fade)

func _process(_delta):
    var t = Time.get_ticks_msec()/1000.0
    for f in floaters:
        var h = f.get_meta("home")
        var p = f.get_meta("phase")
        f.position = h + Vector2(sin(t*0.8+p)*9, cos(t*1.05+p)*7)
        f.modulate.a = 0.35 + 0.65*(sin(t*1.8+p)*0.5+0.5)
    if play_button and not entering:
        var pulse = 1.0 + sin(t*2.1)*0.015
        play_button.pivot_offset = play_button.size/2.0
        play_button.scale = Vector2(pulse,pulse)

func _start_game():
    if entering: return
    entering = true
    play_button.disabled = true
    if music:
        var tw = create_tween()
        tw.tween_property(music,"volume_db",-42.0,0.45)
    var tween = create_tween()
    tween.tween_property(fade,"color:a",1.0,0.5)
    tween.tween_callback(func(): get_tree().change_scene_to_file("res://scenes/Game.tscn"))

func _on_music_finished():
    if not entering and music:
        music.play()
