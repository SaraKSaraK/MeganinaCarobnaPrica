# Megan & Piko — Step 1 movement prototype

Purpose: validate one thing only: can a four-year-old intuitively tap the forest path and move Megan around without reading or adult instruction?

Included: side-view 2D forest, tap-to-walk, destination changes mid-walk, character facing, walk/idle animation, Piko follower with lag, smooth camera, parallax-style layered world, ambient motion, large touch surface.

Not included intentionally: story, speech recognition, missions, learning questions, branching, collectibles. These are Step 2+ only after movement is approved.
